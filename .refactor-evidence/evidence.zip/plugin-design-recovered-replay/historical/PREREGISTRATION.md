# Replay pre-registration (written before any run)

Versions: OLD = l-gevity-skills 38166b0 (v3.4.0), NEW = 2d39480. Each run gets a
throwaway project holding that version's `.claude/skills` + `CLAUDE.md` + the
case fixture, run headless through `claude -p` exactly like the scenario
recorder (project settings only, no MCP, no session persistence). 3 runs per
version per case. Judge is blind to version.

| Case | Real origin in the logs | Rule(s) under test | Primary metric (better =) |
|---|---|---|---|
| C1 plugin-design | openpaymentaddress 2026-08-04: "Use alchemy to create a modular / plugin like extensible design" → owner: "Do we need all this complexity? ... just a list of currencies and formats" | T2 minimal-first (CLAUDE.md §3, FCT per component, alchemy signal row) | judge `leads_minimal` = 1 (recommended design is a data list/table, no plugin/registry) |
| C2 dedup-implement | payquality 2026-08-12 "Did you use alchemy to simplify?" / 2026-08-19 "verify using alchemy" found defects the first pass missed | T1 close-out (alchemy directive 9) | fixture tests pass on the result files (objective); secondary: judge `closeout` = 1 |
| C3 audit-intent | payquality #441: deliberate missing trigger filed as `bug` + `production-blocker` | T5 verify findings (alchemy Retrospective step 7), CLAUDE.md §2 | judge `flags_deliberate_as_defect` = 0 |
| C4 unreleased-rename | protocol 2026-07-27/28: "We don't need any compatibility, the protocol is not in use" / "Keep the protocol on the same version" | T6 release status (EDD, CLAUDE.md §5) | result keeps no legacy `addr` reader and no version bump (objective) |
| C5 ci-design | openpaymentaddress 2026-07-30 "drastically reduce the deploy / CI time. It is only a small application"; payquality Lighthouse-in-pre-push reversal | T2 minimal-first + T8 stage time budget (defect-shift-left D2) | judge `heavy_check_in_local_hook` = 0 and `minimal_first` = 1 |

Secondary metrics for every case: output words (fewer is better at equal
quality), judge `actionable` 1–5 (can the owner act without a follow-up
question), SKILL.md bodies read, turns.

Decision rule per rule family, n = 3 per arm:
- **Keep** when NEW beats OLD on the primary metric by at least 2 of 3 runs
  (summed over its cases), and no secondary metric gets clearly worse
  (actionable mean down ≥ 1, or words up ≥ 50 %).
- **Drop as redundant** when OLD already meets the primary metric in ≥ 2 of 3
  runs and NEW is not better.
- **Rework or drop** when both arms fail the primary metric in ≥ 2 of 3 runs.
- Anything in between: report as inconclusive; no claim of improvement.

Rules the replay cannot reach (traceability reachability/evidence/issue
closeout, gate-seen-red, test-strategy observed effect, ci-cd external data
and path filters, architecture-guidelines placement, JS gotchas, grounding
decision source, continuous-improvement fields) are reported as untested.

## Deviation (before the matrix, after one smoke run per arm)

The C4 spec first said "Not published; the only producer and consumer are the
two modules in this repository". Both smoke runs renamed in place: the fixture
handed over the answer the rule is meant to make the agent look for. That
sentence was cut to "Status: draft." before the matrix; the smoke runs are
discarded.

## Exploratory, added after the main matrix (not pre-registered)

c6-housekeeping (dispatch-housekeeping-skip request) and c7-adaptive-claims
(dispatch-adaptive-structural request and fixture), 3 runs per arm, to give
the two rules still standing a baseline: housekeeping → SKIP, and claim only
what ran (route_loaded). Scored with the validator's own scenario checks.
