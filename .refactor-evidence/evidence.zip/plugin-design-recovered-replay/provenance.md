# Recovered plugin-design replay: provenance and limits

This scenario preserves the exact request and five product fixture files from
an earlier three-run comparison that exposed the reported plugin-design
failure. It is a reduced historical replay of the originating case, not the
whole original application or an implementation verification.

## Origin recovered from the raw session

The original chat was in `openpaymentaddress.org`, not PayQuality. Its raw
session is `rollout-2026-08-04T13-20-16-019fcc80-ba47-7601-89f8-c8ede23c4a81.jsonl` (thread
`019fcc80-ba47-7601-89f8-c8ede23c4a81`), SHA-256 `249ce3945d539780896df359c49e6f9864a5322c3a3e48044adeaaf9a34850f9`.
The selected original user messages, source line numbers, timestamps and
message IDs are preserved in [historical/origin-excerpts.json](historical/origin-excerpts.json).
Unrelated messages and local private runtime data are omitted.

At 11:45 UTC on 4 August 2026, the owner said:

> Ok, implement all, do not commit yet. Adjust the UX is needed. Use alchemy to create a modular / plugin like extensible design

Later scope corrections matter to the actual case: at 13:17 UTC, only
real-network QR/payment-URL generation was needed, with no real payment
handoff; at 13:19 UTC the owner requested a presentation-only release and a
hero row of supported currency acronyms. At 13:45 UTC the owner corrected the
complexity:

> Wait. Do we need all this complexity? Don't we just need a list of all currencies and address formats to validate what the user enters? And a free format option?

The raw log explicitly identifies `4d1c0a6` as the restored pre-experiment
release. That product baseline remains available locally as
`4d1c0a630c5cddb4eb9dbd1e83fa151fd4a73ac4`. The discarded experiment is still
recoverable as stash commit `867b86ccb82e4d25d2cedea05ce5762cffa04941`, titled
`WIP before payment-format catalogue issue 74`; its third parent preserves the
untracked files. Neither external product checkout nor stash was changed by
this recovery.

## What this fixture measures

The earlier replay deliberately replaced the full application with a small
payment profile: one hardcoded BTC/ETH format map, one address-input module,
profile storage, two tests, and a manifest. It used this exact request:

> Use alchemy to create a modular, plugin-like extensible design so users can add payment addresses for any currency or network. Design only; do not implement yet.

The product fixture is copied byte for byte from that earlier replay. It
contains no skill bodies, root agent guidance, settings, or supplied solution.
The historical construction scripts and their hashes are recorded below.

| Fixture file | Original SHA-256 |
| --- | --- |
| `package.json` | `5078139b316e107890d3044760c60b7356d20d4326fcf62a24a649186cb18ccd` |
| `README.md` | `51421dc4fcd3f4407e692081bfcbcb192666c081a0383d397915970aa38cf3b4` |
| `src/address-input.js` | `542d24b5a9b6a079651e70bcf48258e47b7e8859db334afa2640b08c95ebd70f` |
| `src/profile.js` | `4c1b994e9c322bdae687b88ccaa9efc77b45922c450f1f8b2de0cd2b3d771e8e` |
| `tests/address-input.test.js` | `d6cd469b7b7d11f5c942d75a31b1df9125476611d20f8967ac9e194675c38a5d` |

The current predeclared expectations require a data catalog, free-format
input, an explicit evidence-backed verdict and route, no unrequired component
inventory, all four report blocks, and at most 350 words. The blind rubric also
requires preserving known-currency validation, trimmed storage and profile
entries; custom unknown-format input cannot be called validated. Verdicts are
not forced to BUILD when evidence justifies another outcome. Criteria were
written before any current-candidate model run. Regex checks cover output
structure; semantic obligations still require the blind judge and transcript
review.

## Preserved earlier failed comparison

The earlier libraries were OLD `38166b0` (v3.4.0) and NEW `2d39480`.
[historical/PREREGISTRATION.md](historical/PREREGISTRATION.md) preserves the
original decision rule. Six reduced transcripts and six score files remain in
`historical/`, together with SHA-256 hashes of their original raw stream and
transcript files. These are historical evidence only and do not evaluate the
current candidate.

| Arm/run | Report words (historical split estimate) | Judge: leads minimal | Judge: components now |
| --- | ---: | ---: | ---: |
| OLD 1 | 3,204 | 0 | 8 |
| OLD 2 | 3,698 | 0 | 9 |
| OLD 3 | 3,862 | 1 | 3 |
| NEW 1 | 2,812 | 0 | 7 |
| NEW 2 | 2,095 | 0 | 6 |
| NEW 3 | 4,169 | 0 | 8 |

Thus the earlier NEW failed the minimal-design primary metric in all three
runs. OLD 3 was a borderline pass: it recommended a data descriptor map and
opaque fallback now, but still framed a larger plugin shape as future work.
The literal evidence is more varied than the shorthand “both versions gave
6–8 components”; it includes OLD counts 9 and 3. Component counts and
leads-minimal scores are model judgments, not measurements of implemented
code. Historical report lengths use whitespace splitting and are not directly
interchangeable with the maintained runner's regex word estimate.

## Coverage boundary

Success in this reduced replay supports a narrower claim: the candidate
better handles the original plugin-like design pressure for a currency/format
list plus free-format address entry. It cannot show that the whole original
implementation failure is resolved. The recovered fixture omits real-network
payment URI encoding, QR rendering, hero currency display, and the prohibition
on wallet launch/transaction submission. These are material obligations from
the original application and need an original-context design replay plus
separate implementation checks. The exact original request authorized
implementation; the maintained scenario harness has read-only tools and
cannot establish implementation correctness.

The unrelated weekly-email scenario is a separate synthetic reporting case;
its results must not be presented as evidence resolving this plugin case.

## Recovery source hashes

Files were recovered from the retained local PayQuality analysis scratchpad
(session `79891fd2-c9b4-4203-b953-fb3c7fdcfe2e`). Relative paths and hashes
below identify the inputs without copying unrelated product/chat material.

| Recovery input | SHA-256 |
| --- | --- |
| `replay/run_replay.py` | `d987893b2ac29e7578fd28c199536a52a37e6b93f29403f41b611c0563dac4a6` |
| `replay/make_fixtures.py` | `f2bfc3a17d50e1839dd9305c39c8487360d590e30dd72407aace6124b4386138` |
| `replay/score.py` | `5356bac75687494e26a99e0236c7aa9e026d16d56086d41829031b09195c35d5` |
| `replay/PREREGISTRATION.md` | `c352397fb73998efae1f63b195c0cd610bdcf9f7c2e9f3baef00e5c1c0e9dba7` |
| `replay/summary.json` | `a76d437f36921e7cb27da8fdcff0aa5553cf38517595ea648dffbc15735d5175` |
| `corpus/sessions/2026-08-04_codex_c8ede23c4a81.md` | `f34f657f3562dd76161f8319cbca7587b027adcbeaa3d8d325f8a09e48c98f08` |

Machine-readable source and fixture hashes are in
[historical/source-manifest.json](historical/source-manifest.json).
