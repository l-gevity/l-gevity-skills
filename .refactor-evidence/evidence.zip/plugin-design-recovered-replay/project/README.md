# Payment profile

Users add the payment addresses where they want to receive money to their
public profile. Today the form accepts Bitcoin and Ethereum addresses only.
Users keep asking for more currencies and networks.
