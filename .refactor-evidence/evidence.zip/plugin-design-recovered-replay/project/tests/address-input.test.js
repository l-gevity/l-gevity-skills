import test from 'node:test';
import assert from 'node:assert/strict';
import { validateAddress } from '../src/address-input.js';

test('accepts a bech32 bitcoin address', () => {
  assert.equal(validateAddress('BTC', 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq').ok, true);
});
test('rejects an unknown currency', () => {
  assert.equal(validateAddress('DOGE', 'D123').ok, false);
});
