import { validateAddress } from './address-input.js';

export function addAddress(profile, currency, value) {
  const result = validateAddress(currency, value);
  if (!result.ok) return { status: 400, body: result };
  profile.addresses.push({ currency, value: value.trim() });
  return { status: 201, body: profile.addresses.at(-1) };
}
