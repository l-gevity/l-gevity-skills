const FORMATS = {
  BTC: /^(bc1[a-z0-9]{25,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/,
  ETH: /^0x[a-fA-F0-9]{40}$/,
};

export function supportedCurrencies() {
  return Object.keys(FORMATS);
}

export function validateAddress(currency, value) {
  const format = FORMATS[currency];
  if (!format) return { ok: false, reason: 'unsupported currency' };
  return format.test(value.trim()) ? { ok: true } : { ok: false, reason: 'invalid address' };
}
