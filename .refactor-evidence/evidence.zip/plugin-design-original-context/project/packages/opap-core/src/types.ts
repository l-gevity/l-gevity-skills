export interface SepaPaymentOption {
  readonly type: "sepa";
  readonly currency: "EUR";
  readonly name: string;
  readonly iban: string;
}

export interface Erc20PaymentOption {
  readonly type: "erc20";
  readonly currency: string;
  readonly chain: string;
  readonly asset: string;
  readonly recipient: string;
  readonly symbol?: string;
}

export interface ExtensionPaymentOption {
  readonly type: string;
  readonly currency: string;
  readonly data: Readonly<Record<string, unknown>>;
}

export type SplitAllocationEntry =
  | { readonly recipient: string; readonly share_ppm: number }
  | { readonly target: string; readonly share_ppm: number };

export interface SplitExecution {
  readonly type: "erc20-contract";
  readonly adapter: string;
  readonly chain: string;
  readonly asset: string;
  readonly contract: string;
  readonly config_id: string;
}

export interface SplitPaymentOption {
  readonly type: "split";
  readonly currency: string;
  readonly execution: SplitExecution;
  readonly allocations: readonly SplitAllocationEntry[];
}

export type PaymentOption =
  | SepaPaymentOption
  | Erc20PaymentOption
  | SplitPaymentOption
  | ExtensionPaymentOption;

export interface OptionsPayment {
  readonly type: "options";
  readonly options: readonly PaymentOption[];
}

export interface DelegatePayment {
  readonly type: "delegate";
  readonly target: string;
}

export interface OpapRecord {
  readonly version: 1;
  readonly id: string;
  readonly revision: number;
  readonly issued_at: string;
  readonly expires_at: string;
  readonly name?: string;
  readonly payment: OptionsPayment | DelegatePayment;
  readonly extensions?: Readonly<Record<string, unknown>>;
}
