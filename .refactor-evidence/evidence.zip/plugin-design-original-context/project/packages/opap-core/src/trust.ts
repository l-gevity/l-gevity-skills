import { OpapError } from "./errors";
import { fingerprintRecordBytes } from "./record";
import { normalizeOpid } from "./opid";
import type { Continuity } from "./verification";

const BASE64URL = /^[A-Za-z0-9_-]+$/;
const TRUST_RECORD =
  /^v=opap1;epoch=([1-9][0-9]*);ed25519=([A-Za-z0-9_-]+);rec=(none|ed25519-sha256:[A-Za-z0-9_-]+)(?:;next=([A-Za-z0-9_-]+);nextsig=([A-Za-z0-9_-]+))?(?:;previous=([A-Za-z0-9_-]+);previoussig=([A-Za-z0-9_-]+))?$/;
const PROOF = /^v=1;sig=([A-Za-z0-9_-]+)$/;
const RECOVERY_DOMAIN = "OPAP/1 RECOVERY KEY\n";

export interface TrustRecord {
  readonly epoch: number;
  readonly ed25519: string;
  readonly recoveryCommitment: string;
  readonly next?: string;
  readonly nextSignature?: string;
  readonly previous?: string;
  readonly previousSignature?: string;
}

export interface AuthenticatedNextKey {
  readonly epoch: number;
  readonly ed25519: string;
}

export interface OriginKeyPin {
  readonly hostname: string;
  readonly epoch: number;
  readonly ed25519: string;
  readonly recoveryCommitment: string;
  readonly authenticatedNext?: AuthenticatedNextKey;
  readonly retiredKeyFingerprints: readonly `sha256:${string}`[];
}

export interface OriginTrustDecision {
  readonly authorizedKey: string;
  readonly continuity: Exclude<Continuity, "none">;
  readonly nextPin: OriginKeyPin;
}

function decodeBase64Url(
  value: string,
  code:
    | "invalid_trust_record"
    | "record_proof_invalid"
    | "identity_key_transition_invalid",
): Uint8Array {
  if (!BASE64URL.test(value)) throw new OpapError(code);
  try {
    const binary = atob(
      `${value.replaceAll("-", "+").replaceAll("_", "/")}${"=".repeat((4 - (value.length % 4)) % 4)}`,
    );
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  } catch {
    throw new OpapError(code);
  }
}

function encodeBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary)
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replace(/=+$/u, "");
}

function validEncodedLength(value: string, bytes: number): boolean {
  return decodeBase64Url(value, "invalid_trust_record").byteLength === bytes;
}

export async function createRecoveryCommitment(
  recoveryPublicKey: string,
): Promise<string> {
  const raw = decodeBase64Url(recoveryPublicKey, "invalid_trust_record");
  if (raw.byteLength !== 32) throw new OpapError("invalid_trust_record");
  const prefix = new TextEncoder().encode(RECOVERY_DOMAIN);
  const input = new Uint8Array(prefix.byteLength + raw.byteLength);
  input.set(prefix);
  input.set(raw, prefix.byteLength);
  const digest = await crypto.subtle.digest("SHA-256", input);
  return `ed25519-sha256:${encodeBase64Url(new Uint8Array(digest))}`;
}

export function parseTrustRecord(value: string): TrustRecord {
  const match = TRUST_RECORD.exec(value);
  if (match === null) {
    throw new OpapError("invalid_trust_record", `value:${value}`);
  }
  const epoch = Number(match[1]);
  const ed25519 = match[2]!;
  const recoveryCommitment = match[3]!;
  const next = match[4];
  const nextSignature = match[5];
  const previous = match[6];
  const previousSignature = match[7];
  const recoveryDigest = recoveryCommitment.startsWith("ed25519-sha256:")
    ? recoveryCommitment.slice("ed25519-sha256:".length)
    : undefined;
  if (
    !Number.isSafeInteger(epoch) ||
    epoch < 1 ||
    !validEncodedLength(ed25519, 32) ||
    (recoveryDigest !== undefined && !validEncodedLength(recoveryDigest, 32)) ||
    (next !== undefined &&
      (!validEncodedLength(next, 32) ||
        nextSignature === undefined ||
        !validEncodedLength(nextSignature, 64))) ||
    (previous !== undefined &&
      (!validEncodedLength(previous, 32) ||
        previousSignature === undefined ||
        !validEncodedLength(previousSignature, 64))) ||
    next === ed25519 ||
    previous === ed25519 ||
    (next !== undefined && next === previous) ||
    (next !== undefined && previous !== undefined)
  ) {
    throw new OpapError("invalid_trust_record", `value:${value}`);
  }
  return Object.freeze({
    epoch,
    ed25519,
    recoveryCommitment,
    ...(next === undefined ? {} : { next, nextSignature }),
    ...(previous === undefined ? {} : { previous, previousSignature }),
  });
}

export function selectTrustRecord(
  records: readonly (readonly string[])[],
): TrustRecord | undefined {
  const candidates = records
    .map((chunks) => chunks.join(""))
    .filter((value) => value.trimStart().startsWith("v=opap1"));
  if (candidates.length === 0) return undefined;
  if (candidates.length > 1) {
    throw new OpapError("ambiguous_trust_record", `count:${candidates.length}`);
  }
  return parseTrustRecord(candidates[0] ?? "");
}

export function originTrustName(opid: string): string {
  return `_opap.${new URL(normalizeOpid(opid)).hostname}`;
}

export function keyTransitionMessage(
  hostname: string,
  recoveryCommitment: string,
  currentEpoch: number,
  currentPublicKey: string,
  nextPublicKey: string,
): string {
  return `OPAP/1 KEY TRANSITION\n${hostname}\n${recoveryCommitment}\n${currentEpoch}\n${currentPublicKey}\n${currentEpoch + 1}\n${nextPublicKey}\n`;
}

async function importPublicKey(
  value: string,
  code: "record_proof_invalid" | "identity_key_transition_invalid",
): Promise<CryptoKey> {
  try {
    return await crypto.subtle.importKey(
      "raw",
      Uint8Array.from(decodeBase64Url(value, code)).buffer,
      { name: "Ed25519" },
      false,
      ["verify"],
    );
  } catch (cause) {
    throw new OpapError(code, undefined, { cause });
  }
}

export async function verifyKeyTransition(
  hostname: string,
  recoveryCommitment: string,
  currentEpoch: number,
  currentPublicKey: string,
  nextPublicKey: string,
  signature: string,
): Promise<void> {
  const valid = await crypto.subtle.verify(
    "Ed25519",
    await importPublicKey(currentPublicKey, "identity_key_transition_invalid"),
    Uint8Array.from(
      decodeBase64Url(signature, "identity_key_transition_invalid"),
    ).buffer,
    new TextEncoder().encode(
      keyTransitionMessage(
        hostname,
        recoveryCommitment,
        currentEpoch,
        currentPublicKey,
        nextPublicKey,
      ),
    ),
  );
  if (!valid) throw new OpapError("identity_key_transition_invalid");
}

export async function fingerprintOriginKey(
  publicKey: string,
): Promise<`sha256:${string}`> {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    Uint8Array.from(decodeBase64Url(publicKey, "invalid_trust_record")).buffer,
  );
  const hex = Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
  return `sha256:${hex}`;
}

async function authenticatedNext(
  hostname: string,
  trust: TrustRecord,
  existing: AuthenticatedNextKey | undefined,
): Promise<AuthenticatedNextKey | undefined> {
  if (trust.next === undefined || trust.nextSignature === undefined)
    return existing;
  await verifyKeyTransition(
    hostname,
    trust.recoveryCommitment,
    trust.epoch,
    trust.ed25519,
    trust.next,
    trust.nextSignature,
  );
  const proposed = Object.freeze({
    epoch: trust.epoch + 1,
    ed25519: trust.next,
  });
  if (
    existing !== undefined &&
    (existing.epoch !== proposed.epoch || existing.ed25519 !== proposed.ed25519)
  ) {
    throw new OpapError("identity_key_transition_invalid", "successor_changed");
  }
  return proposed;
}

export async function advanceOriginKeyPin(
  hostname: string,
  trust: TrustRecord,
  pin: OriginKeyPin | undefined,
): Promise<OriginTrustDecision> {
  if (pin === undefined) {
    const next = await authenticatedNext(hostname, trust, undefined);
    return Object.freeze({
      authorizedKey: trust.ed25519,
      continuity: "first-use",
      nextPin: Object.freeze({
        hostname,
        epoch: trust.epoch,
        ed25519: trust.ed25519,
        recoveryCommitment: trust.recoveryCommitment,
        ...(next === undefined ? {} : { authenticatedNext: next }),
        retiredKeyFingerprints: Object.freeze([]),
      }),
    });
  }
  if (pin.hostname !== hostname) {
    throw new OpapError("trust_history_unavailable", "pin_hostname_mismatch");
  }
  const presentedFingerprint = await fingerprintOriginKey(trust.ed25519);
  if (pin.retiredKeyFingerprints.includes(presentedFingerprint)) {
    throw new OpapError("identity_key_rollback", `epoch:${trust.epoch}`);
  }
  if (trust.epoch < pin.epoch) {
    throw new OpapError("identity_key_rollback", `epoch:${trust.epoch}`);
  }
  if (trust.recoveryCommitment !== pin.recoveryCommitment) {
    throw new OpapError(
      "identity_key_transition_invalid",
      "recovery_commitment",
    );
  }
  if (trust.epoch === pin.epoch) {
    if (trust.ed25519 !== pin.ed25519) {
      throw new OpapError(
        "identity_key_changed",
        JSON.stringify({
          hostname,
          previousKeyFingerprint: await fingerprintOriginKey(pin.ed25519),
          proposedKeyFingerprint: presentedFingerprint,
          epoch: trust.epoch,
        }),
      );
    }
    const next = await authenticatedNext(
      hostname,
      trust,
      pin.authenticatedNext,
    );
    return Object.freeze({
      authorizedKey: trust.ed25519,
      continuity: "bound",
      nextPin: Object.freeze({
        ...pin,
        ...(next === undefined ? {} : { authenticatedNext: next }),
      }),
    });
  }
  if (trust.epoch !== pin.epoch + 1) {
    throw new OpapError("identity_key_transition_invalid", "missed_transition");
  }
  let transitionAuthenticated =
    pin.authenticatedNext?.epoch === trust.epoch &&
    pin.authenticatedNext.ed25519 === trust.ed25519;
  if (trust.previous !== undefined && trust.previousSignature !== undefined) {
    if (trust.previous !== pin.ed25519) {
      throw new OpapError("identity_key_transition_invalid", "previous_key");
    }
    await verifyKeyTransition(
      hostname,
      pin.recoveryCommitment,
      pin.epoch,
      pin.ed25519,
      trust.ed25519,
      trust.previousSignature,
    );
    transitionAuthenticated = true;
  }
  if (!transitionAuthenticated) {
    throw new OpapError(
      "identity_key_changed",
      JSON.stringify({
        hostname,
        previousKeyFingerprint: await fingerprintOriginKey(pin.ed25519),
        proposedKeyFingerprint: presentedFingerprint,
        epoch: trust.epoch,
      }),
    );
  }
  const retired = Object.freeze([
    ...pin.retiredKeyFingerprints,
    await fingerprintOriginKey(pin.ed25519),
  ]);
  const next = await authenticatedNext(hostname, trust, undefined);
  return Object.freeze({
    authorizedKey: trust.ed25519,
    continuity: "bound",
    nextPin: Object.freeze({
      hostname,
      epoch: trust.epoch,
      ed25519: trust.ed25519,
      recoveryCommitment: trust.recoveryCommitment,
      ...(next === undefined ? {} : { authenticatedNext: next }),
      retiredKeyFingerprints: retired,
    }),
  });
}

export async function verifyRecordProof(
  opid: string,
  bytes: Uint8Array,
  proofHeader: string | undefined,
  publicKey: string,
): Promise<void> {
  const proof =
    proofHeader === undefined ? undefined : PROOF.exec(proofHeader)?.[1];
  if (proof === undefined) throw new OpapError("record_proof_invalid");
  const signature = decodeBase64Url(proof, "record_proof_invalid");
  if (signature.byteLength !== 64) throw new OpapError("record_proof_invalid");
  const signed = new TextEncoder().encode(
    `OPAP/1\n${normalizeOpid(opid)}\n${await fingerprintRecordBytes(bytes)}`,
  );
  const valid = await crypto.subtle.verify(
    "Ed25519",
    await importPublicKey(publicKey, "record_proof_invalid"),
    Uint8Array.from(signature).buffer,
    Uint8Array.from(signed).buffer,
  );
  if (!valid) throw new OpapError("record_proof_invalid");
}
