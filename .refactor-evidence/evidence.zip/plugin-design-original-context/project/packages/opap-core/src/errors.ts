export const OPAP_ERROR_CODES = [
  "invalid_opid",
  "record_not_found",
  "record_unavailable",
  "invalid_record",
  "unsupported_version",
  "id_mismatch",
  "dnssec_bogus",
  "invalid_trust_record",
  "ambiguous_trust_record",
  "record_proof_invalid",
  "record_not_yet_valid",
  "record_expired",
  "record_rollback",
  "record_revision_conflict",
  "identity_key_changed",
  "identity_key_rollback",
  "identity_key_transition_invalid",
  "payment_target_changed",
  "trust_history_unavailable",
  "resolution_cycle",
  "resolution_limit_exceeded",
  "duplicate_opid",
  "target_address_forbidden",
  "no_supported_method",
  "unrecognized_asset",
  "asset_currency_mismatch",
  "unsupported_split_adapter",
  "split_target_incompatible",
  "nested_split_unsupported",
  "split_config_mismatch",
  "split_recipient_collision",
  "recipient_mismatch",
  "split_state_mismatch",
  "amount_not_splittable",
  "execution_changed",
] as const;

export type OpapErrorCode = (typeof OPAP_ERROR_CODES)[number];

export class OpapError extends Error {
  readonly code: OpapErrorCode;
  readonly diagnostic: string | undefined;

  constructor(
    code: OpapErrorCode,
    diagnostic?: string,
    options?: ErrorOptions,
  ) {
    super(code, options);
    this.name = "OpapError";
    this.code = code;
    this.diagnostic = diagnostic;
  }
}
