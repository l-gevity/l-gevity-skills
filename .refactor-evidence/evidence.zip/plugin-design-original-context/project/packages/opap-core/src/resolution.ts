import { OpapError } from "./errors";
import { isSha256Hex } from "./fingerprint";
import { normalizeOpid } from "./opid";
import type { OpapRecord, PaymentOption } from "./types";
import type { VerificationEvidence } from "./verification";

export const MAX_DELEGATE_HOPS = 8;
export const MAX_RESOLUTION_RECORDS = 32;

export interface ResolutionRecord {
  readonly id: string;
  readonly fingerprint: string;
  readonly revision: number;
  readonly expiresAt: string;
  readonly verification: VerificationEvidence;
}

export interface ResolutionEvidence {
  readonly record: OpapRecord;
  readonly fingerprint: string;
  readonly verification: VerificationEvidence;
}

export interface PendingResolution {
  readonly status: "pending";
  readonly source: string;
  readonly nextOpid: string;
  readonly delegateHops: number;
  readonly visited: readonly string[];
  readonly records: readonly ResolutionRecord[];
}

export interface OptionsResolution {
  readonly status: "resolved";
  readonly paymentType: "options";
  readonly source: string;
  readonly resolvedTo: string;
  readonly name?: string;
  readonly options: readonly PaymentOption[];
  readonly records: readonly ResolutionRecord[];
}

export type TerminalResolution = OptionsResolution;
export type ResolutionStep = PendingResolution | TerminalResolution;

function freezeResolutionRecord(
  evidence: ResolutionEvidence,
): ResolutionRecord {
  return Object.freeze({
    id: evidence.record.id,
    fingerprint: evidence.fingerprint,
    revision: evidence.record.revision,
    expiresAt: evidence.record.expires_at,
    verification: evidence.verification,
  });
}

function freezePaymentOption(option: PaymentOption): PaymentOption {
  if (option.type === "split" && "execution" in option) {
    return Object.freeze({
      ...option,
      execution: Object.freeze({ ...option.execution }),
      allocations: Object.freeze(
        option.allocations.map((allocation) =>
          Object.freeze({ ...allocation }),
        ),
      ),
    });
  }
  if ("data" in option) {
    return Object.freeze({
      ...option,
      data: Object.freeze({ ...option.data }),
    });
  }
  return Object.freeze({ ...option });
}

export function createResolutionState(input: string): PendingResolution {
  const source = normalizeOpid(input);
  return Object.freeze({
    status: "pending",
    source,
    nextOpid: source,
    delegateHops: 0,
    visited: Object.freeze([]),
    records: Object.freeze([]),
  });
}

export function advanceResolution(
  state: PendingResolution,
  evidence: ResolutionEvidence,
): ResolutionStep {
  if (evidence.record.id !== state.nextOpid) {
    throw new OpapError(
      "id_mismatch",
      `expected:${state.nextOpid};actual:${evidence.record.id}`,
    );
  }
  if (!isSha256Hex(evidence.fingerprint)) {
    throw new OpapError("invalid_record", "invalid_fingerprint");
  }
  if (state.visited.includes(state.nextOpid)) {
    throw new OpapError("resolution_cycle", `id:${state.nextOpid}`);
  }
  if (state.records.length >= MAX_RESOLUTION_RECORDS) {
    throw new OpapError("resolution_limit_exceeded", "records");
  }

  const visited = Object.freeze([...state.visited, state.nextOpid]);
  const records = Object.freeze([
    ...state.records,
    freezeResolutionRecord(evidence),
  ]);

  if (evidence.record.payment.type === "delegate") {
    if (state.delegateHops >= MAX_DELEGATE_HOPS) {
      throw new OpapError("resolution_limit_exceeded", "delegate_hops");
    }
    const target = evidence.record.payment.target;
    if (visited.includes(target)) {
      throw new OpapError("resolution_cycle", `id:${target}`);
    }
    return Object.freeze({
      status: "pending",
      source: state.source,
      nextOpid: target,
      delegateHops: state.delegateHops + 1,
      visited,
      records,
    });
  }

  return Object.freeze({
    status: "resolved",
    paymentType: "options",
    source: state.source,
    resolvedTo: evidence.record.id,
    ...(evidence.record.name === undefined
      ? {}
      : { name: evidence.record.name }),
    options: Object.freeze(
      evidence.record.payment.options.map(freezePaymentOption),
    ),
    records,
  });
}
