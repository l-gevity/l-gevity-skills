import { OpapError } from "./errors";
import type { OpapRecord } from "./types";

export type Binding = "https" | "dnssec";
export type Continuity = "none" | "first-use" | "bound";

export interface VerificationEvidence {
  readonly binding: Binding;
  readonly continuity: Continuity;
  readonly history?: "none" | "available";
  readonly hostname: string;
  readonly keyFingerprint?: `sha256:${string}`;
  readonly keyEpoch?: number;
}

export interface OpidSecurityHistoryEntry {
  readonly revision: number;
  readonly recordFingerprint: string;
  readonly targetFingerprint: `sha256:${string}`;
  readonly targetProjection: string;
  readonly highestBinding: Binding;
}

export function strongestBinding(
  previous: Binding | undefined,
  current: Binding,
): Binding {
  return previous === "dnssec" || current === "dnssec" ? "dnssec" : "https";
}

export function validateRecordFreshness(
  record: OpapRecord,
  now: Date = new Date(),
): void {
  const issuedAt = Date.parse(record.issued_at);
  const expiresAt = Date.parse(record.expires_at);
  if (!Number.isFinite(issuedAt) || !Number.isFinite(expiresAt)) {
    throw new OpapError("invalid_record", "invalid_publication_timestamp");
  }
  if (expiresAt <= issuedAt) {
    throw new OpapError("invalid_record", "expires_at_not_after_issued_at");
  }
  const current = now.getTime();
  if (!Number.isFinite(current)) {
    throw new TypeError("now must be a valid Date");
  }
  if (current < issuedAt) {
    throw new OpapError(
      "record_not_yet_valid",
      `issued_at:${record.issued_at}`,
    );
  }
  if (current >= expiresAt) {
    throw new OpapError("record_expired", `expires_at:${record.expires_at}`);
  }
}

export function validateRecordRevision(
  previous: OpidSecurityHistoryEntry | undefined,
  record: OpapRecord,
  recordFingerprint: string,
): void {
  if (previous === undefined) return;
  if (record.revision < previous.revision) {
    throw new OpapError(
      "record_rollback",
      `previous:${previous.revision};current:${record.revision}`,
    );
  }
  if (
    record.revision === previous.revision &&
    recordFingerprint !== previous.recordFingerprint
  ) {
    throw new OpapError(
      "record_revision_conflict",
      `revision:${record.revision}`,
    );
  }
}
