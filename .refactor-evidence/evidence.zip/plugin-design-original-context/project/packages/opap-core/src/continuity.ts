import type { ErrorObject, ValidateFunction } from "ajv";

import { OpapError } from "./errors";
import validateContinuityEvidenceSchema from "./generated/continuity-evidence-schema-validator";
import { normalizeOpid } from "./opid";
import {
  canonicalJson,
  fingerprintCanonicalJson,
  type JsonObject,
} from "./target";
import { fingerprintOriginKey, verifyKeyTransition } from "./trust";
import {
  strongestBinding,
  type Binding,
  type Continuity,
} from "./verification";

export type ContinuityHistory = "none" | "available";
export type ContinuityAuthentication = "unsigned" | "origin-key";

export interface NoContinuityEvidence {
  readonly version: 1;
  readonly protocol: "OPAP/1";
  readonly state: "none";
}

export interface UnavailableContinuityEvidence {
  readonly version: 1;
  readonly protocol: "OPAP/1";
  readonly state: "unavailable";
}

export interface AuthenticatedNextEvidence {
  readonly epoch: number;
  readonly public_key: string;
  readonly key_fingerprint: `sha256:${string}`;
  readonly transition_signature: string;
}

export interface UnsignedHostEvidence {
  readonly hostname: string;
  readonly highest_binding: Binding;
  readonly authentication: "unsigned";
}

export interface OriginKeyHostEvidence {
  readonly hostname: string;
  readonly highest_binding: Binding;
  readonly authentication: "origin-key";
  readonly epoch: number;
  readonly public_key: string;
  readonly key_fingerprint: `sha256:${string}`;
  readonly recovery_commitment: string;
  readonly authenticated_next?: AuthenticatedNextEvidence;
  readonly retired_key_fingerprints: readonly `sha256:${string}`[];
}

export type HostContinuityEvidence =
  UnsignedHostEvidence | OriginKeyHostEvidence;

export interface OpidContinuityEvidence {
  readonly opid: string;
  readonly hostname: string;
  readonly revision: number;
  readonly record_fingerprint: `sha256:${string}`;
  readonly target_projection: JsonObject;
  readonly target_fingerprint: `sha256:${string}`;
  readonly highest_binding: Binding;
  readonly authentication: ContinuityAuthentication;
}

export interface AvailableContinuityEvidence {
  readonly version: 1;
  readonly protocol: "OPAP/1";
  readonly state: "available";
  readonly evidence: {
    readonly hosts: readonly HostContinuityEvidence[];
    readonly opids: readonly OpidContinuityEvidence[];
  };
}

export type PriorContinuityEvidence =
  | NoContinuityEvidence
  | AvailableContinuityEvidence
  | UnavailableContinuityEvidence;

export const NO_CONTINUITY_EVIDENCE: NoContinuityEvidence = Object.freeze({
  version: 1,
  protocol: "OPAP/1",
  state: "none",
});

export const UNAVAILABLE_CONTINUITY_EVIDENCE: UnavailableContinuityEvidence =
  Object.freeze({
    version: 1,
    protocol: "OPAP/1",
    state: "unavailable",
  });

export interface CurrentKeyTransition {
  readonly epoch: number;
  readonly public_key: string;
  readonly transition_signature: string;
}

export interface CurrentUnsignedHost {
  readonly hostname: string;
  readonly binding: Binding;
  readonly authentication: "unsigned";
}

export interface CurrentOriginKeyHost {
  readonly hostname: string;
  readonly binding: Binding;
  readonly authentication: "origin-key";
  readonly epoch: number;
  readonly public_key: string;
  readonly recovery_commitment: string;
  readonly next?: CurrentKeyTransition;
  readonly previous?: CurrentKeyTransition;
}

export type CurrentContinuityHost = CurrentUnsignedHost | CurrentOriginKeyHost;

export interface CurrentContinuityOpid {
  readonly opid: string;
  readonly hostname: string;
  readonly revision: number;
  readonly record_fingerprint: `sha256:${string}`;
  readonly target_projection: JsonObject;
  readonly target_fingerprint: `sha256:${string}`;
  readonly binding: Binding;
  readonly authentication: ContinuityAuthentication;
}

export interface CurrentContinuityEvidence {
  readonly hosts: readonly CurrentContinuityHost[];
  readonly opids: readonly CurrentContinuityOpid[];
}

export interface ContinuityNodeResult {
  readonly opid: string;
  readonly history: ContinuityHistory;
  readonly continuity: Continuity;
}

export interface ContinuitySuccess {
  readonly result: "success";
  readonly node_results: readonly ContinuityNodeResult[];
  readonly proposed_evidence: AvailableContinuityEvidence;
}

export interface ContinuityFailure {
  readonly result: "error";
  readonly reason:
    | "identity_key_changed"
    | "identity_key_rollback"
    | "identity_key_transition_invalid"
    | "record_rollback"
    | "record_revision_conflict"
    | "payment_target_changed"
    | "trust_history_unavailable";
  readonly old_evidence?: AvailableContinuityEvidence;
  readonly proposed_evidence: AvailableContinuityEvidence | null;
}

export type ContinuityEvaluation = ContinuitySuccess | ContinuityFailure;

export class OpapContinuityError extends OpapError {
  readonly oldEvidence: AvailableContinuityEvidence | undefined;
  readonly proposedEvidence: AvailableContinuityEvidence | null;

  constructor(failure: ContinuityFailure) {
    super(failure.reason, continuityDiagnostic(failure));
    this.name = "OpapContinuityError";
    this.oldEvidence = failure.old_evidence;
    this.proposedEvidence = failure.proposed_evidence;
  }
}

const validateSchema =
  validateContinuityEvidenceSchema as ValidateFunction<PriorContinuityEvidence>;
const SHA256 = /^sha256:[a-f0-9]{64}$/;

function schemaDiagnostic(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? [])
    .map(
      (error) =>
        `${error.instancePath || "/"} ${error.message ?? error.keyword}`,
    )
    .join("; ");
}

function compareUtf8(left: string, right: string): number {
  const leftBytes = new TextEncoder().encode(left);
  const rightBytes = new TextEncoder().encode(right);
  const length = Math.min(leftBytes.length, rightBytes.length);
  for (let index = 0; index < length; index += 1) {
    const difference = leftBytes[index]! - rightBytes[index]!;
    if (difference !== 0) return difference;
  }
  return leftBytes.length - rightBytes.length;
}

function sortedUnique<T>(
  items: readonly T[],
  identity: (item: T) => string,
): boolean {
  const values = items.map(identity);
  return (
    new Set(values).size === values.length &&
    values.every(
      (value, index) =>
        index === 0 || compareUtf8(values[index - 1]!, value) < 0,
    )
  );
}

function deepFreeze<T>(value: T): T {
  if (typeof value !== "object" || value === null || Object.isFrozen(value)) {
    return value;
  }
  Object.freeze(value);
  for (const entry of Object.values(value)) deepFreeze(entry);
  return value;
}

function clone<T>(value: T): T {
  return structuredClone(value);
}

function invalidHistory(diagnostic: string, cause?: unknown): OpapError {
  return new OpapError("trust_history_unavailable", diagnostic, {
    ...(cause === undefined ? {} : { cause }),
  });
}

async function validateAvailableEvidence(
  envelope: AvailableContinuityEvidence,
): Promise<void> {
  if (!sortedUnique(envelope.evidence.hosts, (host) => host.hostname)) {
    throw invalidHistory("hosts_not_unique_and_sorted");
  }
  if (!sortedUnique(envelope.evidence.opids, (opid) => opid.opid)) {
    throw invalidHistory("opids_not_unique_and_sorted");
  }

  const hosts = new Map(
    envelope.evidence.hosts.map((host) => [host.hostname, host]),
  );
  const usedHostnames = new Set<string>();
  for (const host of envelope.evidence.hosts) {
    if (host.authentication !== "origin-key") continue;
    if (
      host.key_fingerprint !== (await fingerprintOriginKey(host.public_key))
    ) {
      throw invalidHistory(`key_fingerprint:${host.hostname}`);
    }
    if (host.retired_key_fingerprints.includes(host.key_fingerprint)) {
      throw invalidHistory(`current_key_retired:${host.hostname}`);
    }
    if (
      !sortedUnique(host.retired_key_fingerprints, (fingerprint) => fingerprint)
    ) {
      throw invalidHistory(`retired_keys_not_sorted:${host.hostname}`);
    }
    if (host.authenticated_next !== undefined) {
      const next = host.authenticated_next;
      if (
        next.key_fingerprint !== (await fingerprintOriginKey(next.public_key))
      ) {
        throw invalidHistory(`next_key_fingerprint:${host.hostname}`);
      }
      if (
        next.key_fingerprint === host.key_fingerprint ||
        host.retired_key_fingerprints.includes(next.key_fingerprint)
      ) {
        throw invalidHistory(`invalid_next_key:${host.hostname}`);
      }
      try {
        await verifyKeyTransition(
          host.hostname,
          host.recovery_commitment,
          host.epoch,
          host.public_key,
          next.public_key,
          next.transition_signature,
        );
      } catch (cause) {
        throw invalidHistory(`next_key_transition:${host.hostname}`, cause);
      }
      if (next.epoch !== host.epoch + 1) {
        throw invalidHistory(`next_key_epoch:${host.hostname}`);
      }
    }
  }

  for (const opid of envelope.evidence.opids) {
    let canonical: string;
    try {
      canonical = normalizeOpid(opid.opid);
    } catch (cause) {
      throw invalidHistory(`invalid_opid:${opid.opid}`, cause);
    }
    if (canonical !== opid.opid) {
      throw invalidHistory(`noncanonical_opid:${opid.opid}`);
    }
    if (new URL(opid.opid).hostname !== opid.hostname) {
      throw invalidHistory(`opid_hostname:${opid.opid}`);
    }
    const host = hosts.get(opid.hostname);
    if (host === undefined) {
      throw invalidHistory(`missing_host:${opid.opid}`);
    }
    usedHostnames.add(host.hostname);
    if (
      opid.authentication === "origin-key" &&
      host.authentication !== "origin-key"
    ) {
      throw invalidHistory(`opid_authentication:${opid.opid}`);
    }
    if (
      opid.highest_binding === "dnssec" &&
      host.highest_binding !== "dnssec"
    ) {
      throw invalidHistory(`opid_binding:${opid.opid}`);
    }
    if (
      opid.target_fingerprint !==
      fingerprintCanonicalJson(opid.target_projection)
    ) {
      throw invalidHistory(`target_fingerprint:${opid.opid}`);
    }
  }
  for (const hostname of hosts.keys()) {
    if (!usedHostnames.has(hostname)) {
      throw invalidHistory(`unused_host:${hostname}`);
    }
  }
}

export async function validateContinuityEvidence(
  value: unknown,
): Promise<PriorContinuityEvidence> {
  if (!validateSchema(value)) {
    throw invalidHistory(
      `evidence_schema:${schemaDiagnostic(validateSchema.errors)}`,
    );
  }
  const evidence = value as PriorContinuityEvidence;
  if (evidence.state === "available") {
    await validateAvailableEvidence(evidence);
  }
  return deepFreeze(clone(evidence));
}

async function validateCurrentEvidence(
  current: CurrentContinuityEvidence,
): Promise<void> {
  if (
    current.hosts.length === 0 ||
    current.opids.length === 0 ||
    !sortedUnique(current.hosts, (host) => host.hostname) ||
    !sortedUnique(current.opids, (opid) => opid.opid)
  ) {
    throw new OpapError("invalid_record", "current_evidence_order");
  }
  const hosts = new Map(current.hosts.map((host) => [host.hostname, host]));
  const usedHosts = new Set<string>();
  for (const host of current.hosts) {
    if (host.authentication === "origin-key") {
      if (!Number.isSafeInteger(host.epoch) || host.epoch < 1) {
        throw new OpapError("invalid_trust_record", `epoch:${host.hostname}`);
      }
      if (host.next !== undefined) {
        if (host.next.epoch !== host.epoch + 1) {
          throw new OpapError(
            "identity_key_transition_invalid",
            `next_epoch:${host.hostname}`,
          );
        }
        await verifyKeyTransition(
          host.hostname,
          host.recovery_commitment,
          host.epoch,
          host.public_key,
          host.next.public_key,
          host.next.transition_signature,
        );
      }
      if (host.previous !== undefined) {
        if (host.previous.epoch !== host.epoch - 1) {
          throw new OpapError(
            "identity_key_transition_invalid",
            `previous_epoch:${host.hostname}`,
          );
        }
        await verifyKeyTransition(
          host.hostname,
          host.recovery_commitment,
          host.previous.epoch,
          host.previous.public_key,
          host.public_key,
          host.previous.transition_signature,
        );
      }
    }
  }
  for (const opid of current.opids) {
    if (
      normalizeOpid(opid.opid) !== opid.opid ||
      new URL(opid.opid).hostname !== opid.hostname ||
      !Number.isSafeInteger(opid.revision) ||
      opid.revision < 1 ||
      !SHA256.test(opid.record_fingerprint) ||
      !SHA256.test(opid.target_fingerprint) ||
      opid.target_fingerprint !==
        fingerprintCanonicalJson(opid.target_projection)
    ) {
      throw new OpapError("invalid_record", `current_evidence:${opid.opid}`);
    }
    const host = hosts.get(opid.hostname);
    if (
      host === undefined ||
      host.binding !== opid.binding ||
      host.authentication !== opid.authentication
    ) {
      throw new OpapError("invalid_record", `current_host:${opid.opid}`);
    }
    usedHosts.add(host.hostname);
  }
  if (current.hosts.some((host) => !usedHosts.has(host.hostname))) {
    throw new OpapError("invalid_record", "unused_current_host");
  }
}

async function proposedHostEvidence(
  current: CurrentContinuityHost,
  prior: HostContinuityEvidence | undefined,
): Promise<HostContinuityEvidence> {
  if (current.authentication === "unsigned") {
    return {
      hostname: current.hostname,
      highest_binding: strongestBinding(
        prior?.highest_binding,
        current.binding,
      ),
      authentication: "unsigned",
    };
  }
  const currentFingerprint = await fingerprintOriginKey(current.public_key);
  const retired =
    prior?.authentication === "origin-key"
      ? [
          ...prior.retired_key_fingerprints,
          ...(prior.key_fingerprint === currentFingerprint
            ? []
            : [prior.key_fingerprint]),
        ]
      : [];
  const authenticatedNext =
    current.next === undefined
      ? prior?.authentication === "origin-key" &&
        prior.key_fingerprint === currentFingerprint
        ? prior.authenticated_next
        : undefined
      : {
          epoch: current.next.epoch,
          public_key: current.next.public_key,
          key_fingerprint: await fingerprintOriginKey(current.next.public_key),
          transition_signature: current.next.transition_signature,
        };
  return {
    hostname: current.hostname,
    highest_binding: strongestBinding(prior?.highest_binding, current.binding),
    authentication: "origin-key",
    epoch: current.epoch,
    public_key: current.public_key,
    key_fingerprint: currentFingerprint,
    recovery_commitment: current.recovery_commitment,
    ...(authenticatedNext === undefined
      ? {}
      : { authenticated_next: authenticatedNext }),
    retired_key_fingerprints: [...new Set(retired)].sort(compareUtf8),
  };
}

function proposedOpidEvidence(
  current: CurrentContinuityOpid,
  prior: OpidContinuityEvidence | undefined,
): OpidContinuityEvidence {
  return {
    opid: current.opid,
    hostname: current.hostname,
    revision: current.revision,
    record_fingerprint: current.record_fingerprint,
    target_projection: clone(current.target_projection),
    target_fingerprint: current.target_fingerprint,
    highest_binding: strongestBinding(prior?.highest_binding, current.binding),
    authentication: current.authentication,
  };
}

async function proposedEnvelope(
  current: CurrentContinuityEvidence,
  prior: AvailableContinuityEvidence | undefined,
): Promise<AvailableContinuityEvidence> {
  const priorHosts = new Map(
    (prior?.evidence.hosts ?? []).map((host) => [host.hostname, host]),
  );
  const priorOpids = new Map(
    (prior?.evidence.opids ?? []).map((opid) => [opid.opid, opid]),
  );
  return deepFreeze({
    version: 1,
    protocol: "OPAP/1",
    state: "available",
    evidence: {
      hosts: await Promise.all(
        current.hosts.map(async (host) =>
          proposedHostEvidence(host, priorHosts.get(host.hostname)),
        ),
      ),
      opids: current.opids.map((opid) =>
        proposedOpidEvidence(opid, priorOpids.get(opid.opid)),
      ),
    },
  });
}

function failure(
  reason: ContinuityFailure["reason"],
  oldEvidence?: AvailableContinuityEvidence,
  proposal?: AvailableContinuityEvidence,
): ContinuityFailure {
  return deepFreeze({
    result: "error",
    reason,
    ...(oldEvidence === undefined ? {} : { old_evidence: clone(oldEvidence) }),
    proposed_evidence: proposal === undefined ? null : clone(proposal),
  });
}

function continuityDiagnostic(failed: ContinuityFailure): string | undefined {
  if (failed.old_evidence === undefined || failed.proposed_evidence === null) {
    return undefined;
  }
  return canonicalJson({
    old_evidence: failed.old_evidence,
    proposed_evidence: failed.proposed_evidence,
  } as unknown as JsonObject);
}

export async function evaluateContinuity(
  current: CurrentContinuityEvidence,
  suppliedPrior: unknown,
): Promise<ContinuityEvaluation> {
  await validateCurrentEvidence(current);
  let prior: PriorContinuityEvidence;
  try {
    prior = await validateContinuityEvidence(suppliedPrior);
  } catch {
    return failure("trust_history_unavailable");
  }
  if (prior.state === "unavailable") {
    return failure("trust_history_unavailable");
  }

  const available = prior.state === "available" ? prior : undefined;
  const priorHosts = new Map(
    (available?.evidence.hosts ?? []).map((host) => [host.hostname, host]),
  );
  const priorOpids = new Map(
    (available?.evidence.opids ?? []).map((opid) => [opid.opid, opid]),
  );
  const hostContinuity = new Map<string, Continuity>();

  for (const host of current.hosts) {
    const previous = priorHosts.get(host.hostname);
    if (host.authentication === "unsigned") {
      if (previous?.authentication === "origin-key") {
        return failure(
          "identity_key_changed",
          available,
          await proposedEnvelope(current, available),
        );
      }
      hostContinuity.set(host.hostname, "none");
      continue;
    }
    if (previous === undefined || previous.authentication === "unsigned") {
      hostContinuity.set(host.hostname, "first-use");
      continue;
    }

    const currentFingerprint = await fingerprintOriginKey(host.public_key);
    if (host.recovery_commitment !== previous.recovery_commitment) {
      return failure("identity_key_transition_invalid");
    }
    if (
      previous.retired_key_fingerprints.includes(currentFingerprint) ||
      host.epoch < previous.epoch
    ) {
      return failure("identity_key_rollback");
    }
    if (host.epoch === previous.epoch) {
      if (currentFingerprint !== previous.key_fingerprint) {
        return failure(
          "identity_key_changed",
          available,
          await proposedEnvelope(current, available),
        );
      }
      if (
        host.next !== undefined &&
        previous.authenticated_next !== undefined &&
        (await fingerprintOriginKey(host.next.public_key)) !==
          previous.authenticated_next.key_fingerprint
      ) {
        return failure("identity_key_transition_invalid");
      }
      hostContinuity.set(host.hostname, "bound");
      continue;
    }
    if (host.epoch !== previous.epoch + 1) {
      return failure("identity_key_transition_invalid");
    }
    const acceptedStaged =
      previous.authenticated_next?.epoch === host.epoch &&
      previous.authenticated_next.key_fingerprint === currentFingerprint;
    const acceptedCatchup =
      host.previous?.epoch === previous.epoch &&
      host.previous.public_key === previous.public_key;
    if (!acceptedStaged && !acceptedCatchup) {
      return failure("identity_key_transition_invalid");
    }
    hostContinuity.set(host.hostname, "bound");
  }

  const nodeResults: ContinuityNodeResult[] = [];
  for (const opid of current.opids) {
    const previous = priorOpids.get(opid.opid);
    if (previous !== undefined) {
      if (opid.revision < previous.revision) {
        return failure("record_rollback");
      }
      if (
        opid.revision === previous.revision &&
        opid.record_fingerprint !== previous.record_fingerprint
      ) {
        return failure("record_revision_conflict");
      }
      if (opid.target_fingerprint !== previous.target_fingerprint) {
        return failure(
          "payment_target_changed",
          available,
          await proposedEnvelope(current, available),
        );
      }
    }
    nodeResults.push({
      opid: opid.opid,
      history: previous === undefined ? "none" : "available",
      continuity: hostContinuity.get(opid.hostname) ?? "none",
    });
  }

  return deepFreeze({
    result: "success",
    node_results: nodeResults,
    proposed_evidence: await proposedEnvelope(current, available),
  });
}

export function throwContinuityFailure(
  evaluation: ContinuityEvaluation,
): asserts evaluation is ContinuitySuccess {
  if (evaluation.result === "error") {
    throw new OpapContinuityError(evaluation);
  }
}
