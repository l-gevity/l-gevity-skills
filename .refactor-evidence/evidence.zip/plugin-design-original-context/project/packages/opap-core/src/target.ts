import { sha256 } from "@noble/hashes/sha2.js";

import { OpapError } from "./errors";
import type { TerminalResolution } from "./resolution";
import type { OpapRecord, PaymentOption, SplitPaymentOption } from "./types";

export type JsonPrimitive = null | boolean | number | string;
export type JsonValue =
  JsonPrimitive | readonly JsonValue[] | { readonly [key: string]: JsonValue };
export type JsonObject = { readonly [key: string]: JsonValue };

function compareUtf8(left: string, right: string): number {
  const leftBytes = new TextEncoder().encode(left);
  const rightBytes = new TextEncoder().encode(right);
  const length = Math.min(leftBytes.length, rightBytes.length);
  for (let index = 0; index < length; index += 1) {
    const difference = leftBytes[index]! - rightBytes[index]!;
    if (difference !== 0) return difference;
  }
  return leftBytes.length - rightBytes.length;
}

export interface ResolvedTargetAllocationProjection {
  readonly target: string;
  readonly share_ppm: number;
  readonly terminal_opid: string;
  readonly selected: JsonObject;
}

function isJsonValue(value: unknown): value is JsonValue {
  if (
    value === null ||
    typeof value === "boolean" ||
    typeof value === "string"
  ) {
    return true;
  }
  if (typeof value === "number") return Number.isFinite(value);
  if (Array.isArray(value)) return value.every(isJsonValue);
  if (typeof value !== "object") return false;
  return Object.entries(value).every(
    ([, entry]) => entry !== undefined && isJsonValue(entry),
  );
}

export function canonicalJson(value: JsonValue): string {
  if (
    value === null ||
    typeof value === "boolean" ||
    typeof value === "number" ||
    typeof value === "string"
  ) {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map(canonicalJson).join(",")}]`;
  }
  const entries = Object.entries(value).sort(([left], [right]) =>
    compareUtf8(left, right),
  );
  return `{${entries.map(([key, entry]) => `${JSON.stringify(key)}:${canonicalJson(entry)}`).join(",")}}`;
}

export function asJsonObject(value: unknown): JsonObject {
  if (
    !isJsonValue(value) ||
    value === null ||
    Array.isArray(value) ||
    typeof value !== "object"
  ) {
    throw new OpapError("invalid_record", "projection_not_json_object");
  }
  return value as JsonObject;
}

function logicalProjectionValue(
  value: JsonValue,
  parentKey?: string,
): JsonValue {
  if (Array.isArray(value)) {
    return value.map((entry) => logicalProjectionValue(entry, parentKey));
  }
  if (value === null || typeof value !== "object") return value;
  const objectValue = value as { readonly [key: string]: JsonValue };
  const targetAllocation =
    parentKey === "allocations" &&
    typeof objectValue.target === "string" &&
    typeof objectValue.share_ppm === "number";
  return Object.fromEntries(
    Object.entries(objectValue)
      .filter(
        ([key]) =>
          !targetAllocation || (key !== "terminal_opid" && key !== "selected"),
      )
      .map(([key, entry]) => [key, logicalProjectionValue(entry, key)]),
  );
}

/** Compares an unresolved logical projection with its compiled counterpart. */
export function isLogicalTargetProjectionOf(
  logical: JsonObject | string,
  compiled: JsonObject | string,
): boolean {
  const logicalObject =
    typeof logical === "string"
      ? asJsonObject(JSON.parse(logical) as unknown)
      : logical;
  const compiledObject =
    typeof compiled === "string"
      ? asJsonObject(JSON.parse(compiled) as unknown)
      : compiled;
  return (
    canonicalJson(logicalObject) ===
    canonicalJson(logicalProjectionValue(compiledObject))
  );
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join(
    "",
  );
}

export function fingerprintCanonicalJson(value: JsonValue): `sha256:${string}` {
  return `sha256:${bytesToHex(sha256(new TextEncoder().encode(canonicalJson(value))))}`;
}

export function paymentOptionTargetProjection(
  option: PaymentOption,
  resolvedTargets: ReadonlyMap<
    number,
    ResolvedTargetAllocationProjection
  > = new Map(),
): JsonObject {
  if (option.type === "sepa" && "iban" in option) {
    return {
      type: option.type,
      currency: option.currency,
      iban: option.iban,
    };
  }
  if (option.type === "erc20" && "recipient" in option && "asset" in option) {
    return {
      type: option.type,
      currency: option.currency,
      chain: option.chain,
      asset: option.asset.toLowerCase(),
      recipient: option.recipient.toLowerCase(),
    };
  }
  if (option.type === "split" && "execution" in option) {
    return splitOptionTargetProjection(option, resolvedTargets);
  }
  if (!("data" in option)) {
    throw new OpapError(
      "invalid_record",
      `unsupported_projection:${option.type}`,
    );
  }
  return {
    type: option.type,
    currency: option.currency,
    data: asJsonObject(option.data),
  };
}

export function splitOptionTargetProjection(
  option: SplitPaymentOption,
  resolvedTargets: ReadonlyMap<
    number,
    ResolvedTargetAllocationProjection
  > = new Map(),
): JsonObject {
  return {
    type: "split",
    currency: option.currency,
    adapter: option.execution.adapter,
    chain: option.execution.chain,
    asset: option.execution.asset.toLowerCase(),
    contract: option.execution.contract.toLowerCase(),
    config_id: option.execution.config_id.toLowerCase(),
    allocations: option.allocations.map((allocation, index) => {
      if ("recipient" in allocation) {
        return {
          recipient: allocation.recipient.toLowerCase(),
          share_ppm: allocation.share_ppm,
        };
      }
      const resolved = resolvedTargets.get(index);
      return resolved === undefined
        ? { target: allocation.target, share_ppm: allocation.share_ppm }
        : {
            target: allocation.target,
            share_ppm: allocation.share_ppm,
            terminal_opid: resolved.terminal_opid,
            selected: resolved.selected,
          };
    }),
  };
}

export function optionsTargetProjection(
  options: readonly PaymentOption[],
  selectedOverride?: {
    readonly optionIndex: number;
    readonly projection: JsonObject;
  },
): JsonObject {
  const projections = options.map((option, index) =>
    selectedOverride?.optionIndex === index
      ? selectedOverride.projection
      : paymentOptionTargetProjection(option),
  );
  projections.sort((left, right) => {
    return compareUtf8(canonicalJson(left), canonicalJson(right));
  });
  return { options: projections };
}

export function delegatedTargetProjection(
  terminalOpid: string,
  terminalProjection: JsonObject,
): JsonObject {
  return { terminal_opid: terminalOpid, target_projection: terminalProjection };
}

/** Raw validated-record projection used to detect duplicate published options. */
export function rawRecordTargetProjection(record: OpapRecord): JsonObject {
  if (record.payment.type === "delegate") {
    return { target: record.payment.target };
  }
  return optionsTargetProjection(record.payment.options);
}

/** Compatibility helper for security-history storage. */
export function terminalTargetProjection(
  input: readonly PaymentOption[] | TerminalResolution,
): string {
  const options = "options" in input ? input.options : input;
  return canonicalJson(optionsTargetProjection(options));
}

export function recordTargetProjection(
  record: OpapRecord,
  resolution: TerminalResolution,
): string {
  const terminal = optionsTargetProjection(resolution.options);
  return canonicalJson(
    record.payment.type === "delegate"
      ? delegatedTargetProjection(resolution.resolvedTo, terminal)
      : terminal,
  );
}

export async function fingerprintTargetProjection(
  projection: string | JsonObject,
): Promise<`sha256:${string}`> {
  if (typeof projection === "string") {
    return fingerprintCanonicalJson(asJsonObject(JSON.parse(projection)));
  }
  return fingerprintCanonicalJson(projection);
}
