import type { ErrorObject, ValidateFunction } from "ajv";

import { OpapError } from "./errors";
import validateSchema from "./generated/opap-schema-validator";
import { hasValidIbanChecksum } from "./iban";
import { parseJsonBytes } from "./json";
import { normalizeOpid } from "./opid";
import { canonicalJson, paymentOptionTargetProjection } from "./target";
import type { OpapRecord, PaymentOption, SepaPaymentOption } from "./types";

const validate = validateSchema as ValidateFunction<OpapRecord>;

function schemaDiagnostic(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? [])
    .map(
      (error) =>
        `${error.instancePath || "/"} ${error.message ?? error.keyword}`,
    )
    .join("; ");
}

function isSepaOption(option: PaymentOption): option is SepaPaymentOption {
  return option.type === "sepa" && "iban" in option;
}

function publicationTimestamp(value: string): number {
  const milliseconds = Date.parse(value);
  if (
    !Number.isFinite(milliseconds) ||
    new Date(milliseconds).toISOString().replace(".000Z", "Z") !== value
  ) {
    throw new OpapError(
      "invalid_record",
      `invalid_publication_timestamp:${value}`,
    );
  }
  return milliseconds;
}

export function validateOpapRecordBytes(
  bytes: Uint8Array,
  expectedOpid?: string,
): OpapRecord {
  const value = parseJsonBytes(bytes);

  if (
    typeof value === "object" &&
    value !== null &&
    "payment" in value &&
    typeof value.payment === "object" &&
    value.payment !== null &&
    "options" in value.payment &&
    Array.isArray(value.payment.options)
  ) {
    for (const candidate of value.payment.options) {
      if (
        typeof candidate !== "object" ||
        candidate === null ||
        !("type" in candidate) ||
        candidate.type !== "split" ||
        !("allocations" in candidate) ||
        !Array.isArray(candidate.allocations)
      ) {
        continue;
      }
      const targets = new Set<string>();
      for (const allocation of candidate.allocations) {
        if (typeof allocation !== "object" || allocation === null) continue;
        const recipient =
          "recipient" in allocation && typeof allocation.recipient === "string";
        const target =
          "target" in allocation && typeof allocation.target === "string";
        if (Number(recipient) + Number(target) !== 1) {
          throw new OpapError("invalid_record", "allocation_destination");
        }
        if (target) {
          const opid = allocation.target as string;
          if (normalizeOpid(opid) !== opid) {
            throw new OpapError(
              "invalid_record",
              `noncanonical_target:${opid}`,
            );
          }
          if (targets.has(opid)) {
            throw new OpapError("invalid_record", `duplicate_target:${opid}`);
          }
          targets.add(opid);
        }
      }
    }
  }

  if (
    typeof value === "object" &&
    value !== null &&
    "version" in value &&
    typeof value.version === "number" &&
    Number.isInteger(value.version) &&
    value.version !== 1
  ) {
    throw new OpapError("unsupported_version", `version:${value.version}`);
  }

  if (!validate(value)) {
    throw new OpapError("invalid_record", schemaDiagnostic(validate.errors));
  }
  const record = value as OpapRecord;
  if (
    publicationTimestamp(record.expires_at) <=
    publicationTimestamp(record.issued_at)
  ) {
    throw new OpapError("invalid_record", "expires_at_not_after_issued_at");
  }
  if (normalizeOpid(record.id) !== record.id) {
    throw new OpapError("invalid_record", `noncanonical_id:${record.id}`);
  }
  if (
    record.payment.type === "delegate" &&
    normalizeOpid(record.payment.target) !== record.payment.target
  ) {
    throw new OpapError(
      "invalid_record",
      `noncanonical_delegate_target:${record.payment.target}`,
    );
  }
  if (expectedOpid !== undefined) {
    const normalizedExpectedOpid = normalizeOpid(expectedOpid);
    if (record.id !== normalizedExpectedOpid) {
      throw new OpapError(
        "id_mismatch",
        `expected:${normalizedExpectedOpid};actual:${record.id}`,
      );
    }
  }
  if (record.payment.type === "options") {
    const optionTargets = new Set<string>();
    for (const option of record.payment.options) {
      if (isSepaOption(option) && !hasValidIbanChecksum(option.iban)) {
        throw new OpapError(
          "invalid_record",
          `invalid_iban_checksum:${option.iban}`,
        );
      }
      if (option.type === "split" && "allocations" in option) {
        const recipients = new Set<string>();
        const targets = new Set<string>();
        let totalShare = 0;
        for (const allocation of option.allocations) {
          if ("recipient" in allocation) {
            const normalizedRecipient = allocation.recipient.toLowerCase();
            if (recipients.has(normalizedRecipient)) {
              throw new OpapError(
                "invalid_record",
                `duplicate_recipient:${allocation.recipient}`,
              );
            }
            recipients.add(normalizedRecipient);
          } else {
            if (normalizeOpid(allocation.target) !== allocation.target) {
              throw new OpapError(
                "invalid_record",
                `noncanonical_target:${allocation.target}`,
              );
            }
            if (targets.has(allocation.target)) {
              throw new OpapError(
                "invalid_record",
                `duplicate_target:${allocation.target}`,
              );
            }
            targets.add(allocation.target);
          }
          totalShare += allocation.share_ppm;
        }
        if (totalShare !== 1_000_000) {
          throw new OpapError(
            "invalid_record",
            `invalid_split_share_ppm_sum:${totalShare}`,
          );
        }
      }
      const target = canonicalJson(paymentOptionTargetProjection(option));
      if (optionTargets.has(target)) {
        throw new OpapError("invalid_record", "duplicate_option_target");
      }
      optionTargets.add(target);
    }
  }

  return record;
}

export async function fingerprintRecordBytes(
  bytes: Uint8Array,
): Promise<string> {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    Uint8Array.from(bytes).buffer,
  );
  return Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}
