import type { ErrorObject, ValidateFunction } from "ajv";

import { OpapError } from "./errors";
import validateExecutionPlanSchema from "./generated/execution-plan-schema-validator";
import {
  canonicalJson,
  fingerprintCanonicalJson,
  type JsonObject,
} from "./target";

export interface PaymentAuthorization {
  readonly planFingerprint: `sha256:${string}`;
  readonly amountAtomic: bigint;
  readonly reference?: string;
  readonly approvedAt: string;
}

export interface ExecutionPlanSelection {
  readonly option_index: number;
  readonly option_projection: JsonObject;
}

export interface ExecutionPlanTransport {
  readonly profile: "strict" | "portable";
  readonly proof_source: "header" | "sidecar" | "none";
  readonly cache: "no-store" | "bounded" | "unspecified";
  readonly max_age?: number;
  readonly media_type?: string;
}

export interface ExecutionPlanNode {
  readonly opid: string;
  readonly hostname: string;
  readonly record_url: string;
  readonly revision: number;
  readonly expires_at: string;
  readonly record_fingerprint: `sha256:${string}`;
  readonly binding: "https" | "dnssec";
  readonly continuity: "none" | "first-use" | "bound";
  readonly history: "none" | "available";
  readonly transport: ExecutionPlanTransport;
  readonly origin_key?: {
    readonly fingerprint: `sha256:${string}`;
    readonly epoch: number;
  };
  readonly target_projection: JsonObject;
  readonly target_fingerprint: `sha256:${string}`;
  readonly selection?: ExecutionPlanSelection;
}

export type ExecutionPlanEdge =
  | { readonly type: "delegate"; readonly from: string; readonly to: string }
  | {
      readonly type: "allocation";
      readonly from: string;
      readonly option_index: number;
      readonly allocation_index: number;
      readonly to: string;
    };

interface ExecutionSource {
  readonly source_opid: string;
  readonly source_option_index: number;
  readonly currency: string;
}

export interface SepaExecutionInstruction extends ExecutionSource {
  readonly type: "sepa";
  readonly name: string;
  readonly iban: string;
}

export interface Erc20ExecutionInstruction extends ExecutionSource {
  readonly type: "erc20";
  readonly chain: string;
  readonly asset: string;
  readonly recipient: string;
}

export interface CompiledSplitAllocation {
  readonly recipient: string;
  readonly share_ppm: number;
}

export interface SplitExecutionInstruction extends ExecutionSource {
  readonly type: "split";
  readonly adapter: string;
  readonly chain: string;
  readonly asset: string;
  readonly contract: string;
  readonly config_id: string;
  readonly allocations: readonly CompiledSplitAllocation[];
}

export interface ExtensionExecutionInstruction extends ExecutionSource {
  readonly type: "extension";
  readonly option_type: string;
  readonly data: JsonObject;
}

export type ExecutionInstruction =
  | SepaExecutionInstruction
  | Erc20ExecutionInstruction
  | SplitExecutionInstruction
  | ExtensionExecutionInstruction;

export interface ExecutionPlan {
  readonly version: 1;
  readonly protocol: "OPAP/1";
  readonly root_opid: string;
  readonly prior_evidence: "none" | "available";
  readonly graph: {
    readonly nodes: readonly ExecutionPlanNode[];
    readonly edges: readonly ExecutionPlanEdge[];
  };
  readonly execution: ExecutionInstruction;
}

export type SepaExecutionPlan = ExecutionPlan & {
  readonly execution: SepaExecutionInstruction;
};
export type Erc20ExecutionPlan = ExecutionPlan & {
  readonly execution: Erc20ExecutionInstruction;
};
export type SplitExecutionPlan = ExecutionPlan & {
  readonly execution: SplitExecutionInstruction;
};
export type DirectExecutionPlan = SepaExecutionPlan | Erc20ExecutionPlan;

const validatePlan =
  validateExecutionPlanSchema as ValidateFunction<ExecutionPlan>;

function schemaDiagnostic(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? [])
    .map(
      (error) =>
        `${error.instancePath || "/"} ${error.message ?? error.keyword}`,
    )
    .join("; ");
}

function deepFreeze<T>(value: T): T {
  if (typeof value !== "object" || value === null || Object.isFrozen(value)) {
    return value;
  }
  Object.freeze(value);
  for (const entry of Object.values(value)) deepFreeze(entry);
  return value;
}

export function createExecutionPlan(plan: ExecutionPlan): ExecutionPlan {
  if (!validatePlan(plan)) {
    throw new OpapError(
      "invalid_record",
      `execution_plan_schema:${schemaDiagnostic(validatePlan.errors)}`,
    );
  }
  if (plan.version !== 1 || plan.protocol !== "OPAP/1") {
    throw new OpapError("invalid_record", "invalid_execution_plan_version");
  }
  const nodeIds = new Set<string>();
  for (const node of plan.graph.nodes) {
    if (nodeIds.has(node.opid))
      throw new OpapError("duplicate_opid", node.opid);
    nodeIds.add(node.opid);
    if (
      node.target_fingerprint !==
      fingerprintCanonicalJson(node.target_projection)
    ) {
      throw new OpapError("invalid_record", `target_fingerprint:${node.opid}`);
    }
    if ((node.continuity === "none") !== (node.origin_key === undefined)) {
      throw new OpapError("invalid_record", `origin_key_evidence:${node.opid}`);
    }
    if (
      plan.prior_evidence === "none" &&
      (node.history !== "none" || node.continuity === "bound")
    ) {
      throw new OpapError("invalid_record", `prior_evidence:${node.opid}`);
    }
    const expectedTransportProfile =
      node.transport.proof_source !== "sidecar" &&
      node.transport.cache === "no-store" &&
      (node.transport.media_type === "application/opap+json" ||
        node.transport.media_type === "application/json")
        ? "strict"
        : "portable";
    if (node.transport.profile !== expectedTransportProfile) {
      throw new OpapError("invalid_record", `transport_profile:${node.opid}`);
    }
    if (node.selection !== undefined) {
      const options = node.target_projection.options;
      if (
        !Array.isArray(options) ||
        !options.some(
          (option) =>
            typeof option === "object" &&
            option !== null &&
            !Array.isArray(option) &&
            canonicalJson(option) ===
              canonicalJson(node.selection!.option_projection),
        )
      ) {
        throw new OpapError(
          "invalid_record",
          `selection_projection:${node.opid}`,
        );
      }
    }
  }
  if (!nodeIds.has(plan.root_opid)) {
    throw new OpapError("invalid_record", "root_opid_missing");
  }
  for (const edge of plan.graph.edges) {
    if (!nodeIds.has(edge.from) || !nodeIds.has(edge.to)) {
      throw new OpapError("invalid_record", "dangling_execution_plan_edge");
    }
  }
  const source = plan.graph.nodes.find(
    (node) => node.opid === plan.execution.source_opid,
  );
  if (source?.selection?.option_index !== plan.execution.source_option_index) {
    throw new OpapError("invalid_record", "execution_selection_mismatch");
  }
  return deepFreeze(plan);
}

export function executionPlanFingerprint(
  plan: ExecutionPlan,
): `sha256:${string}` {
  return fingerprintCanonicalJson(plan as unknown as JsonObject);
}

export function createPaymentAuthorization(input: {
  readonly plan: ExecutionPlan;
  readonly amountAtomic: bigint;
  readonly reference?: string;
  readonly approvedAt?: string;
}): PaymentAuthorization {
  if (input.amountAtomic <= 0n)
    throw new RangeError("amountAtomic must be positive");
  const approvedAt = input.approvedAt ?? new Date().toISOString();
  if (new Date(approvedAt).toISOString() !== approvedAt) {
    throw new TypeError("approvedAt must be an ISO timestamp");
  }
  return Object.freeze({
    planFingerprint: executionPlanFingerprint(input.plan),
    amountAtomic: input.amountAtomic,
    ...(input.reference === undefined ? {} : { reference: input.reference }),
    approvedAt,
  });
}

function executionIdentity(plan: ExecutionPlan): string {
  return canonicalJson({
    root_opid: plan.root_opid,
    prior_evidence: plan.prior_evidence,
    graph: {
      nodes: plan.graph.nodes.map((node) => ({
        opid: node.opid,
        binding: node.binding,
        continuity: node.continuity,
        history: node.history,
        ...(node.origin_key === undefined
          ? {}
          : { origin_key: node.origin_key }),
        target_projection: node.target_projection,
        target_fingerprint: node.target_fingerprint,
        ...(node.selection === undefined ? {} : { selection: node.selection }),
      })),
      edges: plan.graph.edges,
    },
    execution: plan.execution,
  } as unknown as JsonObject);
}

/** Allows freshness-only record metadata changes, but no trust or recipient change. */
export function assertExecutionPlanUnchanged(
  reviewed: ExecutionPlan,
  candidate: ExecutionPlan,
): void {
  if (executionIdentity(reviewed) !== executionIdentity(candidate)) {
    throw new OpapError("execution_changed");
  }
}
