import {
  NO_CONTINUITY_EVIDENCE,
  validateContinuityEvidence,
  type AvailableContinuityEvidence,
  type HostContinuityEvidence,
  type OpidContinuityEvidence,
  type PriorContinuityEvidence,
} from "./continuity";
import { fingerprintOriginKey } from "./trust";
import type { JsonObject } from "./target";
import type { Binding } from "./verification";

function plainRecord(
  value: unknown,
): value is Readonly<Record<string, unknown>> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function jsonObject(value: unknown): JsonObject {
  if (!plainRecord(value)) throw new Error("target_projection");
  return value as JsonObject;
}

function strongest(left: Binding | undefined, right: Binding): Binding {
  return left === "dnssec" || right === "dnssec" ? "dnssec" : "https";
}

function compareIdentity(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

/**
 * Converts the pre-evidence continuity shape used by the first CLI and browser
 * releases. Storage adapters still own version detection, locking, and writes.
 */
export async function migrateLegacyContinuityHistory(
  history: Readonly<Record<string, unknown>>,
): Promise<PriorContinuityEvidence> {
  if (!plainRecord(history.pins) || !plainRecord(history.opids)) {
    throw new Error("legacy_shape");
  }
  if (
    Object.keys(history.pins).length === 0 &&
    Object.keys(history.opids).length === 0
  ) {
    return NO_CONTINUITY_EVIDENCE;
  }

  const opids: OpidContinuityEvidence[] = [];
  const hostBindings = new Map<string, Binding>();
  for (const [opid, candidate] of Object.entries(history.opids)) {
    if (!plainRecord(candidate)) throw new Error(`legacy_opid:${opid}`);
    const hostname = new URL(opid).hostname;
    const binding = candidate.highestBinding;
    if (binding !== "https" && binding !== "dnssec") {
      throw new Error(`legacy_binding:${opid}`);
    }
    const projection =
      typeof candidate.targetProjection === "string"
        ? jsonObject(JSON.parse(candidate.targetProjection) as unknown)
        : jsonObject(candidate.targetProjection);
    if (
      typeof candidate.recordFingerprint !== "string" ||
      typeof candidate.targetFingerprint !== "string" ||
      typeof candidate.revision !== "number"
    ) {
      throw new Error(`legacy_opid_fields:${opid}`);
    }
    opids.push({
      opid,
      hostname,
      revision: candidate.revision,
      record_fingerprint: (candidate.recordFingerprint.startsWith("sha256:")
        ? candidate.recordFingerprint
        : `sha256:${candidate.recordFingerprint}`) as `sha256:${string}`,
      target_projection: projection,
      target_fingerprint: candidate.targetFingerprint as `sha256:${string}`,
      highest_binding: binding,
      authentication: Object.hasOwn(history.pins, hostname)
        ? "origin-key"
        : "unsigned",
    });
    hostBindings.set(hostname, strongest(hostBindings.get(hostname), binding));
  }

  const hosts = new Map<string, HostContinuityEvidence>();
  for (const opid of opids) {
    if (opid.authentication === "unsigned") {
      hosts.set(opid.hostname, {
        hostname: opid.hostname,
        highest_binding: hostBindings.get(opid.hostname) ?? "https",
        authentication: "unsigned",
      });
    }
  }
  for (const [hostname, candidate] of Object.entries(history.pins)) {
    if (
      !plainRecord(candidate) ||
      typeof candidate.epoch !== "number" ||
      typeof candidate.ed25519 !== "string" ||
      typeof candidate.recoveryCommitment !== "string" ||
      !Array.isArray(candidate.retiredKeyFingerprints)
    ) {
      throw new Error(`legacy_pin:${hostname}`);
    }
    if (candidate.authenticatedNext !== undefined) {
      throw new Error(`legacy_staged_key_requires_reset:${hostname}`);
    }
    if (!hostBindings.has(hostname)) {
      throw new Error(`legacy_orphan_pin:${hostname}`);
    }
    hosts.set(hostname, {
      hostname,
      highest_binding: hostBindings.get(hostname) ?? "https",
      authentication: "origin-key",
      epoch: candidate.epoch,
      public_key: candidate.ed25519,
      key_fingerprint: await fingerprintOriginKey(candidate.ed25519),
      recovery_commitment: candidate.recoveryCommitment,
      retired_key_fingerprints:
        candidate.retiredKeyFingerprints as `sha256:${string}`[],
    });
  }

  return await validateContinuityEvidence({
    version: 1,
    protocol: "OPAP/1",
    state: "available",
    evidence: {
      hosts: [...hosts.values()].sort((left, right) =>
        compareIdentity(left.hostname, right.hostname),
      ),
      opids: opids.sort((left, right) =>
        compareIdentity(left.opid, right.opid),
      ),
    },
  });
}

/** Merge a resolver proposal into the latest persisted evidence snapshot. */
export async function mergeContinuityEvidence(
  current: PriorContinuityEvidence,
  proposed: AvailableContinuityEvidence,
): Promise<AvailableContinuityEvidence> {
  const hosts = new Map(
    (current.state === "available" ? current.evidence.hosts : []).map(
      (host) => [host.hostname, host],
    ),
  );
  const opids = new Map(
    (current.state === "available" ? current.evidence.opids : []).map(
      (opid) => [opid.opid, opid],
    ),
  );
  for (const host of proposed.evidence.hosts) hosts.set(host.hostname, host);
  for (const opid of proposed.evidence.opids) opids.set(opid.opid, opid);
  return (await validateContinuityEvidence({
    version: 1,
    protocol: "OPAP/1",
    state: "available",
    evidence: {
      hosts: [...hosts.values()].sort((left, right) =>
        compareIdentity(left.hostname, right.hostname),
      ),
      opids: [...opids.values()].sort((left, right) =>
        compareIdentity(left.opid, right.opid),
      ),
    },
  })) as AvailableContinuityEvidence;
}
