export { decimalAmountToAtomicUnits } from "./amount";
export {
  evaluateContinuity,
  NO_CONTINUITY_EVIDENCE,
  OpapContinuityError,
  throwContinuityFailure,
  UNAVAILABLE_CONTINUITY_EVIDENCE,
  validateContinuityEvidence,
  type AuthenticatedNextEvidence,
  type AvailableContinuityEvidence,
  type ContinuityAuthentication,
  type ContinuityEvaluation,
  type ContinuityFailure,
  type ContinuityHistory,
  type ContinuityNodeResult,
  type ContinuitySuccess,
  type CurrentContinuityEvidence,
  type CurrentContinuityHost,
  type CurrentContinuityOpid,
  type CurrentKeyTransition,
  type CurrentOriginKeyHost,
  type CurrentUnsignedHost,
  type HostContinuityEvidence,
  type NoContinuityEvidence,
  type OpidContinuityEvidence,
  type OriginKeyHostEvidence,
  type PriorContinuityEvidence,
  type UnavailableContinuityEvidence,
  type UnsignedHostEvidence,
} from "./continuity";
export {
  mergeContinuityEvidence,
  migrateLegacyContinuityHistory,
} from "./continuity-history";
export {
  resolveAssetProfile,
  validateAssetRegistry,
  type AssetProfile,
  type AssetRegistry,
  type AssetRegistryEntry,
} from "./assets";
export { OPAP_ERROR_CODES, OpapError, type OpapErrorCode } from "./errors";
export {
  assertExecutionPlanUnchanged,
  createExecutionPlan,
  createPaymentAuthorization,
  executionPlanFingerprint,
  type CompiledSplitAllocation,
  type DirectExecutionPlan,
  type Erc20ExecutionPlan,
  type ExecutionPlan,
  type ExecutionPlanEdge,
  type ExecutionPlanNode,
  type ExecutionPlanTransport,
  type ExecutionInstruction,
  type PaymentAuthorization,
  type SepaExecutionPlan,
  type SplitExecutionPlan,
  type SplitExecutionInstruction,
} from "./execution-plan";
export { MAX_RECORD_BYTES } from "./json";
export { formatSha256Fingerprint, isSha256Hex } from "./fingerprint";
export { derivePathKey, deriveRecordUrl, normalizeOpid } from "./opid";
export { fingerprintRecordBytes, validateOpapRecordBytes } from "./record";
export {
  MAX_DELEGATE_HOPS,
  MAX_RESOLUTION_RECORDS,
  advanceResolution,
  createResolutionState,
  type OptionsResolution,
  type PendingResolution,
  type ResolutionEvidence,
  type ResolutionRecord,
  type ResolutionStep,
  type TerminalResolution,
} from "./resolution";
export { buildSepaHandoff, type SepaHandoff } from "./sepa";
export {
  MAX_SUPPORTED_SPLIT_RECIPIENTS,
  OPAP_SPLIT_ADAPTER,
  allocateSplitAmount,
  deriveSplitConfigId,
  verifySplitContractState,
  type SplitAllocation,
  type SplitContractState,
  type TerminalSplitAllocationEntry,
} from "./split";
export {
  advanceOriginKeyPin,
  createRecoveryCommitment,
  fingerprintOriginKey,
  keyTransitionMessage,
  originTrustName,
  parseTrustRecord,
  selectTrustRecord,
  verifyKeyTransition,
  verifyRecordProof,
  type AuthenticatedNextKey,
  type OriginKeyPin,
  type OriginTrustDecision,
  type TrustRecord,
} from "./trust";
export {
  fingerprintTargetProjection,
  fingerprintCanonicalJson,
  isLogicalTargetProjectionOf,
  canonicalJson,
  delegatedTargetProjection,
  optionsTargetProjection,
  paymentOptionTargetProjection,
  rawRecordTargetProjection,
  recordTargetProjection,
  splitOptionTargetProjection,
  terminalTargetProjection,
  type JsonObject,
  type JsonValue,
  type ResolvedTargetAllocationProjection,
} from "./target";
export type {
  DelegatePayment,
  Erc20PaymentOption,
  ExtensionPaymentOption,
  OpapRecord,
  OptionsPayment,
  PaymentOption,
  SepaPaymentOption,
  SplitAllocationEntry,
  SplitExecution,
  SplitPaymentOption,
} from "./types";
export {
  strongestBinding,
  validateRecordFreshness,
  validateRecordRevision,
  type Binding,
  type Continuity,
  type OpidSecurityHistoryEntry,
  type VerificationEvidence,
} from "./verification";
