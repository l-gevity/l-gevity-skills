import {
  OpapError,
  assertExecutionPlanUnchanged,
  createExecutionPlan,
  delegatedTargetProjection,
  fingerprintCanonicalJson,
  formatSha256Fingerprint,
  optionsTargetProjection,
  paymentOptionTargetProjection,
  splitOptionTargetProjection,
  type AvailableContinuityEvidence,
  type CurrentContinuityEvidence,
  type ExecutionPlan,
  type ExecutionPlanEdge,
  type ExecutionPlanNode,
  type JsonObject,
  type PriorContinuityEvidence,
  type SplitPaymentOption,
} from "@opap/core";

import {
  evaluateResolutionChains,
  type LiveResolution,
  type RawLiveResolution,
  type ResolutionChain,
} from "./evidence";
import { createDecodedByteBudget } from "./https";
import {
  OPAP_GRAPH_LIMITS,
  resolveOpidRaw,
  usablePriorEvidence,
  validateResolutionTimeout,
  type ResolutionOptions,
} from "./resolve";
import { createTimeoutSignal } from "./timeout";

export interface ResolvedExecutionPlan {
  readonly plan: ExecutionPlan;
  readonly root: LiveResolution;
  readonly targets: readonly LiveResolution[];
  readonly priorEvidence: PriorContinuityEvidence;
  readonly currentEvidence: CurrentContinuityEvidence;
  readonly proposedEvidence: AvailableContinuityEvidence;
}

function selectedOption(resolution: RawLiveResolution, optionIndex: number) {
  if (!Number.isInteger(optionIndex)) {
    throw new OpapError("no_supported_method", `index:${optionIndex}`);
  }
  const option = resolution.options[optionIndex];
  if (option === undefined) {
    throw new OpapError("no_supported_method", `index:${optionIndex}`);
  }
  return option;
}

function chainEdges(
  resolution: RawLiveResolution,
): readonly ExecutionPlanEdge[] {
  return resolution.publications.slice(0, -1).map((publication, index) => {
    const next = resolution.publications[index + 1];
    if (publication.record.payment.type !== "delegate" || next === undefined) {
      throw new OpapError("invalid_record", "invalid_delegation_chain");
    }
    return Object.freeze({
      type: "delegate" as const,
      from: publication.opid,
      to: next.opid,
    });
  });
}

function chainNodes(chain: {
  readonly resolution: LiveResolution;
  readonly projection: JsonObject;
  readonly selection?: {
    readonly option_index: number;
    readonly option_projection: JsonObject;
  };
}): readonly ExecutionPlanNode[] {
  return chain.resolution.publications.map((publication) => {
    const terminal = publication.opid === chain.resolution.resolvedTo;
    const projection = terminal
      ? chain.projection
      : delegatedTargetProjection(
          chain.resolution.resolvedTo,
          chain.projection,
        );
    const verification = publication.verification;
    return Object.freeze({
      opid: publication.opid,
      hostname: new URL(publication.opid).hostname,
      record_url: publication.url,
      revision: publication.record.revision,
      expires_at: publication.record.expires_at,
      record_fingerprint: formatSha256Fingerprint(publication.fingerprint),
      binding: verification.binding,
      continuity: verification.continuity,
      history: verification.history ?? "none",
      transport: publication.transport,
      ...(verification.continuity === "none"
        ? {}
        : {
            origin_key: {
              fingerprint: verification.keyFingerprint!,
              epoch: verification.keyEpoch!,
            },
          }),
      target_projection: projection,
      target_fingerprint: fingerprintCanonicalJson(projection),
      ...(terminal && chain.selection !== undefined
        ? { selection: chain.selection }
        : {}),
    });
  });
}

function sameAddress(left: string, right: string): boolean {
  return left.toLowerCase() === right.toLowerCase();
}

function compatibleTargetIndex(
  resolution: RawLiveResolution,
  split: SplitPaymentOption,
): number {
  const index = resolution.options.findIndex(
    (option) =>
      option.type === "erc20" &&
      "recipient" in option &&
      option.currency === split.currency &&
      option.chain === split.execution.chain &&
      sameAddress(option.asset, split.execution.asset),
  );
  if (index >= 0) return index;
  const nested = resolution.options.some(
    (option) =>
      option.type === "split" &&
      "execution" in option &&
      option.currency === split.currency &&
      option.execution.type === split.execution.type &&
      option.execution.adapter === split.execution.adapter &&
      option.execution.chain === split.execution.chain &&
      sameAddress(option.execution.asset, split.execution.asset),
  );
  throw new OpapError(
    nested ? "nested_split_unsupported" : "split_target_incompatible",
    resolution.source,
  );
}

function assertGraphBounds(
  root: RawLiveResolution,
  targets: readonly RawLiveResolution[],
): void {
  const all = [root, ...targets];
  const nodeCount = all.reduce(
    (total, resolution) => total + resolution.publications.length,
    0,
  );
  const bodyBytes = all.reduce(
    (total, resolution) =>
      total +
      resolution.publications.reduce(
        (subtotal, publication) => subtotal + publication.retrievedBodyBytes,
        0,
      ),
    0,
  );
  if (
    nodeCount > OPAP_GRAPH_LIMITS.distinct_opids ||
    bodyBytes > OPAP_GRAPH_LIMITS.fetched_body_bytes
  ) {
    throw new OpapError("resolution_limit_exceeded", "graph_budget");
  }
  for (const target of targets) {
    if (
      root.publications.length + target.publications.length - 1 >
      OPAP_GRAPH_LIMITS.max_path_edges
    ) {
      throw new OpapError("resolution_limit_exceeded", "path_edges");
    }
  }
}

async function compileExecutionPlanRaw(
  root: RawLiveResolution,
  optionIndex: number,
  options: ResolutionOptions,
): Promise<ResolvedExecutionPlan> {
  const selected = selectedOption(root, optionIndex);
  const targets: RawLiveResolution[] = [];
  const allocationEdges: ExecutionPlanEdge[] = [];
  const targetChains: ResolutionChain[] = [];
  const visited = new Set(
    root.publications.map((publication) => publication.opid),
  );
  const resolvedTargets = new Map<
    number,
    {
      readonly target: string;
      readonly share_ppm: number;
      readonly terminal_opid: string;
      readonly selected: JsonObject;
    }
  >();
  const compiledAllocations: { recipient: string; share_ppm: number }[] = [];

  if (selected.type === "split" && "execution" in selected) {
    const targetCount = selected.allocations.filter(
      (allocation) => "target" in allocation,
    ).length;
    const totalLeaves = root.options.reduce(
      (total, option) =>
        total +
        (option.type === "split" && "allocations" in option
          ? option.allocations.length
          : 0),
      0,
    );
    if (
      targetCount > OPAP_GRAPH_LIMITS.allocation_targets_per_split ||
      selected.allocations.length >
        OPAP_GRAPH_LIMITS.terminal_leaves_per_split ||
      totalLeaves > OPAP_GRAPH_LIMITS.terminal_leaves
    ) {
      throw new OpapError("resolution_limit_exceeded", "allocation_leaves");
    }
    for (const [
      allocationIndex,
      allocation,
    ] of selected.allocations.entries()) {
      if ("recipient" in allocation) {
        compiledAllocations.push({
          recipient: allocation.recipient.toLowerCase(),
          share_ppm: allocation.share_ppm,
        });
        continue;
      }
      if (options.fetch === undefined) {
        throw new OpapError(
          "target_address_forbidden",
          "hardened_graph_fetch_required",
        );
      }
      const target = await resolveOpidRaw(allocation.target, options, {
        activePath: new Set(
          root.publications.map((publication) => publication.opid),
        ),
        visited,
      });
      for (const publication of target.publications) {
        visited.add(publication.opid);
      }
      const selectedIndex = compatibleTargetIndex(target, selected);
      const targetOption = target.options[selectedIndex]!;
      if (targetOption.type !== "erc20" || !("recipient" in targetOption)) {
        throw new OpapError("split_target_incompatible", allocation.target);
      }
      const selectedProjection = paymentOptionTargetProjection(targetOption);
      const targetProjection = optionsTargetProjection(target.options);
      targets.push(target);
      targetChains.push({
        resolution: target,
        projection: targetProjection,
        selection: {
          option_index: selectedIndex,
          option_projection: selectedProjection,
        },
      });
      allocationEdges.push({
        type: "allocation",
        from: root.resolvedTo,
        option_index: optionIndex,
        allocation_index: allocationIndex,
        to: allocation.target,
      });
      resolvedTargets.set(allocationIndex, {
        target: allocation.target,
        share_ppm: allocation.share_ppm,
        terminal_opid: target.resolvedTo,
        selected: selectedProjection,
      });
      compiledAllocations.push({
        recipient: targetOption.recipient.toLowerCase(),
        share_ppm: allocation.share_ppm,
      });
    }
    const recipients = new Set<string>();
    for (const allocation of compiledAllocations) {
      if (recipients.has(allocation.recipient)) {
        throw new OpapError("split_recipient_collision", allocation.recipient);
      }
      recipients.add(allocation.recipient);
    }
  }

  assertGraphBounds(root, targets);
  const selectedProjection =
    selected.type === "split" && "execution" in selected
      ? splitOptionTargetProjection(selected, resolvedTargets)
      : paymentOptionTargetProjection(selected);
  const rootProjection = optionsTargetProjection(root.options, {
    optionIndex,
    projection: selectedProjection,
  });
  const rootChain: ResolutionChain = {
    resolution: root,
    projection: rootProjection,
    selection: {
      option_index: optionIndex,
      option_projection: selectedProjection,
    },
  };
  const evaluated = await evaluateResolutionChains(
    [rootChain, ...targetChains],
    options.priorEvidence,
  );
  const evaluatedRoot = evaluated.resolutions[0]!;
  const evaluatedTargets = evaluated.resolutions.slice(1);

  const nodes: ExecutionPlanNode[] = [
    ...chainNodes({
      resolution: evaluatedRoot,
      projection: rootProjection,
      ...(rootChain.selection === undefined
        ? {}
        : { selection: rootChain.selection }),
    }),
  ];
  const edges: ExecutionPlanEdge[] = [...chainEdges(root)];
  targetChains.forEach((chain, index) => {
    edges.push(allocationEdges[index]!);
    nodes.push(
      ...chainNodes({
        resolution: evaluatedTargets[index]!,
        projection: chain.projection,
        ...(chain.selection === undefined
          ? {}
          : { selection: chain.selection }),
      }),
    );
    edges.push(...chainEdges(chain.resolution));
  });

  const source = {
    source_opid: root.resolvedTo,
    source_option_index: optionIndex,
    currency: selected.currency,
  };
  let execution: ExecutionPlan["execution"];
  if (selected.type === "sepa" && "iban" in selected) {
    execution = {
      ...source,
      type: "sepa",
      name: selected.name,
      iban: selected.iban,
    };
  } else if (selected.type === "erc20" && "recipient" in selected) {
    execution = {
      ...source,
      type: "erc20",
      chain: selected.chain,
      asset: selected.asset.toLowerCase(),
      recipient: selected.recipient.toLowerCase(),
    };
  } else if (selected.type === "split" && "execution" in selected) {
    execution = {
      ...source,
      type: "split",
      adapter: selected.execution.adapter,
      chain: selected.execution.chain,
      asset: selected.execution.asset.toLowerCase(),
      contract: selected.execution.contract.toLowerCase(),
      config_id: selected.execution.config_id.toLowerCase(),
      allocations: compiledAllocations,
    };
  } else {
    throw new OpapError("no_supported_method", `option:${selected.type}`);
  }

  return Object.freeze({
    plan: createExecutionPlan({
      version: 1,
      protocol: "OPAP/1",
      root_opid: root.source,
      prior_evidence:
        options.priorEvidence.state === "available" ? "available" : "none",
      graph: { nodes, edges },
      execution,
    }),
    root: evaluatedRoot,
    targets: Object.freeze(evaluatedTargets),
    priorEvidence: options.priorEvidence,
    currentEvidence: evaluated.currentEvidence,
    proposedEvidence: evaluated.proposedEvidence,
  });
}

function rawFromLive(resolution: LiveResolution): RawLiveResolution {
  const hosts = new Map(
    resolution.currentEvidence.hosts.map((host) => [host.hostname, host]),
  );
  return Object.freeze({
    ...resolution,
    publications: Object.freeze(
      resolution.publications.map((publication) => {
        const currentHost = hosts.get(publication.verification.hostname);
        if (currentHost === undefined) {
          throw new OpapError(
            "trust_history_unavailable",
            `missing_current_host:${publication.opid}`,
          );
        }
        return Object.freeze({ ...publication, currentHost });
      }),
    ),
  });
}

/**
 * Compiles a caller-selected option from an already resolved root.
 *
 * Split targets are resolved through the caller-supplied runtime adapters.
 */
export async function compileExecutionPlan(
  root: LiveResolution,
  optionIndex: number,
  options: ResolutionOptions,
): Promise<ResolvedExecutionPlan> {
  const decodedByteBudget =
    options.decodedByteBudget ??
    createDecodedByteBudget(
      OPAP_GRAPH_LIMITS.fetched_body_bytes,
      root.publications.reduce(
        (total, publication) => total + publication.retrievedBodyBytes,
        0,
      ),
    );
  return compileExecutionPlanRaw(rawFromLive(root), optionIndex, {
    ...options,
    priorEvidence: await usablePriorEvidence(options.priorEvidence),
    decodedByteBudget,
  });
}

/** Resolves an OPID and compiles the caller-selected option in one operation. */
export async function resolveExecutionPlan(
  input: string,
  optionIndex: number,
  options: ResolutionOptions,
): Promise<ResolvedExecutionPlan> {
  const priorEvidence = await usablePriorEvidence(options.priorEvidence);
  const validatedOptions = {
    ...options,
    priorEvidence,
    decodedByteBudget:
      options.decodedByteBudget ??
      createDecodedByteBudget(OPAP_GRAPH_LIMITS.fetched_body_bytes),
  };
  const timeout = createTimeoutSignal(
    validateResolutionTimeout(validatedOptions),
    options.signal,
  );
  try {
    return await compileExecutionPlanRaw(
      await resolveOpidRaw(input, {
        ...validatedOptions,
        signal: timeout.signal,
      }),
      optionIndex,
      {
        ...validatedOptions,
        signal: timeout.signal,
      },
    );
  } catch (cause) {
    if (
      options.signal?.aborted !== true &&
      timeout.signal.aborted &&
      timeout.signal.reason instanceof DOMException &&
      timeout.signal.reason.name === "TimeoutError"
    ) {
      throw new OpapError("resolution_limit_exceeded", "elapsed_ms", {
        cause,
      });
    }
    throw cause;
  } finally {
    timeout.dispose();
  }
}

/** Resolves the payer-selected OPID again immediately before execution. */
export async function reResolveAndCompare(
  plan: ExecutionPlan,
  options: ResolutionOptions,
): Promise<ResolvedExecutionPlan> {
  const candidate = await resolveExecutionPlan(
    plan.root_opid,
    plan.execution.source_option_index,
    options,
  );
  assertExecutionPlanUnchanged(plan, candidate.plan);
  return candidate;
}
