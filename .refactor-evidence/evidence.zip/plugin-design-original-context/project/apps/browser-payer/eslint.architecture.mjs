export default {
  components: [
    {
      name: "payer-composition",
      pattern: "apps/browser-payer/ts/userinterface/main.ts",
      mode: "file",
    },
    {
      name: "payer-routing",
      pattern: "apps/browser-payer/ts/paymentrouting/**",
    },
    {
      name: "payer-execution",
      pattern: "apps/browser-payer/ts/paymentexecution/**",
    },
    { name: "payer-policy", pattern: "apps/browser-payer/ts/policy/**" },
    {
      name: "payer-resolution",
      pattern: "apps/browser-payer/ts/resolution/**",
    },
    { name: "payer-storage", pattern: "apps/browser-payer/ts/storage/**" },
    { name: "payer-fixtures", pattern: "apps/browser-payer/fixtures/**" },
    { name: "payer-tooling", pattern: "apps/browser-payer/scripts/**" },
    { name: "payer-tests", pattern: "apps/browser-payer/test/**" },
    { name: "payer-edge", pattern: "apps/browser-payer/ts/edge/**" },
    {
      name: "payer-interface",
      pattern: "apps/browser-payer/ts/userinterface/**",
    },
    { name: "payer-app", pattern: "apps/browser-payer/**" },
  ],
  forbidden: [
    {
      from: "payer-interface",
      to: "payer-composition",
      why: "The Browser Payer composition root wires focused UI modules and must never become their dependency.",
    },
    {
      from: "payer-routing",
      to: "payer-*",
      except_to: ["payer-routing", "payer-policy"],
      why: "Payment routing is a pure decision boundary and may depend only on release policy.",
    },
    {
      from: "payer-execution",
      to: "payer-*",
      except_to: ["payer-execution", "payer-routing", "payer-policy"],
      why: "Wallet execution may consume reviewed payment plans and release policy but not UI, resolution or edge infrastructure.",
    },
    {
      from: "payer-policy",
      to: "payer-*",
      except_to: ["payer-policy"],
      why: "Release policy must remain independent from Browser Payer behavior.",
    },
    {
      from: "payer-resolution",
      to: "payer-*",
      except_to: ["payer-resolution", "payer-storage", "payer-fixtures"],
      why: "Browser resolution may depend on browser storage but not UI, payment execution or policy.",
    },
    {
      from: "payer-storage",
      to: "payer-*",
      except_to: ["payer-storage"],
      why: "Browser persistence must remain independent from UI and application orchestration.",
    },
    {
      from: "payer-edge",
      to: "payer-*",
      except_to: ["payer-edge"],
      why: "The Cloudflare transport boundary may use the OPAP runtime facade but must not depend on another Browser Payer module.",
    },
    {
      from: "payer-*",
      except: ["payer-edge", "payer-tests"],
      to: "payer-edge",
      why: "Browser code must reach the Cloudflare transport boundary only through its same-origin HTTP contract.",
    },
  ],
};
