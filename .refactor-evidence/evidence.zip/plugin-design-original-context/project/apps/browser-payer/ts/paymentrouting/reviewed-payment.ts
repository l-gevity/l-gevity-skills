import {
  allocateSplitAmount,
  decimalAmountToAtomicUnits,
  OpapError,
  resolveAssetProfile,
  type AssetProfile,
  type AssetRegistry,
  type Erc20ExecutionPlan,
  type ExecutionPlan,
  type OptionsResolution,
  type PaymentOption,
  type PriorContinuityEvidence,
  type SepaExecutionPlan,
  type SplitContractState,
  type SplitExecutionPlan,
} from "@opap/core";

import {
  browserPayerRegistry,
  type BrowserPayerRegistry,
} from "../policy/browser-payer-registry";

interface ReviewedPaymentBase {
  readonly amount: string;
  readonly amountAtomic: bigint;
  readonly reference?: string;
  readonly priorEvidence: PriorContinuityEvidence;
}

export interface ReviewedSepaPayment extends ReviewedPaymentBase {
  readonly type: "sepa";
  readonly plan: SepaExecutionPlan;
}

export interface ReviewedErc20Payment extends ReviewedPaymentBase {
  readonly type: "erc20";
  readonly plan: Erc20ExecutionPlan;
  readonly assetProfile: AssetProfile;
}

export interface ReviewedSplitPayment extends ReviewedPaymentBase {
  readonly type: "split";
  readonly plan: SplitExecutionPlan;
  readonly assetProfile: AssetProfile;
  readonly adapterState: SplitContractState;
  readonly allocations: readonly {
    readonly recipient: string;
    readonly sharePpm: number;
    readonly atomicAmount: string;
  }[];
}

export type ReviewedPayment =
  ReviewedSepaPayment | ReviewedErc20Payment | ReviewedSplitPayment;
export type ReviewedOnchainPayment =
  ReviewedErc20Payment | ReviewedSplitPayment;

export interface ReviewedPaymentInput {
  readonly plan: ExecutionPlan;
  readonly amount: string;
  readonly currency: string;
  readonly reference?: string;
  readonly priorEvidence: PriorContinuityEvidence;
  readonly adapterState?: SplitContractState;
}

export interface ExecutablePaymentOption {
  readonly index: number;
  readonly option: PaymentOption;
  readonly assetProfile?: AssetProfile;
  readonly splitState?: SplitContractState;
}

export function buildReviewedPayment(
  input: ReviewedPaymentInput,
  registry: AssetRegistry = browserPayerRegistry,
): ReviewedPayment {
  const amount = input.amount.trim();
  const reference = input.reference?.trim();
  if (input.plan.execution.currency !== input.currency) {
    throw new OpapError("no_supported_method", "currency");
  }
  const common = {
    amount,
    priorEvidence: input.priorEvidence,
    ...(reference === undefined || reference.length === 0 ? {} : { reference }),
  };

  if (input.plan.execution.type === "sepa") {
    return Object.freeze({
      ...common,
      type: "sepa",
      plan: input.plan as SepaExecutionPlan,
      amountAtomic: decimalAmountToAtomicUnits(amount, 2),
    });
  }
  if (
    input.plan.execution.type !== "erc20" &&
    input.plan.execution.type !== "split"
  ) {
    throw new OpapError("no_supported_method", input.plan.execution.type);
  }

  const assetProfile = resolveAssetProfile(
    registry,
    input.plan.execution,
    input.currency,
  );
  const amountAtomic = decimalAmountToAtomicUnits(
    amount,
    assetProfile.decimals,
  );
  if (input.plan.execution.type === "split") {
    if (input.adapterState === undefined) {
      throw new OpapError("split_config_mismatch", "not_validated");
    }
    return Object.freeze({
      ...common,
      type: "split",
      plan: input.plan as SplitExecutionPlan,
      amountAtomic,
      assetProfile,
      adapterState: input.adapterState,
      allocations: allocateSplitAmount(
        amountAtomic,
        input.plan.execution.allocations,
      ),
    });
  }
  return Object.freeze({
    ...common,
    type: "erc20",
    plan: input.plan as Erc20ExecutionPlan,
    amountAtomic,
    assetProfile,
  });
}

export function executablePaymentOptions(
  resolution: OptionsResolution,
  registry: BrowserPayerRegistry = browserPayerRegistry,
  splitStates: ReadonlyMap<number, SplitContractState> = new Map(),
): readonly ExecutablePaymentOption[] {
  const executable: ExecutablePaymentOption[] = [];
  resolution.options.forEach((option, index) => {
    if (option.type === "sepa" && "iban" in option) {
      executable.push({ index, option });
      return;
    }
    if (option.type === "split" && "execution" in option) {
      const splitState = splitStates.get(index);
      const adapter = registry.splitAdapters.find(
        (candidate) =>
          candidate.status === "active" &&
          candidate.adapter === option.execution.adapter &&
          candidate.chain === option.execution.chain &&
          candidate.contract.toLowerCase() ===
            option.execution.contract.toLowerCase(),
      );
      if (adapter === undefined) return;
      try {
        executable.push({
          index,
          option,
          ...(splitState === undefined ? {} : { splitState }),
          assetProfile: resolveAssetProfile(
            registry,
            { ...option.execution, currency: option.currency },
            option.currency,
          ),
        });
      } catch (cause) {
        if (cause instanceof OpapError) return;
        throw cause;
      }
      return;
    }
    if (option.type !== "erc20" || !("recipient" in option)) return;
    const chain = registry.chains.find(
      (candidate) =>
        candidate.caip2 === option.chain && candidate.status === "active",
    );
    if (chain === undefined) return;
    try {
      executable.push({
        index,
        option,
        assetProfile: resolveAssetProfile(registry, option, option.currency),
      });
    } catch (cause) {
      if (cause instanceof OpapError) return;
      throw cause;
    }
  });
  return executable;
}
