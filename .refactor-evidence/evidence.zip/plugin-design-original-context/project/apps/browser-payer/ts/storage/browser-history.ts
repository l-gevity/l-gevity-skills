import {
  NO_CONTINUITY_EVIDENCE,
  OpapError,
  UNAVAILABLE_CONTINUITY_EVIDENCE,
  canonicalJson,
  mergeContinuityEvidence,
  migrateLegacyContinuityHistory,
  validateContinuityEvidence,
  type AvailableContinuityEvidence,
  type JsonObject,
  type PriorContinuityEvidence,
} from "@opap/core";

export const PAYMENT_HISTORY_KEY = "opap.payment-history.v1";
export const SECURITY_HISTORY_KEY = "opap.security-history.v1";
const MAX_PAYMENT_HISTORY = 20;

/** Browser-local persistence shared by payment receipts and continuity evidence. */
export interface HistoryStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface HistoryLockManager {
  request<T>(name: string, callback: () => T | PromiseLike<T>): Promise<T>;
}

interface ContinuityResult {
  readonly proposedEvidence: AvailableContinuityEvidence;
}

export interface BrowserContinuityHistory {
  run<T extends ContinuityResult>(
    operation: (prior: PriorContinuityEvidence) => Promise<T>,
    persist?: boolean,
  ): Promise<T>;
  acceptChange(
    oldEvidence: AvailableContinuityEvidence,
    proposedEvidence: AvailableContinuityEvidence,
  ): Promise<void>;
}

export interface PaymentHistoryEntry {
  readonly opid: string;
  readonly chain?: string;
  readonly transactionHash?: string;
  readonly timestamp: string;
  readonly outcome: "handoff-created" | "confirmed";
}

export interface BrowserPaymentHistory {
  read(): readonly PaymentHistoryEntry[];
  append(entry: PaymentHistoryEntry): Promise<void>;
}

export interface BrowserHistoryAdapters {
  readonly continuity: BrowserContinuityHistory;
  readonly payments: BrowserPaymentHistory;
  clearAll(): Promise<void>;
}

function plainRecord(
  value: unknown,
): value is Readonly<Record<string, unknown>> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

async function parseStored(value: unknown): Promise<PriorContinuityEvidence> {
  if (!plainRecord(value)) throw new Error("shape");
  if (value.version === 2 && "evidence" in value) {
    return await validateContinuityEvidence(value.evidence);
  }
  if (plainRecord(value.pins) && plainRecord(value.opids)) {
    return await migrateLegacyContinuityHistory(value);
  }
  throw new Error("version");
}

async function readContinuity(
  storage: HistoryStorage,
): Promise<PriorContinuityEvidence> {
  const stored = storage.getItem(SECURITY_HISTORY_KEY);
  if (stored === null) return NO_CONTINUITY_EVIDENCE;
  try {
    return await parseStored(JSON.parse(stored) as unknown);
  } catch {
    return UNAVAILABLE_CONTINUITY_EVIDENCE;
  }
}

function isPaymentHistoryEntry(value: unknown): value is PaymentHistoryEntry {
  return (
    plainRecord(value) &&
    typeof value.opid === "string" &&
    typeof value.timestamp === "string" &&
    (value.outcome === "handoff-created" || value.outcome === "confirmed") &&
    (value.chain === undefined || typeof value.chain === "string") &&
    (value.transactionHash === undefined ||
      typeof value.transactionHash === "string")
  );
}

function readPayments(storage: HistoryStorage): readonly PaymentHistoryEntry[] {
  try {
    const parsed: unknown = JSON.parse(
      storage.getItem(PAYMENT_HISTORY_KEY) ?? "[]",
    );
    if (!Array.isArray(parsed)) return [];
    return Object.freeze(
      parsed.filter(isPaymentHistoryEntry).slice(0, MAX_PAYMENT_HISTORY),
    );
  } catch {
    return [];
  }
}

function sameEvidence(
  left: PriorContinuityEvidence,
  right: AvailableContinuityEvidence,
): boolean {
  return (
    left.state === "available" &&
    canonicalJson(left as unknown as JsonObject) ===
      canonicalJson(right as unknown as JsonObject)
  );
}

export function createBrowserHistoryAdapters(
  storage: HistoryStorage,
  locks?: HistoryLockManager,
): BrowserHistoryAdapters {
  let fallbackQueue: Promise<void> = Promise.resolve();

  const exclusive = async <T>(
    callback: () => T | PromiseLike<T>,
  ): Promise<T> => {
    if (locks !== undefined) {
      return await locks.request("opap-browser-history", callback);
    }
    const result = fallbackQueue.then(callback, callback);
    fallbackQueue = result.then(
      () => undefined,
      () => undefined,
    );
    return await result;
  };

  const writeContinuity = (evidence: AvailableContinuityEvidence): void => {
    try {
      storage.setItem(
        SECURITY_HISTORY_KEY,
        JSON.stringify({ version: 2, evidence }),
      );
    } catch (cause) {
      throw new OpapError(
        "trust_history_unavailable",
        "browser_history_write",
        { cause },
      );
    }
  };

  return Object.freeze({
    continuity: Object.freeze({
      async run<T extends ContinuityResult>(
        operation: (prior: PriorContinuityEvidence) => Promise<T>,
        persist = true,
      ): Promise<T> {
        return await exclusive(async () => {
          const prior = await readContinuity(storage);
          const result = await operation(prior);
          if (persist) {
            writeContinuity(
              await mergeContinuityEvidence(prior, result.proposedEvidence),
            );
          }
          return result;
        });
      },
      async acceptChange(
        oldEvidence: AvailableContinuityEvidence,
        proposedEvidence: AvailableContinuityEvidence,
      ): Promise<void> {
        await exclusive(async () => {
          const current = await readContinuity(storage);
          if (!sameEvidence(current, oldEvidence)) {
            throw new OpapError(
              "trust_history_unavailable",
              "concurrent_update",
            );
          }
          writeContinuity(
            await mergeContinuityEvidence(current, proposedEvidence),
          );
        });
      },
    }),
    payments: Object.freeze({
      read(): readonly PaymentHistoryEntry[] {
        return readPayments(storage);
      },
      async append(entry: PaymentHistoryEntry): Promise<void> {
        await exclusive(() => {
          storage.setItem(
            PAYMENT_HISTORY_KEY,
            JSON.stringify(
              [entry, ...readPayments(storage)].slice(0, MAX_PAYMENT_HISTORY),
            ),
          );
        });
      },
    }),
    async clearAll(): Promise<void> {
      await exclusive(() => {
        storage.removeItem(PAYMENT_HISTORY_KEY);
        storage.removeItem(SECURITY_HISTORY_KEY);
      });
    },
  });
}

let browserHistories: BrowserHistoryAdapters | undefined;

/** Browser-owned singleton. Tests should use createBrowserHistoryAdapters. */
export function getBrowserHistoryAdapters(): BrowserHistoryAdapters {
  if (typeof localStorage === "undefined") {
    throw new OpapError(
      "trust_history_unavailable",
      "browser_storage_unavailable",
    );
  }
  browserHistories ??= createBrowserHistoryAdapters(
    localStorage,
    typeof navigator === "undefined" || navigator.locks === undefined
      ? undefined
      : {
          async request(name, callback) {
            return await navigator.locks.request(name, callback);
          },
        },
  );
  return browserHistories;
}
