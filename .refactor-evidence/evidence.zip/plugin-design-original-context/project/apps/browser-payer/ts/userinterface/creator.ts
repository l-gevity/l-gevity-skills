import { OpapError, deriveRecordUrl, normalizeOpid } from "@opap/core";

import { CreatorPaymentOptions } from "./creator-payment-options";
import {
  createOpidRecord,
  type CreatedOpid,
  type CreatorInput,
} from "./opid-creator";

const form = document.querySelector<HTMLFormElement>("[data-creator-form]");
const output = document.querySelector<HTMLElement>("[data-creator-output]");
const error = document.querySelector<HTMLElement>("[data-creator-error]");
const preview = document.querySelector<HTMLElement>("[data-opid-preview]");
const publicationPreview = document.querySelector<HTMLElement>(
  "[data-publication-preview]",
);
const ownedAddressFlow = document.querySelector<HTMLElement>(
  "[data-owned-address-flow]",
);
const hostedAddressFlow = document.querySelector<HTMLElement>(
  "[data-hosted-address-flow]",
);
const ownedPreview = document.querySelector<HTMLElement>(
  "[data-owned-preview]",
);
const hostedPreview = document.querySelector<HTMLElement>(
  "[data-hosted-preview]",
);
const ownedPreviewWarning = document.querySelector<HTMLElement>(
  "[data-owned-preview-warning]",
);
const previewTitle = document.querySelector<HTMLElement>(
  "[data-preview-title]",
);
const paymentOptions = new CreatorPaymentOptions();

function field(name: string): HTMLInputElement {
  const element = form?.elements.namedItem(name);
  if (!(element instanceof HTMLInputElement)) {
    throw new TypeError(`missing_creator_field:${name}`);
  }
  return element;
}

function creatorInput(): CreatorInput {
  const common = {
    opid: field("opid").value,
    displayName: field("displayName").value,
  };
  if (paymentOptions.selectedMode(form) === "delegate") {
    return {
      ...common,
      mode: "delegate",
      delegateTarget: field("delegateTarget").value,
    };
  }
  return {
    ...common,
    mode: "options",
    options: paymentOptions.inputs(),
  };
}

function selectedAddressSource(): "owned" | "hosted" {
  return form?.querySelector<HTMLInputElement>(
    'input[name="addressSource"]:checked',
  )?.value === "hosted"
    ? "hosted"
    : "owned";
}

function showAddressSource(): void {
  const hosted = selectedAddressSource() === "hosted";
  if (ownedAddressFlow !== null) ownedAddressFlow.hidden = hosted;
  if (hostedAddressFlow !== null) hostedAddressFlow.hidden = !hosted;
  if (ownedPreview !== null) ownedPreview.hidden = hosted;
  if (hostedPreview !== null) hostedPreview.hidden = !hosted;
  if (ownedPreviewWarning !== null) ownedPreviewWarning.hidden = hosted;
  if (previewTitle !== null) {
    previewTitle.textContent = hosted
      ? "Hosted address preview"
      : "Live preview";
  }
  if (hosted && error !== null) error.hidden = true;
}

function selectHostedPlatform(platform: string): void {
  const opid = normalizeOpid(`https://my-opid.${platform}/`);
  const publicationUrl = `${deriveRecordUrl(opid)}.json`;
  document
    .querySelectorAll<HTMLButtonElement>("[data-hosted-platform]")
    .forEach((button) => {
      const selected = button.dataset.hostedPlatform === platform;
      button.setAttribute("aria-pressed", String(selected));
      button.className = selected
        ? "rounded-2xl border border-teal-700 bg-white p-4 text-left ring-2 ring-teal-700/15"
        : "rounded-2xl border border-slate-300 bg-white p-4 text-left hover:border-teal-700 hover:bg-teal-50";
    });
  document
    .querySelectorAll<HTMLElement>("[data-hosted-address-preview]")
    .forEach((hostedAddressPreview) => {
      hostedAddressPreview.textContent = opid;
    });
  document
    .querySelectorAll<HTMLElement>("[data-hosted-publication-preview]")
    .forEach((hostedPublicationPreview) => {
      hostedPublicationPreview.textContent = publicationUrl;
    });
}

function updatePreview(): void {
  if (preview === null || publicationPreview === null) return;
  try {
    const opid = normalizeOpid(field("opid").value.trim());
    preview.textContent = opid;
    publicationPreview.textContent = `${deriveRecordUrl(opid)}.json`;
  } catch {
    preview.textContent = "https://your-domain.org/donate";
    publicationPreview.textContent =
      "Enter your canonical HTTPS OPID to derive this URL";
  }
}

function invalidateResult(): void {
  if (form !== null) {
    delete form.dataset.createdJson;
    delete form.dataset.createdFilename;
  }
  if (output !== null) output.hidden = true;
}

function errorMessage(cause: unknown): string {
  if (cause instanceof OpapError && cause.code === "invalid_opid") {
    return "Enter a public HTTPS URL. It can be your domain itself or a path on it; do not include a port, query, fragment, or a final slash after a path.";
  }
  if (cause instanceof OpapError && cause.code === "invalid_record") {
    if (cause.message.includes("invalid_iban_checksum")) {
      return "That IBAN does not pass its checksum. Check the account number and try again.";
    }
    if (cause.message.includes("invalid_split_share_ppm_sum")) {
      return "The split shares must total exactly 100%.";
    }
    if (cause.message.includes("duplicate_recipient")) {
      return "Each split recipient must use a different wallet address.";
    }
    if (cause.message.includes("duplicate_option_target")) {
      return "Two payment options point to the same destination. Remove or change one of them.";
    }
    return "The payment details do not form a valid payment file. Check the highlighted fields and address lengths.";
  }
  if (
    cause instanceof Error &&
    cause.message.includes("invalid_share_percent")
  ) {
    return "Enter a positive share below 100%, using at most four decimal places.";
  }
  return "The payment file could not be created. Review the form and try again.";
}

function renderResult(result: CreatedOpid): void {
  const opid = document.querySelector<HTMLElement>("[data-result-opid]");
  const location = document.querySelector<HTMLElement>(
    "[data-result-location]",
  );
  const code = document.querySelector<HTMLElement>("[data-result-json]");
  const proofLocation = document.querySelector<HTMLElement>(
    "[data-result-proof-location]",
  );
  const testPaymentLink = document.querySelector<HTMLAnchorElement>(
    "[data-test-payment-link]",
  );
  if (opid !== null) opid.textContent = result.opid;
  if (location !== null) location.textContent = result.publicationUrl;
  if (proofLocation !== null) proofLocation.textContent = result.proofUrl;
  if (code !== null) code.textContent = result.json;
  if (testPaymentLink !== null) {
    testPaymentLink.href = `/pay/?opid=${encodeURIComponent(result.opid)}`;
  }
  if (output !== null) {
    output.hidden = false;
    output.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

form?.addEventListener("change", (event) => {
  const target = event.target;
  if (target instanceof HTMLInputElement && target.name === "paymentMode") {
    paymentOptions.showMode(paymentOptions.selectedMode(form));
  }
  if (target instanceof HTMLInputElement && target.name === "addressSource") {
    showAddressSource();
  }
  paymentOptions.refreshChangedControl(target);
  updatePreview();
  invalidateResult();
});

form?.addEventListener("input", (event) => {
  paymentOptions.refreshShareTotal(event.target);
  updatePreview();
  invalidateResult();
});

form?.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  try {
    const result = createOpidRecord(creatorInput());
    form.dataset.createdJson = result.json;
    form.dataset.createdFilename = result.filename;
    if (error !== null) error.hidden = true;
    renderResult(result);
  } catch (cause) {
    if (output !== null) output.hidden = true;
    if (error !== null) {
      error.textContent = errorMessage(cause);
      error.hidden = false;
      error.focus();
    }
  }
});

document
  .querySelector<HTMLButtonElement>("[data-copy-record]")
  ?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    if (!(button instanceof HTMLButtonElement)) return;
    const json = form?.dataset.createdJson;
    if (json === undefined) return;
    try {
      await navigator.clipboard.writeText(json);
      button.textContent = "Copied";
      window.setTimeout(() => {
        button.textContent = "Copy JSON";
      }, 1800);
    } catch {
      const selection = window.getSelection();
      const range = document.createRange();
      const code = document.querySelector<HTMLElement>("[data-result-json]");
      if (selection !== null && code !== null) {
        range.selectNodeContents(code);
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
  });

document
  .querySelector<HTMLButtonElement>("[data-download-record]")
  ?.addEventListener("click", () => {
    const json = form?.dataset.createdJson;
    const filename = form?.dataset.createdFilename;
    if (json === undefined || filename === undefined) return;
    const url = URL.createObjectURL(
      new Blob([json], { type: "application/opap+json" }),
    );
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  });

document
  .querySelector<HTMLButtonElement>("[data-use-owned-address]")
  ?.addEventListener("click", () => {
    const owned = form?.querySelector<HTMLInputElement>(
      'input[name="addressSource"][value="owned"]',
    );
    if (owned === null || owned === undefined) return;
    owned.checked = true;
    showAddressSource();
    owned.focus();
  });

document
  .querySelectorAll<HTMLButtonElement>("[data-hosted-platform]")
  .forEach((button) => {
    button.addEventListener("click", () => {
      const platform = button.dataset.hostedPlatform;
      if (platform !== undefined) selectHostedPlatform(platform);
    });
  });

paymentOptions.initialize(invalidateResult);
paymentOptions.showMode(paymentOptions.selectedMode(form));
showAddressSource();
selectHostedPlatform("paylink.example");
updatePreview();
document.documentElement.dataset.enhanced = "true";
