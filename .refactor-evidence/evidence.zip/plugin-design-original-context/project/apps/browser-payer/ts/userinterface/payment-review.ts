import {
  deriveRecordUrl,
  OpapError,
  type ExecutionPlan,
  type PriorContinuityEvidence,
  type SplitContractState,
} from "@opap/core";
import type { LiveResolution } from "@opap/runtime";

import type { InterpretedPaymentInput } from "./payment-input";
import type { ConversionFundingPlan } from "../paymentrouting/funding-plan";
import {
  buildReviewedPayment,
  executablePaymentOptions,
  type ExecutablePaymentOption,
  type ReviewedPayment,
} from "../paymentrouting/reviewed-payment";
import { browserPayerRegistry } from "../policy/browser-payer-registry";
import { typedErrorMessage } from "./error-message";

interface CompiledReviewPlan {
  readonly plan: ExecutionPlan;
  readonly adapterState?: SplitContractState;
  readonly priorEvidence: PriorContinuityEvidence;
}

type PlanCompiler = (
  resolution: LiveResolution,
  optionIndex: number,
) => Promise<CompiledReviewPlan>;

function element<T extends Element>(selector: string): T {
  const found = document.querySelector<T>(selector);
  if (found === null) throw new Error(`missing_element:${selector}`);
  return found;
}

function row(term: string, detail: string): HTMLDivElement {
  const wrapper = document.createElement("div");
  wrapper.className =
    "grid gap-1 border-b border-slate-100 pb-3 sm:grid-cols-[9rem_1fr]";
  const dt = document.createElement("dt");
  dt.className = "font-bold text-slate-600";
  dt.textContent = term;
  const dd = document.createElement("dd");
  dd.className = "break-all font-semibold text-slate-950";
  dd.textContent = detail;
  wrapper.append(dt, dd);
  return wrapper;
}

function formatAtomic(amount: string, decimals: number): string {
  const padded = amount.padStart(decimals + 1, "0");
  if (decimals === 0) return padded;
  const whole = padded.slice(0, -decimals);
  const fraction = padded.slice(-decimals).replace(/0+$/, "");
  return fraction.length === 0 ? whole : `${whole}.${fraction}`;
}

function terminalRecipient(
  plan: ExecutionPlan,
  targetOpid: string,
): string | undefined {
  let current = targetOpid;
  const seen = new Set<string>();
  while (!seen.has(current)) {
    seen.add(current);
    const node = plan.graph.nodes.find(
      (candidate) => candidate.opid === current,
    );
    const recipient = node?.selection?.option_projection.recipient;
    if (typeof recipient === "string") return recipient;
    const delegation = plan.graph.edges.find(
      (edge) => edge.type === "delegate" && edge.from === current,
    );
    if (delegation === undefined) return undefined;
    current = delegation.to;
  }
  return undefined;
}

export class PaymentReviewController {
  readonly #details = element<HTMLElement>("[data-payment-details]");
  readonly #amount = element<HTMLInputElement>("[data-payment-amount]");
  readonly #currency = element<HTMLElement>("[data-payment-currency]");
  readonly #description = element<HTMLInputElement>(
    "[data-payment-description]",
  );
  readonly #currencies = element<HTMLElement>("[data-currency-options]");
  readonly #methods = element<HTMLElement>("[data-method-options]");
  readonly #planError = element<HTMLElement>("[data-plan-error]");
  readonly #allocation = element<HTMLElement>("[data-allocation-preview]");
  readonly #review = element<HTMLElement>("[data-review-section]");
  readonly #reviewDetails = element<HTMLElement>("[data-review-details]");
  readonly #reviewMore = element<HTMLDetailsElement>("[data-review-more]");
  readonly #reviewTechnicalDetails = element<HTMLElement>(
    "[data-review-technical-details]",
  );
  readonly #warning = element<HTMLElement>("[data-review-warning]");
  readonly #pay = element<HTMLButtonElement>("[data-pay-button]");
  #resolution: LiveResolution | undefined;
  readonly #compiled = new Map<number, Promise<CompiledReviewPlan>>();
  #fundingPlan: ConversionFundingPlan | undefined;
  #executableOptions: readonly ExecutablePaymentOption[] = [];
  readonly #selectedMethodByCurrency = new Map<string, number>();
  #rebuildVersion = 0;
  readonly #compilePlan: PlanCompiler;
  #onPlan: (payment: ReviewedPayment | undefined) => void;

  constructor(
    compilePlan: PlanCompiler,
    onPlan: (payment: ReviewedPayment | undefined) => void,
  ) {
    this.#compilePlan = compilePlan;
    this.#onPlan = onPlan;
    this.#amount.addEventListener("input", () => void this.rebuild());
    this.#description.addEventListener("input", () => void this.rebuild());
    this.#currencies.addEventListener("change", () => {
      const currency = this.selectedCurrency();
      const resolution = this.#resolution;
      if (resolution !== undefined && currency !== undefined) {
        this.renderMethods(currency);
      }
      void this.rebuild();
    });
    this.#methods.addEventListener("change", () => {
      const selected = this.selectedMethodIndex();
      const currency = this.selectedCurrency();
      if (selected !== undefined && currency !== undefined) {
        this.#selectedMethodByCurrency.set(currency, selected);
      }
      void this.rebuild();
    });
  }

  setResolution(
    resolution: LiveResolution,
    input: InterpretedPaymentInput,
  ): void {
    this.#resolution = resolution;
    this.#compiled.clear();
    this.#amount.value = input.amount ?? "";
    this.#description.value = input.reference ?? "";
    this.#selectedMethodByCurrency.clear();
    this.#currencies.replaceChildren();
    this.#methods.replaceChildren();
    this.#executableOptions = executablePaymentOptions(
      resolution,
      browserPayerRegistry,
      new Map(),
    );
    if (this.#executableOptions.length === 0) {
      throw new OpapError("no_supported_method", "release_policy");
    }
    const currencies = [
      ...new Set(this.#executableOptions.map(({ option }) => option.currency)),
    ];
    const requestedOption =
      input.currency === undefined
        ? this.#executableOptions[0]
        : this.#executableOptions.find(
            ({ option }) => option.currency === input.currency,
          );
    if (requestedOption === undefined) {
      throw new OpapError("no_supported_method", "requested_currency");
    }
    const requestedIndex = requestedOption.index;
    const initialCurrency = resolution.options[requestedIndex]?.currency;
    if (initialCurrency === undefined) throw new Error("missing_currency");
    this.#selectedMethodByCurrency.set(initialCurrency, requestedIndex);
    this.renderCurrencies(currencies, initialCurrency);
    this.renderMethods(initialCurrency);
    this.#currency.textContent = this.selectedCurrency() ?? "---";
    this.#reviewMore.open = false;
    this.#details.hidden = false;
    void this.rebuild();
    this.#amount.focus();
  }

  reset(): void {
    this.#resolution = undefined;
    this.#compiled.clear();
    this.#fundingPlan = undefined;
    this.#executableOptions = [];
    this.#selectedMethodByCurrency.clear();
    this.#currency.textContent = "---";
    this.#currencies.replaceChildren();
    this.#details.hidden = true;
    this.#review.hidden = true;
    this.#onPlan(undefined);
  }

  setReady(ready: boolean, label?: string): void {
    this.#pay.disabled = !ready;
    this.#pay.textContent = label ?? "Confirm payment";
  }

  setGasEstimate(gas: bigint | undefined): void {
    this.#reviewTechnicalDetails.querySelector("[data-gas-row]")?.remove();
    if (gas === undefined) return;
    const gasRow = row("Estimated gas", gas.toString());
    gasRow.dataset.gasRow = "";
    this.#reviewTechnicalDetails.append(gasRow);
  }

  setExecutionError(title: string, detail: string): void {
    const heading = document.createElement("p");
    heading.className = "font-bold";
    heading.textContent = title;
    const explanation = document.createElement("p");
    explanation.className = "mt-1";
    explanation.textContent = detail;
    this.#warning.className =
      "mt-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm leading-6 text-rose-950";
    this.#warning.replaceChildren(heading, explanation);
  }

  setFundingPlan(fundingPlan: ConversionFundingPlan | undefined): void {
    this.#fundingPlan = fundingPlan;
    this.renderFundingPlan();
  }

  onPay(handler: () => void): void {
    this.#pay.addEventListener("click", handler);
  }

  private renderCurrencies(
    currencies: readonly string[],
    selectedCurrency: string,
  ): void {
    this.#currencies.replaceChildren();
    if (currencies.length === 1) {
      const fixed = document.createElement("p");
      fixed.className =
        "col-span-full flex min-h-14 items-center justify-between rounded-xl border border-teal-700 bg-teal-50 px-4";
      const code = document.createElement("span");
      code.className = "text-lg font-black tracking-wide text-teal-950";
      code.textContent = currencies[0] ?? selectedCurrency;
      const note = document.createElement("span");
      note.className =
        "text-xs font-bold uppercase tracking-wide text-teal-800";
      note.textContent = "Only option";
      fixed.append(code, note);
      fixed.dataset.currency = selectedCurrency;
      this.#currencies.append(fixed);
      return;
    }
    currencies.forEach((currency, index) => {
      const label = document.createElement("label");
      label.className =
        "relative flex min-h-16 cursor-pointer flex-col justify-center rounded-xl border border-slate-300 bg-white px-4 transition hover:border-teal-600 has-[:checked]:border-teal-700 has-[:checked]:bg-teal-50 has-[:checked]:ring-1 has-[:checked]:ring-teal-700 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-teal-700 has-[:focus-visible]:ring-offset-2";
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = "settlement-currency";
      radio.value = currency;
      radio.checked = currency === selectedCurrency;
      radio.className = "sr-only";
      const code = document.createElement("span");
      code.className = "text-lg font-black tracking-wide text-slate-950";
      code.textContent = currency;
      const note = document.createElement("span");
      note.className = "mt-0.5 text-xs font-semibold text-slate-500";
      note.textContent = index === 0 ? "Recipient's first choice" : "Accepted";
      label.append(radio, code, note);
      this.#currencies.append(label);
    });
  }

  private renderMethods(currency: string): void {
    this.#methods.replaceChildren();
    const available = this.#executableOptions.filter(
      ({ option }) => option.currency === currency,
    );
    const remembered = this.#selectedMethodByCurrency.get(currency);
    const selectedIndex = available.some(({ index }) => index === remembered)
      ? remembered
      : available[0]?.index;
    if (selectedIndex !== undefined) {
      this.#selectedMethodByCurrency.set(currency, selectedIndex);
    }
    for (const { option, index, assetProfile } of available) {
      const label = document.createElement("label");
      label.className =
        "flex min-h-16 cursor-pointer items-start gap-3 rounded-xl border border-slate-300 bg-white px-4 py-3 transition hover:border-teal-600 has-[:checked]:border-teal-700 has-[:checked]:bg-teal-50 has-[:checked]:ring-1 has-[:checked]:ring-teal-700 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-teal-700 has-[:focus-visible]:ring-offset-2";
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = "payment-method";
      radio.value = index.toString();
      radio.checked = index === selectedIndex;
      radio.className = "mt-0.5 h-5 w-5 shrink-0 accent-teal-700";
      const copy = document.createElement("span");
      copy.className = "min-w-0";
      const name = document.createElement("span");
      name.className = "block text-sm font-bold text-slate-950";
      name.textContent =
        option.type === "sepa" && "iban" in option
          ? "Bank transfer (SEPA)"
          : option.type === "split" && "execution" in option
            ? `Split between ${option.allocations.length} recipients`
            : assetProfile?.environment === "test"
              ? `Monerium test wallet · ${currency}`
              : `${assetProfile?.symbol ?? "Digital money"} wallet transfer`;
      const detail = document.createElement("span");
      detail.className = "mt-1 block break-all text-xs text-slate-600";
      detail.textContent =
        option.type === "sepa" && "iban" in option
          ? `${option.iban.slice(0, 4)}…${option.iban.slice(-4)}`
          : option.type === "split" && "execution" in option
            ? `${option.allocations.length} recipients · ${option.execution.chain}`
            : assetProfile?.environment === "test"
              ? "Monerium sandbox"
              : assetProfile?.environment === "local"
                ? "Local payment sandbox"
                : "Approved wallet route";
      copy.append(name, detail);
      if (index === 0) {
        const preferred = document.createElement("span");
        preferred.className =
          "ml-auto shrink-0 rounded-full bg-teal-100 px-2 py-1 text-[0.65rem] font-black uppercase tracking-wide text-teal-900";
        preferred.textContent = "Preferred";
        label.append(radio, copy, preferred);
      } else {
        label.append(radio, copy);
      }
      this.#methods.append(label);
    }
  }

  private selectedCurrency(): string | undefined {
    const selected =
      this.#currencies.querySelector<HTMLInputElement>("input:checked")?.value;
    if (selected !== undefined) return selected;
    return this.#currencies.querySelector<HTMLElement>("[data-currency]")
      ?.dataset.currency;
  }

  private selectedMethodIndex(): number | undefined {
    const value =
      this.#methods.querySelector<HTMLInputElement>("input:checked")?.value;
    if (value === undefined) return undefined;
    const index = Number(value);
    return Number.isInteger(index) ? index : undefined;
  }

  private async rebuild(): Promise<void> {
    const version = ++this.#rebuildVersion;
    const resolution = this.#resolution;
    if (resolution === undefined || this.#amount.value.trim().length === 0) {
      this.#planError.hidden = true;
      this.#allocation.replaceChildren();
      this.#review.hidden = true;
      this.#onPlan(undefined);
      return;
    }
    try {
      const currency = this.selectedCurrency();
      if (currency === undefined) throw new TypeError("missing_currency");
      this.#currency.textContent = currency;
      const optionIndex = this.selectedMethodIndex() ?? -1;
      let pending = this.#compiled.get(optionIndex);
      if (pending === undefined) {
        pending = this.#compilePlan(resolution, optionIndex);
        this.#compiled.set(optionIndex, pending);
      }
      const { plan, adapterState, priorEvidence } = await pending;
      if (version !== this.#rebuildVersion) return;
      const payment = buildReviewedPayment(
        {
          plan,
          amount: this.#amount.value,
          currency,
          reference: this.#description.value,
          priorEvidence,
          ...(adapterState === undefined ? {} : { adapterState }),
        },
        browserPayerRegistry,
      );
      this.#planError.hidden = true;
      this.renderPlan(payment);
      this.#onPlan(payment);
    } catch (cause) {
      const message = typedErrorMessage(cause);
      this.#planError.textContent = `${message.title}. ${message.detail}`;
      this.#planError.hidden = false;
      this.#allocation.replaceChildren();
      this.#review.hidden = true;
      this.#onPlan(undefined);
    }
  }

  private renderPlan(payment: ReviewedPayment): void {
    const plan = payment.plan;
    const execution = plan.execution;
    this.#allocation.replaceChildren();
    if (payment.type === "split") {
      const title = document.createElement("h3");
      title.className = "font-bold";
      title.textContent = "How the payment is split";
      const list = document.createElement("ol");
      list.className = "mt-2 grid gap-2";
      for (const [index, allocation] of payment.allocations.entries()) {
        const item = document.createElement("li");
        item.className = "break-all rounded-lg bg-slate-50 p-3 text-sm";
        item.textContent = `Recipient ${index + 1}: ${(allocation.sharePpm / 10_000).toFixed(2)}% · ${allocation.recipient}`;
        list.append(item);
      }
      this.#allocation.append(title, list);
    }
    const destination =
      payment.type === "sepa"
        ? payment.plan.execution.iban
        : payment.type === "erc20"
          ? payment.plan.execution.recipient
          : `${payment.plan.execution.allocations.length} recipients`;
    const route =
      payment.type === "sepa"
        ? "Bank transfer (SEPA)"
        : payment.type === "split"
          ? `Split between ${payment.allocations.length} recipients`
          : `${payment.type === "erc20" ? payment.assetProfile.symbol : "Digital money"} wallet transfer`;
    const details = [
      row("Recipient", this.#resolution?.name ?? execution.source_opid),
      row("Amount", `${payment.amount} ${execution.currency}`),
      ...(payment.reference === undefined
        ? []
        : [row("For", payment.reference)]),
      row("Payment method", route),
      row("Destination", destination),
    ];
    const technicalDetails = [
      row("Payment address", plan.root_opid),
      ...(execution.source_opid === plan.root_opid
        ? []
        : [row("Payment option published by", execution.source_opid)]),
      row("Derived record URL", deriveRecordUrl(plan.root_opid)),
      ...(payment.type === "sepa"
        ? []
        : [
            row(
              "Currency / chain / asset",
              `${payment.plan.execution.currency} · ${payment.plan.execution.chain} · ${payment.plan.execution.asset}`,
            ),
            ...(payment.type === "split"
              ? [
                  row("Adapter", payment.plan.execution.adapter),
                  row("Contract", payment.plan.execution.contract),
                  row("Config ID", payment.plan.execution.config_id),
                  row(
                    "Split control",
                    "Each target publisher chooses the first compatible address through option ordering. The root publisher controls settlement context, shares, and allocation order.",
                  ),
                ]
              : []),
          ]),
      row(
        "Resolved OPIDs and trust",
        plan.graph.nodes
          .map(
            (node) =>
              `${node.opid} · revision ${node.revision} · ${node.binding}/${node.continuity} · ${node.transport.profile} transport (${node.transport.proof_source} proof, ${node.transport.cache} cache) · ${node.record_fingerprint}`,
          )
          .join(" → "),
      ),
      ...plan.graph.edges
        .filter((edge) => edge.type === "allocation")
        .map((edge) => {
          const recipient = terminalRecipient(plan, edge.to);
          return row(
            `Target ${edge.allocation_index + 1}`,
            `${edge.to} → ${recipient ?? "unresolved"}`,
          );
        }),
    ];
    this.#reviewDetails.replaceChildren(...details);
    this.#reviewTechnicalDetails.replaceChildren(...technicalDetails);
    this.#warning.className =
      "mt-5 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-950";
    this.#warning.textContent =
      payment.type === "sepa"
        ? "Use the banking-app button on this device, or scan the QR code with another device. Check the recipient and amount in your banking app. OPAP cannot confirm when the transfer arrives."
        : payment.assetProfile.environment === "production"
          ? "This wallet payment is not available yet."
          : plan.graph.nodes.some((node) => node.continuity !== "bound")
            ? "This browser has not seen one or more of these payment addresses before. OPAP will check everything again before you pay."
            : "This is a test payment. No real money will be sent.";
    this.#review.hidden = false;
    this.renderFundingPlan();
    this.#pay.hidden = execution.type === "sepa";
    this.setReady(false, "Confirm test payment");
  }

  private renderFundingPlan(): void {
    this.#reviewDetails
      .querySelectorAll("[data-funding-row]")
      .forEach((entry) => entry.remove());
    const funding = this.#fundingPlan;
    if (funding === undefined || this.#review.hidden) return;
    const sourceAmount = formatAtomic(
      funding.sourceAtomicAmount,
      funding.sourceAssetProfile.decimals,
    );
    const maximumSourceAmount = formatAtomic(
      funding.maxSourceAtomicAmount,
      funding.sourceAssetProfile.decimals,
    );
    const targetAmount = formatAtomic(
      funding.targetAtomicAmount,
      funding.targetAssetProfile.decimals,
    );
    const source = row(
      "You pay",
      `${sourceAmount} ${funding.sourceAssetProfile.symbol} (${funding.sourceAssetProfile.currency ?? "unknown"}); maximum ${maximumSourceAmount}`,
    );
    const output = row(
      "Recipient gets",
      `${targetAmount} ${funding.targetAssetProfile.symbol} (${funding.targetAssetProfile.currency ?? "unknown"}) to ${funding.recipient}`,
    );
    const terms = row(
      "Conversion",
      `Fixed local test rate: ${sourceAmount} ${funding.sourceAssetProfile.symbol} for ${targetAmount} ${funding.targetAssetProfile.symbol} · fee 0 · slippage 0 · no quote expiry`,
    );
    source.dataset.fundingRow = "";
    output.dataset.fundingRow = "";
    terms.dataset.fundingRow = "";
    this.#reviewDetails.append(source, output, terms);
    this.#warning.textContent =
      "This test converts the amount shown under “You pay.” The recipient still receives the exact amount shown above.";
  }
}
