import {
  sharePercentToPpm,
  type CreatorPaymentOptionInput,
} from "./opid-creator";

export type PaymentMode = "options" | "delegate";
type PaymentOptionKind = "sepa" | "erc20";

export class CreatorPaymentOptions {
  readonly #root: Document;
  readonly #optionList: HTMLElement | null;
  readonly #optionTemplate: HTMLTemplateElement | null;
  readonly #allocationTemplate: HTMLTemplateElement | null;
  readonly #addOptionButton: HTMLButtonElement | null;

  constructor(root: Document = document) {
    this.#root = root;
    this.#optionList = root.querySelector("[data-payment-option-list]");
    this.#optionTemplate = root.querySelector("[data-payment-option-template]");
    this.#allocationTemplate = root.querySelector("[data-allocation-template]");
    this.#addOptionButton = root.querySelector("[data-add-payment-option]");
  }

  selectedMode(form: HTMLFormElement | null): PaymentMode {
    const selected = form?.querySelector<HTMLInputElement>(
      'input[name="paymentMode"]:checked',
    )?.value;
    return selected === "delegate" ? "delegate" : "options";
  }

  inputs(): CreatorPaymentOptionInput[] {
    return this.#cards().map((card) => this.#paymentOptionInput(card));
  }

  showMode(mode: PaymentMode): void {
    for (const panel of this.#root.querySelectorAll<HTMLElement>(
      "[data-payment-mode-panel]",
    )) {
      const active = panel.dataset.paymentModePanel === mode;
      panel.hidden = !active;
      if (!active) this.#setControlsEnabled(panel, false);
    }
    if (mode === "options") {
      this.#cards().forEach((card) => {
        this.#setControlsEnabled(card, true);
        this.#refreshOptionCard(card);
      });
      this.#updateOptionControls();
    } else {
      const delegate = this.#root.querySelector<HTMLElement>(
        '[data-payment-mode-panel="delegate"]',
      );
      if (delegate !== null) this.#setControlsEnabled(delegate, true);
    }
  }

  refreshChangedControl(target: EventTarget | null): void {
    if (
      target instanceof HTMLSelectElement &&
      target.matches("[data-option-kind]")
    ) {
      const card = target.closest<HTMLElement>("[data-payment-option]");
      if (card !== null) this.#refreshOptionCard(card);
    }
    if (
      target instanceof HTMLSelectElement &&
      target.matches("[data-allocation-kind]")
    ) {
      const row = target.closest<HTMLElement>("[data-allocation]");
      if (row !== null) this.#refreshAllocationRow(row);
    }
    if (
      target instanceof HTMLInputElement &&
      target.matches("[data-split-toggle]")
    ) {
      const card = target.closest<HTMLElement>("[data-payment-option]");
      if (card !== null) this.#refreshOptionCard(card);
    }
  }

  refreshShareTotal(target: EventTarget | null): void {
    if (
      target instanceof HTMLInputElement &&
      target.matches('[data-allocation-field="share"]')
    ) {
      const card = target.closest<HTMLElement>("[data-payment-option]");
      if (card !== null) this.#updateSplitTotal(card);
    }
  }

  initialize(onChange: () => void): void {
    this.#addOptionButton?.addEventListener("click", () => {
      this.#addPaymentOption();
      this.#cards()
        .at(-1)
        ?.scrollIntoView({ behavior: "smooth", block: "center" });
      onChange();
    });
    this.#optionList?.addEventListener("click", (event) => {
      if (this.#handleListClick(event.target)) onChange();
    });
    this.#addPaymentOption();
  }

  #optionField(card: HTMLElement, name: string): HTMLInputElement {
    const input = card.querySelector<HTMLInputElement>(
      `[data-option-field="${name}"]`,
    );
    if (input === null) throw new TypeError(`missing_option_field:${name}`);
    return input;
  }

  #setControlsEnabled(container: HTMLElement, enabled: boolean): void {
    for (const control of container.querySelectorAll<
      HTMLInputElement | HTMLSelectElement | HTMLButtonElement
    >("input, select, button")) {
      control.disabled = !enabled;
    }
  }

  #cards(): HTMLElement[] {
    return Array.from(
      this.#optionList?.querySelectorAll<HTMLElement>(
        "[data-payment-option]",
      ) ?? [],
    );
  }

  #paymentOptionInput(card: HTMLElement): CreatorPaymentOptionInput {
    const kind =
      card.querySelector<HTMLSelectElement>("[data-option-kind]")?.value;
    if (kind === "sepa") {
      return {
        type: "sepa",
        name: this.#optionField(card, "name").value,
        iban: this.#optionField(card, "iban").value,
      };
    }

    const common = {
      chainId: this.#optionField(card, "chainId").value,
      currency: this.#optionField(card, "currency").value,
      asset: this.#optionField(card, "asset").value,
    };
    const split = card.querySelector<HTMLInputElement>(
      "[data-split-toggle]",
    )?.checked;
    if (!split) {
      return {
        type: "erc20",
        ...common,
        recipient: this.#optionField(card, "recipient").value,
        symbol: this.#optionField(card, "symbol").value,
      };
    }

    const allocations = Array.from(
      card.querySelectorAll<HTMLElement>("[data-allocation]"),
      (row) => {
        const allocationKind =
          row.querySelector<HTMLSelectElement>("[data-allocation-kind]")
            ?.value === "target"
            ? "target"
            : "recipient";
        const recipient = row.querySelector<HTMLInputElement>(
          '[data-allocation-field="recipient"]',
        );
        const target = row.querySelector<HTMLInputElement>(
          '[data-allocation-field="target"]',
        );
        const share = row.querySelector<HTMLInputElement>(
          '[data-allocation-field="share"]',
        );
        if (recipient === null || target === null || share === null) {
          throw new TypeError("missing_split_allocation_field");
        }
        const sharePpm = sharePercentToPpm(share.value);
        return allocationKind === "recipient"
          ? {
              type: "recipient" as const,
              recipient: recipient.value,
              sharePpm,
            }
          : {
              type: "target" as const,
              target: target.value,
              sharePpm,
            };
      },
    );
    return {
      type: "split",
      ...common,
      contract: this.#optionField(card, "contract").value,
      configId: this.#optionField(card, "configId").value,
      allocations,
    };
  }

  #optionKind(card: HTMLElement): PaymentOptionKind {
    return card.querySelector<HTMLSelectElement>("[data-option-kind]")
      ?.value === "erc20"
      ? "erc20"
      : "sepa";
  }

  #updateSplitTotal(card: HTMLElement): void {
    const shareFields = Array.from(
      card.querySelectorAll<HTMLInputElement>(
        '[data-allocation-field="share"]',
      ),
    );
    let totalPpm = 0;
    let allValid = shareFields.length >= 2;
    for (const share of shareFields) {
      share.setCustomValidity("");
      try {
        totalPpm += sharePercentToPpm(share.value);
      } catch {
        allValid = false;
      }
    }
    const total = card.querySelector<HTMLElement>("[data-split-total]");
    if (total !== null) {
      const formatted = (totalPpm / 10_000).toFixed(4).replace(/\.?0+$/, "");
      total.textContent = `Total: ${formatted}%`;
      total.className =
        allValid && totalPpm === 1_000_000
          ? "mt-3 text-sm font-black text-emerald-800"
          : "mt-3 text-sm font-black text-rose-800";
    }
    if (allValid && totalPpm !== 1_000_000) {
      shareFields[0]?.setCustomValidity("Shares must total exactly 100%.");
    }
  }

  #updateAllocationControls(card: HTMLElement): void {
    const rows = Array.from(
      card.querySelectorAll<HTMLElement>("[data-allocation]"),
    );
    rows.forEach((row, index) => {
      const remove = row.querySelector<HTMLButtonElement>(
        "[data-remove-allocation]",
      );
      if (remove !== null) {
        remove.disabled = rows.length <= 2;
        remove.setAttribute("aria-label", `Remove allocation ${index + 1}`);
      }
    });
    const add = card.querySelector<HTMLButtonElement>("[data-add-allocation]");
    if (add !== null) add.disabled = rows.length >= 16;
    this.#updateSplitTotal(card);
    this.#refreshSplitConfigId(card);
  }

  #refreshAllocationRow(row: HTMLElement): void {
    const kind =
      row.querySelector<HTMLSelectElement>("[data-allocation-kind]")?.value ===
      "target"
        ? "target"
        : "recipient";
    for (const panel of row.querySelectorAll<HTMLElement>(
      "[data-allocation-panel]",
    )) {
      const active = panel.dataset.allocationPanel === kind;
      panel.hidden = !active;
      this.#setControlsEnabled(panel, active);
    }
    const card = row.closest<HTMLElement>("[data-payment-option]");
    if (card !== null) this.#refreshSplitConfigId(card);
  }

  #refreshSplitConfigId(card: HTMLElement): void {
    const splitEnabled =
      card.querySelector<HTMLInputElement>("[data-split-toggle]")?.checked ===
      true;
    const hasTargets = Array.from(
      card.querySelectorAll<HTMLSelectElement>("[data-allocation-kind]"),
    ).some((select) => select.value === "target");
    const panel = card.querySelector<HTMLElement>("[data-target-config-panel]");
    if (panel === null) return;
    const active = splitEnabled && hasTargets;
    panel.hidden = !active;
    this.#setControlsEnabled(panel, active);
  }

  #addAllocation(card: HTMLElement, share = ""): void {
    const list = card.querySelector<HTMLElement>("[data-allocation-list]");
    const row =
      this.#allocationTemplate?.content.firstElementChild?.cloneNode(true);
    if (list === null || !(row instanceof HTMLElement)) return;
    const shareField = row.querySelector<HTMLInputElement>(
      '[data-allocation-field="share"]',
    );
    if (shareField !== null) shareField.value = share;
    list.append(row);
    this.#refreshAllocationRow(row);
    this.#updateAllocationControls(card);
  }

  #ensureInitialAllocations(card: HTMLElement): void {
    if (card.querySelector("[data-allocation]") !== null) return;
    this.#addAllocation(card, "50");
    this.#addAllocation(card, "50");
  }

  #refreshOptionCard(card: HTMLElement): void {
    const kind = this.#optionKind(card);
    for (const panel of card.querySelectorAll<HTMLElement>(
      "[data-option-panel]",
    )) {
      const active = panel.dataset.optionPanel === kind;
      panel.hidden = !active;
      this.#setControlsEnabled(panel, active);
    }
    if (kind !== "erc20") return;

    const split =
      card.querySelector<HTMLInputElement>("[data-split-toggle]")?.checked ??
      false;
    if (split) this.#ensureInitialAllocations(card);
    const directPanel = card.querySelector<HTMLElement>("[data-direct-panel]");
    const splitPanel = card.querySelector<HTMLElement>("[data-split-panel]");
    const directOnly = card.querySelector<HTMLElement>("[data-direct-only]");
    if (directPanel !== null) {
      directPanel.hidden = split;
      this.#setControlsEnabled(directPanel, !split);
    }
    if (directOnly !== null) {
      directOnly.hidden = split;
      this.#setControlsEnabled(directOnly, !split);
    }
    if (splitPanel !== null) {
      splitPanel.hidden = !split;
      this.#setControlsEnabled(splitPanel, split);
    }
    if (split) {
      card
        .querySelectorAll<HTMLElement>("[data-allocation]")
        .forEach((row) => this.#refreshAllocationRow(row));
    }
    this.#updateAllocationControls(card);
  }

  #updateOptionControls(): void {
    const cards = this.#cards();
    cards.forEach((card, index) => {
      const title = card.querySelector<HTMLElement>("[data-option-title]");
      if (title !== null) title.textContent = `Payment option ${index + 1}`;
      const up = card.querySelector<HTMLButtonElement>("[data-move-option-up]");
      const down = card.querySelector<HTMLButtonElement>(
        "[data-move-option-down]",
      );
      const remove = card.querySelector<HTMLButtonElement>(
        "[data-remove-option]",
      );
      if (up !== null) {
        up.disabled = index === 0;
        up.setAttribute("aria-label", `Move payment option ${index + 1} up`);
      }
      if (down !== null) {
        down.disabled = index === cards.length - 1;
        down.setAttribute(
          "aria-label",
          `Move payment option ${index + 1} down`,
        );
      }
      if (remove !== null) {
        remove.disabled = cards.length <= 1;
        remove.setAttribute("aria-label", `Remove payment option ${index + 1}`);
      }
    });
    if (this.#addOptionButton !== null) {
      this.#addOptionButton.disabled = cards.length >= 16;
    }
  }

  #addPaymentOption(kind: PaymentOptionKind = "sepa"): void {
    const card =
      this.#optionTemplate?.content.firstElementChild?.cloneNode(true);
    if (this.#optionList === null || !(card instanceof HTMLElement)) return;
    const select = card.querySelector<HTMLSelectElement>("[data-option-kind]");
    if (select !== null) select.value = kind;
    this.#optionList.append(card);
    this.#refreshOptionCard(card);
    this.#updateOptionControls();
  }

  #handleListClick(target: EventTarget | null): boolean {
    if (!(target instanceof HTMLButtonElement)) return false;
    const card = target.closest<HTMLElement>("[data-payment-option]");
    if (card === null || this.#optionList === null) return false;

    if (target.matches("[data-move-option-up]")) {
      const previous = card.previousElementSibling;
      if (previous !== null) this.#optionList.insertBefore(card, previous);
    } else if (target.matches("[data-move-option-down]")) {
      const next = card.nextElementSibling;
      if (next !== null) next.after(card);
    } else if (target.matches("[data-remove-option]")) {
      card.remove();
    } else if (target.matches("[data-add-allocation]")) {
      this.#addAllocation(card);
    } else if (target.matches("[data-remove-allocation]")) {
      target.closest<HTMLElement>("[data-allocation]")?.remove();
      this.#updateAllocationControls(card);
    } else {
      return false;
    }
    this.#updateOptionControls();
    return true;
  }
}
