import type {
  ReviewedOnchainPayment,
  ReviewedSepaPayment,
} from "../paymentrouting/reviewed-payment";
import { chainPolicy } from "../policy/browser-payer-registry";
import {
  getBrowserHistoryAdapters,
  type PaymentHistoryEntry,
} from "../storage/browser-history";
import type { SubmittedPayment } from "../paymentexecution/wallet-session";
import type { PaymentReturnTarget } from "./payment-request";

function history(): readonly PaymentHistoryEntry[] {
  return getBrowserHistoryAdapters().payments.read();
}

async function save(entry: PaymentHistoryEntry): Promise<void> {
  await getBrowserHistoryAdapters().payments.append(entry);
}

function paragraph(value: string, className: string): HTMLParagraphElement {
  const result = document.createElement("p");
  result.textContent = value;
  result.className = className;
  return result;
}

function setReceiptHeader(title: string, summary: string): void {
  const heading = document.querySelector<HTMLElement>("[data-receipt-title]");
  const detail = document.querySelector<HTMLElement>("[data-receipt-summary]");
  if (heading !== null) heading.textContent = title;
  if (detail !== null) detail.textContent = summary;
}

function returnAction(
  target: PaymentReturnTarget,
  detail: string,
): HTMLDivElement {
  const wrapper = document.createElement("div");
  wrapper.className = "mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4";
  const link = document.createElement("a");
  link.href = target.href;
  link.rel = "noreferrer";
  link.className =
    "flex min-h-12 w-full items-center justify-center rounded-lg border border-teal-700 bg-white px-5 text-center font-black text-teal-800 hover:bg-teal-50";
  link.textContent = `Return to ${target.host}`;
  const explanation = paragraph(
    detail,
    "mt-2 text-xs leading-5 text-slate-600",
  );
  wrapper.append(link, explanation);
  return wrapper;
}

export function renderHistory(): void {
  const list = document.querySelector<HTMLOListElement>(
    "[data-payment-history]",
  );
  if (list === null) return;
  const entries = history();
  if (entries.length === 0) {
    const empty = document.createElement("li");
    empty.className = "text-sm text-slate-500";
    empty.textContent = "No locally saved payments.";
    list.replaceChildren(empty);
    return;
  }
  list.replaceChildren(
    ...entries.map((entry) => {
      const item = document.createElement("li");
      item.className =
        "rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm";
      item.append(
        paragraph(
          `${entry.outcome === "confirmed" ? "Confirmed" : "Handoff created"} · ${entry.opid}`,
          "font-bold",
        ),
        paragraph(
          new Date(entry.timestamp).toLocaleString(),
          "mt-1 text-slate-600",
        ),
      );
      if (entry.transactionHash !== undefined)
        item.append(
          paragraph(
            entry.transactionHash,
            "mt-1 break-all font-mono text-xs text-slate-600",
          ),
        );
      return item;
    }),
  );
}

function optedIn(): boolean {
  return (
    document.querySelector<HTMLInputElement>("[data-history-opt-in]")
      ?.checked === true
  );
}

export function bankingAppHref(paytoUri: string, userAgent: string): string {
  if (!/\bAndroid\b/i.test(userAgent)) return paytoUri;
  return `intent:${paytoUri.slice("payto:".length)}#Intent;scheme=payto;end`;
}

export function showSepaHandoff(
  payment: ReviewedSepaPayment,
  paytoUri: string,
  returnTarget?: PaymentReturnTarget,
): void {
  const content = document.querySelector<HTMLElement>("[data-sepa-handoff]");
  if (content === null) return;

  const action = document.createElement("div");
  action.className = "rounded-2xl border border-teal-200 bg-teal-50 p-4 sm:p-5";
  const actionTitle = document.createElement("h3");
  actionTitle.className = "text-base font-black text-teal-950";
  actionTitle.textContent = "Pay from this device";
  const link = document.createElement("a");
  link.href = bankingAppHref(paytoUri, navigator.userAgent);
  link.dataset.paytoLink = "";
  link.setAttribute("aria-describedby", "payto-help");
  link.className =
    "mt-3 flex min-h-12 w-full items-center justify-center rounded-lg bg-teal-700 px-5 text-center font-black text-white shadow-sm hover:bg-teal-800";
  link.textContent = "Pay with banking app";
  const actionHelp = paragraph(
    "Opens these payment details in a compatible banking app.",
    "mt-2 text-xs leading-5 text-teal-900",
  );
  actionHelp.id = "payto-help";
  action.append(actionTitle, link, actionHelp);

  const qrFrame = document.createElement("figure");
  qrFrame.className =
    "mt-5 overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 sm:p-5";
  qrFrame.dataset.sepaQr = "";
  const qrTitle = document.createElement("figcaption");
  qrTitle.className = "mb-3 text-center text-sm font-bold text-slate-700";
  qrTitle.textContent = "Or scan this QR code from another device";
  const qrStatus = paragraph(
    `Preparing the QR code for ${payment.amount} ${payment.plan.execution.currency}…`,
    "flex min-h-48 items-center justify-center rounded-xl bg-slate-50 p-4 text-center text-sm text-slate-600",
  );
  qrStatus.dataset.sepaQrStatus = "";
  qrFrame.append(qrTitle, qrStatus);

  content.replaceChildren(
    action,
    qrFrame,
    ...(returnTarget === undefined
      ? []
      : [
          returnAction(
            returnTarget,
            "This reports that the banking-app handoff was prepared. It does not confirm that the bank transfer settled.",
          ),
        ]),
  );
  content.hidden = false;
}

export function showSepaQr(
  payment: ReviewedSepaPayment,
  qr: HTMLImageElement,
): void {
  const frame = document.querySelector<HTMLElement>("[data-sepa-qr]");
  if (frame === null) return;
  qr.alt = `SEPA payment QR for ${payment.amount} ${payment.plan.execution.currency} to ${payment.plan.execution.name}`;
  frame.querySelector("[data-sepa-qr-status]")?.replaceWith(qr);
}

export function showSepaQrError(): void {
  const status = document.querySelector<HTMLElement>("[data-sepa-qr-status]");
  if (status === null) return;
  status.className =
    "rounded-xl border border-amber-200 bg-amber-50 p-4 text-center text-sm leading-6 text-amber-950";
  status.textContent =
    "The QR code could not be displayed. Use the banking-app button above.";
}

export function clearReceipt(): void {
  const section = document.querySelector<HTMLElement>("[data-receipt-section]");
  const content = document.querySelector<HTMLElement>("[data-receipt-content]");
  const sepaHandoff = document.querySelector<HTMLElement>(
    "[data-sepa-handoff]",
  );
  if (content !== null) content.replaceChildren();
  if (section !== null) section.hidden = true;
  if (sepaHandoff !== null) {
    sepaHandoff.replaceChildren();
    sepaHandoff.hidden = true;
  }
  setReceiptHeader("Payment result", "");
}

export async function showOnchainReceipt(
  payment: ReviewedOnchainPayment,
  receipt: SubmittedPayment,
  returnTarget?: PaymentReturnTarget,
): Promise<void> {
  const section = document.querySelector<HTMLElement>("[data-receipt-section]");
  const content = document.querySelector<HTMLElement>("[data-receipt-content]");
  if (section === null || content === null) return;
  const historyControl = document.querySelector<HTMLElement>(
    "[data-history-opt-in-control]",
  );
  if (historyControl !== null) historyControl.hidden = false;
  const chain = payment.plan.execution.chain;
  setReceiptHeader(
    "Transaction confirmed",
    `The wallet confirmed this payment on ${chain}.`,
  );
  content.replaceChildren(
    paragraph(
      `Block ${receipt.blockNumber} on ${chain}`,
      "text-sm text-slate-700",
    ),
    paragraph(
      receipt.hash,
      "mt-3 break-all rounded-lg bg-slate-50 p-3 font-mono text-xs",
    ),
    paragraph(receipt.decoded, "mt-3 break-all text-sm text-slate-700"),
  );
  const explorer = chainPolicy(chain).explorerUrl;
  if (explorer !== null) {
    const link = document.createElement("a");
    link.href = `${explorer.replace(/\/$/, "")}/tx/${receipt.hash}`;
    link.target = "_blank";
    link.rel = "noreferrer noopener";
    link.className =
      "mt-4 inline-flex min-h-11 items-center font-bold text-teal-800 underline";
    link.textContent = "View transaction in explorer (informational)";
    content.append(link);
  }
  if (returnTarget !== undefined) {
    content.append(
      returnAction(
        returnTarget,
        "The calling application must independently verify this transaction against its original payment request.",
      ),
    );
  }
  section.hidden = false;
  if (optedIn()) {
    await save({
      opid: payment.plan.root_opid,
      chain,
      transactionHash: receipt.hash,
      timestamp: new Date().toISOString(),
      outcome: "confirmed",
    });
    renderHistory();
  }
  section.scrollIntoView({ behavior: "smooth", block: "start" });
}

export function initializeHistory(): void {
  document
    .querySelector<HTMLButtonElement>("[data-clear-history]")
    ?.addEventListener("click", async () => {
      await getBrowserHistoryAdapters().clearAll();
      renderHistory();
      const status = document.querySelector<HTMLElement>(
        "[data-history-status]",
      );
      if (status !== null) {
        status.textContent =
          "Payment and security history were cleared. This device no longer has key, revision, or target continuity.";
      }
    });
  renderHistory();
}
