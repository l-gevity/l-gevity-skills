import {
  buildSepaHandoff,
  createPaymentAuthorization,
  type SplitExecutionInstruction,
} from "@opap/core";
import {
  verifySupportedSplitAdapter,
  type LiveResolution,
  type ResolvedExecutionPlan,
} from "@opap/runtime";

import type { ConversionFundingPlan } from "../paymentrouting/funding-plan";
import type {
  ReviewedPayment,
  ReviewedSepaPayment,
} from "../paymentrouting/reviewed-payment";
import {
  browserPayerRegistry,
  chainPolicy,
} from "../policy/browser-payer-registry";
import {
  acceptBrowserContinuityChange,
  reResolveBrowserAndCompare,
  resolveBrowserExecutionPlan,
  resolveBrowserInput,
} from "../resolution/browser-resolution";
import { browserSplitConfigReader } from "../paymentexecution/split-config-reader";
import { WalletSession } from "../paymentexecution/wallet-session";
import { typedErrorMessage } from "./error-message";
import { type InterpretedPaymentInput } from "./payment-input";
import {
  createPaymentReturnTarget,
  interpretPaymentRequest,
  type PaymentPageRequest,
  type PaymentReturnResult,
  type PaymentReturnTarget,
} from "./payment-request";
import {
  clearReceipt,
  initializeHistory,
  showOnchainReceipt,
  showSepaHandoff,
  showSepaQr,
  showSepaQrError,
} from "./payment-receipt";
import { PaymentReviewController } from "./payment-review";
import { createEpcQrImage } from "./qr";
import {
  paymentTargetChangeDetails,
  showResolution,
  showResolutionError,
  showResolving,
  showTargetChangeConfirmation,
} from "./resolver-view";

let operation = 0;
let controller: AbortController | undefined;
let payment: ReviewedPayment | undefined;
let resolution: LiveResolution | undefined;
let wallet: WalletSession | undefined;
let fundingPlan: ConversionFundingPlan | undefined;
let sepaPresentation = 0;
let pageRequest: PaymentPageRequest | undefined;

const review = new PaymentReviewController(compileForReview, (nextPayment) => {
  const presentation = ++sepaPresentation;
  payment = nextPayment;
  fundingPlan = undefined;
  clearReceipt();
  review.setFundingPlan(undefined);
  const walletSection = document.querySelector<HTMLElement>(
    "[data-wallet-section]",
  );
  if (walletSection !== null)
    walletSection.hidden =
      nextPayment === undefined || nextPayment.type === "sepa";
  if (nextPayment !== undefined && nextPayment.type !== "sepa") {
    review.setReady(false);
  } else if (nextPayment?.type === "sepa" && navigator.onLine) {
    void presentSepaPayment(nextPayment, presentation);
  }
});

function walletStatus(
  title: string,
  detail: string,
  tone: "neutral" | "success" | "error" = "neutral",
): void {
  const status = document.querySelector<HTMLElement>("[data-wallet-status]");
  if (status === null) return;
  const heading = document.createElement("p");
  heading.className = "font-bold";
  heading.textContent = title;
  const paragraph = document.createElement("p");
  paragraph.className = "mt-1 text-sm";
  paragraph.textContent = detail;
  status.className = `mt-5 rounded-xl border p-4 ${tone === "success" ? "border-emerald-200 bg-emerald-50 text-emerald-900" : tone === "error" ? "border-rose-200 bg-rose-50 text-rose-900" : "border-slate-200 bg-slate-50 text-slate-700"}`;
  status.replaceChildren(heading, paragraph);
}

function returnTarget(
  result: PaymentReturnResult,
): PaymentReturnTarget | undefined {
  return pageRequest === undefined
    ? undefined
    : createPaymentReturnTarget(pageRequest, result);
}

function initializePaymentRequestContext(request: PaymentPageRequest): void {
  const context = document.querySelector<HTMLElement>("[data-caller-context]");
  const defaultContext = document.querySelector<HTMLElement>(
    "[data-direct-payment-context]",
  );
  const host = document.querySelector<HTMLElement>("[data-caller-host]");
  const cancel = document.querySelector<HTMLAnchorElement>(
    "[data-cancel-return]",
  );
  const changeAddress = document.querySelector<HTMLElement>(
    "[data-change-address]",
  );
  const target = createPaymentReturnTarget(request, { status: "cancelled" });
  if (
    target === undefined ||
    context === null ||
    host === null ||
    cancel === null
  ) {
    return;
  }
  host.textContent = target.host;
  cancel.href = target.href;
  cancel.textContent = `Cancel and return to ${target.host}`;
  context.hidden = false;
  if (defaultContext !== null) defaultContext.hidden = true;
  if (changeAddress !== null) changeAddress.hidden = true;
}

function activeSplitPolicy(execution: SplitExecutionInstruction) {
  return browserPayerRegistry.splitAdapters.find(
    (entry) =>
      entry.adapter === execution.adapter &&
      entry.chain === execution.chain &&
      entry.contract.toLowerCase() === execution.contract.toLowerCase() &&
      entry.status === "active",
  );
}

async function compileForReview(target: LiveResolution, optionIndex: number) {
  const compiled = await resolveBrowserExecutionPlan(
    target.source,
    optionIndex,
  );
  if (compiled.plan.execution.type !== "split") {
    return {
      plan: compiled.plan,
      priorEvidence: compiled.priorEvidence,
    };
  }
  const policy = activeSplitPolicy(compiled.plan.execution);
  if (policy === undefined) {
    throw new Error("unsupported_split_adapter");
  }
  return {
    plan: compiled.plan,
    priorEvidence: compiled.priorEvidence,
    adapterState: await verifySupportedSplitAdapter(
      compiled.plan.execution,
      policy,
      browserSplitConfigReader,
    ),
  };
}

async function resolveInput(input: InterpretedPaymentInput): Promise<void> {
  const current = ++operation;
  controller?.abort(new DOMException("Superseded", "AbortError"));
  controller = new AbortController();
  payment = undefined;
  resolution = undefined;
  wallet = undefined;
  fundingPlan = undefined;
  review.reset();
  showResolving(input.opid);
  try {
    const next = await resolveBrowserInput(input, controller.signal);
    if (current !== operation) return;
    resolution = next;
    showResolution(next);
    review.setResolution(next, input);
  } catch (cause) {
    if (current !== operation || controller.signal.aborted) return;
    const targetChange = paymentTargetChangeDetails(cause);
    if (targetChange !== undefined) {
      showTargetChangeConfirmation(targetChange, () => {
        void confirmChangedTarget(input, targetChange, current);
      });
      return;
    }
    showResolutionError(cause);
  }
}

async function confirmChangedTarget(
  input: InterpretedPaymentInput,
  details: NonNullable<ReturnType<typeof paymentTargetChangeDetails>>,
  current: number,
): Promise<void> {
  showResolving(input.opid);
  try {
    await acceptBrowserContinuityChange(
      details.oldEvidence,
      details.proposedEvidence,
    );
    const next = await resolveBrowserInput(input);
    if (current !== operation) return;
    resolution = next;
    showResolution(next);
    review.setResolution(next, input);
  } catch (cause) {
    if (current !== operation) return;
    const nextChange = paymentTargetChangeDetails(cause);
    if (nextChange !== undefined) {
      showTargetChangeConfirmation(nextChange, () => {
        void confirmChangedTarget(input, nextChange, current);
      });
      return;
    }
    showResolutionError(cause);
  }
}

async function connectWallet(): Promise<void> {
  if (!navigator.onLine) {
    walletStatus(
      "Offline",
      "On-chain payment controls are disabled until connectivity returns.",
      "error",
    );
    return;
  }
  const currentPayment = payment;
  if (currentPayment === undefined || currentPayment.type === "sepa") return;
  try {
    const chain = currentPayment.plan.execution.chain;
    walletStatus(
      "Connecting wallet…",
      "Your wallet will ask for account access and the supported test network.",
    );
    wallet = await WalletSession.connect(chainPolicy(chain));
    walletStatus("Wallet connected", wallet.account, "success");
    const readiness = document.querySelector<HTMLButtonElement>(
      "[data-check-readiness]",
    );
    if (readiness !== null) readiness.disabled = false;
  } catch (cause) {
    const message = typedErrorMessage(cause);
    walletStatus(
      message.title,
      cause instanceof Error && cause.message === "wallet_unavailable"
        ? "Install or enable an EIP-1193 wallet to continue."
        : message.detail,
      "error",
    );
  }
}

async function checkReadiness(): Promise<void> {
  if (!navigator.onLine) return;
  const currentPayment = payment;
  if (
    currentPayment === undefined ||
    currentPayment.type === "sepa" ||
    wallet === undefined
  )
    return;
  try {
    walletStatus(
      "Checking the payment…",
      "Checking the network, balance, fees and transaction before you continue.",
    );
    const readiness = await wallet.check(currentPayment);
    fundingPlan = readiness.fundingPlan;
    review.setFundingPlan(fundingPlan);
    const simulation =
      readiness.estimatedGas === undefined
        ? "Authorization is required; the combined call will be simulated after signature or approval."
        : `Simulation succeeded. Estimated gas: ${readiness.estimatedGas}.`;
    walletStatus(
      "Ready to review",
      `${simulation} Connected account: ${readiness.account}.`,
      "success",
    );
    review.setGasEstimate(readiness.estimatedGas);
    review.setReady(
      true,
      fundingPlan === undefined ? "Confirm test payment" : "Convert and pay",
    );
  } catch (cause) {
    walletStatus(
      "Readiness check failed",
      cause instanceof Error
        ? cause.message.replaceAll("_", " ")
        : "No payment was submitted.",
      "error",
    );
    review.setReady(false);
  }
}

async function freshCompare(
  currentPayment: ReviewedPayment,
): Promise<ResolvedExecutionPlan> {
  const currentPlan = currentPayment.plan;
  const fresh = await reResolveBrowserAndCompare(
    currentPlan,
    currentPayment.priorEvidence,
  );
  if (fresh.plan.execution.type === "split") {
    const policy = activeSplitPolicy(fresh.plan.execution);
    if (policy === undefined) throw new Error("unsupported_split_adapter");
    await verifySupportedSplitAdapter(
      fresh.plan.execution,
      policy,
      browserSplitConfigReader,
    );
  }
  return fresh;
}

async function presentSepaPayment(
  currentPayment: ReviewedSepaPayment,
  presentation: number,
): Promise<void> {
  try {
    await freshCompare(currentPayment);
    if (presentation !== sepaPresentation || payment !== currentPayment) return;
    const authorization = createPaymentAuthorization({
      plan: currentPayment.plan,
      amountAtomic: currentPayment.amountAtomic,
      ...(currentPayment.reference === undefined
        ? {}
        : { reference: currentPayment.reference }),
    });
    const handoff = buildSepaHandoff(currentPayment.plan, authorization);
    showSepaHandoff(
      currentPayment,
      handoff.paytoUri,
      returnTarget({ status: "handoff" }),
    );
    try {
      const qr = await createEpcQrImage(handoff.epcQrPayload);
      if (presentation !== sepaPresentation || payment !== currentPayment)
        return;
      showSepaQr(currentPayment, qr);
    } catch {
      if (presentation !== sepaPresentation || payment !== currentPayment)
        return;
      showSepaQrError();
    }
  } catch (cause) {
    if (presentation !== sepaPresentation || payment !== currentPayment) return;
    const message = typedErrorMessage(cause);
    const detail =
      cause instanceof Error
        ? `${message.detail} (${cause.message})`
        : message.detail;
    review.setExecutionError(message.title, detail);
  }
}

async function pay(): Promise<void> {
  const currentPayment = payment;
  if (currentPayment === undefined || resolution === undefined) return;
  if (currentPayment.type === "sepa") return;
  if (!navigator.onLine) {
    walletStatus(
      "Offline",
      "Payment execution is disabled while offline.",
      "error",
    );
    review.setReady(false);
    return;
  }
  review.setReady(false, "Verifying again…");
  try {
    await freshCompare(currentPayment);
    const authorization = createPaymentAuthorization({
      plan: currentPayment.plan,
      amountAtomic: currentPayment.amountAtomic,
      ...(currentPayment.reference === undefined
        ? {}
        : { reference: currentPayment.reference }),
    });
    if (wallet === undefined) throw new Error("wallet_not_connected");
    const readiness = await wallet.check(currentPayment);
    if (!sameFundingPlan(fundingPlan, readiness.fundingPlan)) {
      throw new Error("funding_plan_changed");
    }
    review.setReady(false, "Confirm in wallet…");
    const receipt =
      currentPayment.type === "erc20"
        ? fundingPlan === undefined
          ? await wallet.submitDirect(
              currentPayment,
              authorization,
              async () => {
                await freshCompare(currentPayment);
              },
            )
          : await wallet.submitConverted(
              currentPayment,
              authorization,
              fundingPlan,
              async () => {
                await freshCompare(currentPayment);
              },
            )
        : await wallet.submitSplit(currentPayment, authorization, async () => {
            await freshCompare(currentPayment);
          });
    await showOnchainReceipt(
      currentPayment,
      receipt,
      returnTarget({
        status: "confirmed",
        chain: currentPayment.plan.execution.chain,
        transactionHash: receipt.hash,
      }),
    );
    review.setReady(false, "Payment confirmed");
  } catch (cause) {
    const message = typedErrorMessage(cause);
    const detail =
      cause instanceof Error
        ? `${message.detail} (${cause.message})`
        : message.detail;
    review.setExecutionError(message.title, detail);
    walletStatus(message.title, detail, "error");
    review.setReady(true, "Retry test payment");
  }
}

function sameFundingPlan(
  reviewed: ConversionFundingPlan | undefined,
  fresh: ConversionFundingPlan | undefined,
): boolean {
  if (reviewed === undefined || fresh === undefined) return reviewed === fresh;
  return (
    reviewed.chain === fresh.chain &&
    reviewed.sourceAsset.toLowerCase() === fresh.sourceAsset.toLowerCase() &&
    reviewed.sourceAtomicAmount === fresh.sourceAtomicAmount &&
    reviewed.maxSourceAtomicAmount === fresh.maxSourceAtomicAmount &&
    reviewed.targetAsset.toLowerCase() === fresh.targetAsset.toLowerCase() &&
    reviewed.targetAtomicAmount === fresh.targetAtomicAmount &&
    reviewed.converter.toLowerCase() === fresh.converter.toLowerCase() &&
    reviewed.recipient.toLowerCase() === fresh.recipient.toLowerCase() &&
    reviewed.adapterCodeFingerprint === fresh.adapterCodeFingerprint
  );
}

document
  .querySelector<HTMLButtonElement>("[data-connect-wallet]")
  ?.addEventListener("click", () => void connectWallet());
document
  .querySelector<HTMLButtonElement>("[data-check-readiness]")
  ?.addEventListener("click", () => void checkReadiness());
review.onPay(() => void pay());

function resolvePaymentFromQuery(): void {
  const search = window.location.search;
  const query = new URLSearchParams(search);
  const opid = query.get("opid") ?? query.get("url") ?? query.get("text");
  const address = document.querySelector<HTMLElement>("[data-payment-address]");
  const error = document.querySelector<HTMLElement>(
    "[data-payment-page-error]",
  );
  const errorMessage = document.querySelector<HTMLElement>(
    "[data-payment-page-error-message]",
  );

  const showPageError = (message: string): void => {
    if (errorMessage !== null) errorMessage.textContent = message;
    if (error !== null) error.hidden = false;
  };

  window.history.replaceState(
    null,
    "",
    `${window.location.pathname}${window.location.hash}`,
  );
  try {
    const request = interpretPaymentRequest(search, document.referrer);
    pageRequest = request;
    initializePaymentRequestContext(request);
    if (address !== null) address.textContent = request.input.opid;
    void resolveInput(request.input);
  } catch (cause) {
    if (address !== null) address.textContent = opid ?? "No address selected";
    showPageError(
      cause instanceof TypeError && cause.message === "missing_opid"
        ? "Choose a payment address to begin."
        : "This payment link is invalid or tries to return to an unsafe website.",
    );
  }
}

resolvePaymentFromQuery();
initializeHistory();

interface InstallPromptEvent extends Event {
  prompt(): Promise<void>;
}

let installPrompt: InstallPromptEvent | undefined;
const installButton = document.querySelector<HTMLButtonElement>(
  "[data-install-button]",
);
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  installPrompt = event as InstallPromptEvent;
  if (installButton !== null) installButton.hidden = false;
});
installButton?.addEventListener("click", async () => {
  await installPrompt?.prompt();
  installPrompt = undefined;
  installButton.hidden = true;
});

function updateNetworkStatus(): void {
  const online = navigator.onLine;
  if (!online) {
    ++sepaPresentation;
    clearReceipt();
    review.setReady(false);
  } else if (payment?.type === "sepa") {
    const presentation = ++sepaPresentation;
    clearReceipt();
    void presentSepaPayment(payment, presentation);
  }
}
window.addEventListener("online", updateNetworkStatus);
window.addEventListener("offline", updateNetworkStatus);
updateNetworkStatus();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    void navigator.serviceWorker.register("/sw.js").then((registration) => {
      if (registration.waiting !== null) void registration.update();
    });
  });
}
document.documentElement.dataset.enhanced = "true";
