import {
  interpretPaymentInput,
  type InterpretedPaymentInput,
} from "./payment-input";

const MAX_AMOUNT_LENGTH = 80;
const MAX_REFERENCE_LENGTH = 140;
const MAX_RETURN_URL_LENGTH = 2048;
const MAX_STATE_LENGTH = 256;

export interface PaymentPageRequest {
  readonly input: InterpretedPaymentInput;
  readonly returnUrl?: string;
  readonly state?: string;
}

export type PaymentReturnResult =
  | { readonly status: "cancelled" | "handoff" }
  | {
      readonly status: "confirmed";
      readonly chain: string;
      readonly transactionHash: string;
    };

export interface PaymentReturnTarget {
  readonly href: string;
  readonly host: string;
  readonly status: PaymentReturnResult["status"];
}

function singleValue(
  query: URLSearchParams,
  names: readonly string[],
): string | undefined {
  const values = names.flatMap((name) => query.getAll(name));
  if (values.length > 1) throw new TypeError("duplicate_payment_argument");
  return values[0];
}

function paymentAmount(value: string | undefined): string | undefined {
  if (value === undefined) return undefined;
  const amount = value.trim();
  if (
    amount.length === 0 ||
    amount.length > MAX_AMOUNT_LENGTH ||
    !/^(0|[1-9][0-9]*)(?:\.[0-9]+)?$/.test(amount) ||
    /^0(?:\.0+)?$/.test(amount)
  ) {
    throw new TypeError("invalid_payment_amount");
  }
  return amount;
}

function paymentCurrency(value: string | undefined): string | undefined {
  if (value === undefined) return undefined;
  const currency = value.trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) {
    throw new TypeError("invalid_payment_currency");
  }
  return currency;
}

function paymentReference(value: string | undefined): string | undefined {
  if (value === undefined) return undefined;
  const reference = value.trim();
  if (reference.length === 0) return undefined;
  const hasControlCharacter = [...reference].some((character) => {
    const codePoint = character.codePointAt(0);
    return codePoint !== undefined && (codePoint < 32 || codePoint === 127);
  });
  if (reference.length > MAX_REFERENCE_LENGTH || hasControlCharacter) {
    throw new TypeError("invalid_payment_reference");
  }
  return reference;
}

function returnOriginFromReferrer(
  referrer: string | undefined,
): string | undefined {
  if (referrer === undefined || referrer.length === 0) return undefined;
  try {
    const url = new URL(referrer);
    if (
      url.protocol !== "https:" ||
      url.username.length > 0 ||
      url.password.length > 0
    ) {
      return undefined;
    }
    return url.origin;
  } catch {
    return undefined;
  }
}

function paymentReturnUrl(
  value: string | undefined,
  opid: string,
  referrer: string | undefined,
): string | undefined {
  if (value === undefined) return undefined;
  if (
    value.length === 0 ||
    value.length > MAX_RETURN_URL_LENGTH ||
    value !== value.trim()
  ) {
    throw new TypeError("invalid_return_url");
  }

  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new TypeError("invalid_return_url");
  }
  if (
    url.protocol !== "https:" ||
    url.username.length > 0 ||
    url.password.length > 0 ||
    url.hash.length > 0
  ) {
    throw new TypeError("invalid_return_url");
  }

  const trustedOrigins = new Set([new URL(opid).origin]);
  const referrerOrigin = returnOriginFromReferrer(referrer);
  if (referrerOrigin !== undefined) trustedOrigins.add(referrerOrigin);
  if (!trustedOrigins.has(url.origin)) {
    throw new TypeError("untrusted_return_origin");
  }
  return url.href;
}

function paymentState(
  value: string | undefined,
  returnUrl: string | undefined,
): string | undefined {
  if (value === undefined) return undefined;
  if (
    returnUrl === undefined ||
    value.length === 0 ||
    value.length > MAX_STATE_LENGTH ||
    !/^[A-Za-z0-9._~-]+$/.test(value)
  ) {
    throw new TypeError("invalid_payment_state");
  }
  return value;
}

export function interpretPaymentRequest(
  search: string,
  referrer?: string,
): PaymentPageRequest {
  const query = new URLSearchParams(search);
  const opidValue = singleValue(query, ["opid", "url", "text"]);
  if (opidValue === undefined) throw new TypeError("missing_opid");

  const baseInput = interpretPaymentInput(opidValue);
  const amount = paymentAmount(singleValue(query, ["amount"]));
  const currency = paymentCurrency(singleValue(query, ["currency"]));
  const reference = paymentReference(singleValue(query, ["reference"]));
  const returnUrl = paymentReturnUrl(
    singleValue(query, ["return_url"]),
    baseInput.opid,
    referrer,
  );
  const state = paymentState(singleValue(query, ["state"]), returnUrl);

  return Object.freeze({
    input: Object.freeze({
      ...baseInput,
      ...(amount === undefined ? {} : { amount }),
      ...(currency === undefined ? {} : { currency }),
      ...(reference === undefined ? {} : { reference }),
    }),
    ...(returnUrl === undefined ? {} : { returnUrl }),
    ...(state === undefined ? {} : { state }),
  });
}

export function createPaymentReturnTarget(
  request: PaymentPageRequest,
  result: PaymentReturnResult,
): PaymentReturnTarget | undefined {
  if (request.returnUrl === undefined) return undefined;

  const url = new URL(request.returnUrl);
  url.searchParams.set("status", result.status);
  url.searchParams.delete("chain");
  url.searchParams.delete("transaction_hash");
  if (request.state === undefined) {
    url.searchParams.delete("state");
  } else {
    url.searchParams.set("state", request.state);
  }
  if (result.status === "confirmed") {
    url.searchParams.set("chain", result.chain);
    url.searchParams.set("transaction_hash", result.transactionHash);
  }

  return Object.freeze({
    href: url.href,
    host: url.host,
    status: result.status,
  });
}
