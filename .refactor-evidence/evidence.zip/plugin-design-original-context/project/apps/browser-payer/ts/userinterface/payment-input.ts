import { normalizeOpid } from "@opap/core";

export interface InterpretedPaymentInput {
  readonly sourceKind: "opid";
  readonly opid: string;
  readonly amount?: string;
  readonly currency?: string;
  readonly reference?: string;
}

export function interpretPaymentInput(input: string): InterpretedPaymentInput {
  const trimmed = input.trim();
  if (trimmed.length === 0 || trimmed.length > 512) {
    throw new TypeError("invalid_input_length");
  }
  const opid = trimmed.includes("://") ? trimmed : `https://${trimmed}`;
  return { sourceKind: "opid", opid: normalizeOpid(opid) };
}

function showCreateOpidWarning(error: HTMLElement): void {
  const title = document.createElement("p");
  title.className = "font-black";
  title.textContent = "The URL you entered is not an OPID (Open Payment ID).";
  const link = document.createElement("a");
  link.className =
    "mt-3 inline-flex min-h-10 items-center rounded-lg bg-amber-900 px-3 text-sm font-black text-white hover:bg-amber-950";
  link.href = "/create/";
  link.textContent = "Create an OPID and follow the instructions →";
  error.className =
    "mt-3 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950";
  error.replaceChildren(title, link);
  error.hidden = false;
}

export function initializePaymentInput(
  onResolve: (input: InterpretedPaymentInput) => void,
  onScan: () => void,
): void {
  const form = document.querySelector<HTMLFormElement>(
    "[data-payment-input-form]",
  );
  const input = document.querySelector<HTMLInputElement>(
    "[data-payment-input]",
  );
  const error = document.querySelector<HTMLElement>("[data-input-error]");
  const scan = document.querySelector<HTMLButtonElement>("[data-scan-button]");
  if (form === null || input === null || error === null || scan === null)
    return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    try {
      error.hidden = true;
      error.classList.add("hidden");
      onResolve(interpretPaymentInput(input.value));
    } catch {
      showCreateOpidWarning(error);
      input.focus();
    }
  });
  scan.addEventListener("click", onScan);
  document
    .querySelectorAll<HTMLButtonElement>("[data-fixture]")
    .forEach((button) => {
      button.addEventListener("click", () => {
        input.value =
          button.dataset.fixture === "split"
            ? "https://split.local.example/"
            : "https://direct.local.example/";
        input.form?.requestSubmit();
      });
    });
}
