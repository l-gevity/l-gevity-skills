import QRCode from "qrcode";

export async function createEpcQrImage(
  payload: string,
): Promise<HTMLImageElement> {
  const source = await QRCode.toDataURL(payload, {
    errorCorrectionLevel: "M",
    margin: 2,
    width: 360,
  });
  const image = document.createElement("img");
  image.className = "mx-auto h-auto w-full max-w-[22.5rem] rounded-xl";
  image.dataset.epcQr = "";
  image.width = 360;
  image.height = 360;
  image.decoding = "async";
  image.src = source;
  return image;
}
