import {
  normalizeOpid,
  deriveSplitConfigId,
  derivePathKey,
  deriveRecordUrl,
  OPAP_SPLIT_ADAPTER,
  validateOpapRecordBytes,
  type OpapRecord,
  type PaymentOption,
} from "@opap/core";

interface CreatorBaseInput {
  readonly opid: string;
  readonly displayName: string;
}

export interface CreatorSepaOptionInput {
  readonly type: "sepa";
  readonly name: string;
  readonly iban: string;
}

interface CreatorErc20BaseInput {
  readonly chainId: string;
  readonly currency: string;
  readonly asset: string;
}

export interface CreatorErc20OptionInput extends CreatorErc20BaseInput {
  readonly type: "erc20";
  readonly recipient: string;
  readonly symbol: string;
}

export interface CreatorSplitRecipientAllocationInput {
  readonly type: "recipient";
  readonly recipient: string;
  readonly sharePpm: number;
}

export interface CreatorSplitTargetAllocationInput {
  readonly type: "target";
  readonly target: string;
  readonly sharePpm: number;
}

export type CreatorSplitAllocationInput =
  CreatorSplitRecipientAllocationInput | CreatorSplitTargetAllocationInput;

export interface CreatorSplitOptionInput extends CreatorErc20BaseInput {
  readonly type: "split";
  readonly contract: string;
  readonly configId: string;
  readonly allocations: readonly CreatorSplitAllocationInput[];
}

export type CreatorPaymentOptionInput =
  CreatorSepaOptionInput | CreatorErc20OptionInput | CreatorSplitOptionInput;

export interface CreatorOptionsInput extends CreatorBaseInput {
  readonly mode: "options";
  readonly options: readonly CreatorPaymentOptionInput[];
}

export interface CreatorDelegateInput extends CreatorBaseInput {
  readonly mode: "delegate";
  readonly delegateTarget: string;
}

export type CreatorInput = CreatorOptionsInput | CreatorDelegateInput;

export interface CreatedOpid {
  readonly opid: string;
  readonly publicationUrl: string;
  readonly proofUrl: string;
  readonly filename: string;
  readonly record: OpapRecord;
  readonly json: string;
}

function cleanIban(value: string): string {
  return value.replaceAll(/\s/g, "").toUpperCase();
}

function cleanAddress(value: string): string {
  return value.trim().toLowerCase();
}

export function sharePercentToPpm(value: string): number {
  const match = /^([0-9]{1,3})(?:\.([0-9]{1,4}))?$/.exec(value.trim());
  if (match?.[1] === undefined) throw new TypeError("invalid_share_percent");
  const whole = Number.parseInt(match[1], 10);
  const fractional = Number.parseInt((match[2] ?? "").padEnd(4, "0"), 10);
  const sharePpm = whole * 10_000 + fractional;
  if (sharePpm <= 0 || sharePpm >= 1_000_000) {
    throw new RangeError("invalid_share_percent");
  }
  return sharePpm;
}

function paymentOption(input: CreatorPaymentOptionInput): PaymentOption {
  if (input.type === "sepa") {
    return {
      type: "sepa",
      currency: "EUR",
      name: input.name.trim(),
      iban: cleanIban(input.iban),
    };
  }

  const chain = `eip155:${input.chainId.trim()}`;
  const currency = input.currency.trim().toUpperCase();
  const asset = cleanAddress(input.asset);
  if (input.type === "erc20") {
    const symbol = input.symbol.trim();
    return {
      type: "erc20",
      currency,
      chain,
      asset,
      recipient: cleanAddress(input.recipient),
      ...(symbol.length === 0 ? {} : { symbol }),
    };
  }

  const contract = cleanAddress(input.contract);
  const allocations = input.allocations.map((allocation) =>
    allocation.type === "recipient"
      ? {
          recipient: cleanAddress(allocation.recipient),
          share_ppm: allocation.sharePpm,
        }
      : {
          target: normalizeOpid(allocation.target.trim()),
          share_ppm: allocation.sharePpm,
        },
  );
  const execution = { chain, asset, contract };
  const hasTargets = input.allocations.some(
    (allocation) => allocation.type === "target",
  );
  const configId = hasTargets
    ? input.configId.trim().toLowerCase()
    : deriveSplitConfigId(
        execution,
        input.allocations.map((allocation) => {
          if (allocation.type !== "recipient") {
            throw new TypeError("target_config_id_required");
          }
          return {
            recipient: cleanAddress(allocation.recipient),
            share_ppm: allocation.sharePpm,
          };
        }),
      );
  return {
    type: "split",
    currency,
    execution: {
      type: "erc20-contract",
      adapter: OPAP_SPLIT_ADAPTER,
      ...execution,
      config_id: configId,
    },
    allocations,
  };
}

function recordPayment(input: CreatorInput): OpapRecord["payment"] {
  if (input.mode === "delegate") {
    return {
      type: "delegate",
      target: normalizeOpid(input.delegateTarget.trim()),
    };
  }

  return {
    type: "options",
    options: input.options.map(paymentOption),
  };
}

export function createOpidRecord(
  input: CreatorInput,
  now: Date = new Date(),
): CreatedOpid {
  const opid = normalizeOpid(input.opid.trim());
  const displayName = input.displayName.trim();
  const issuedAt = new Date(Math.floor(now.getTime() / 1_000) * 1_000);
  if (!Number.isFinite(issuedAt.getTime()))
    throw new TypeError("invalid current time");
  const expiresAt = new Date(issuedAt.getTime() + 30 * 24 * 60 * 60 * 1_000);
  const candidate: OpapRecord = {
    version: 1,
    id: opid,
    revision: 1,
    issued_at: issuedAt.toISOString().replace(".000Z", "Z"),
    expires_at: expiresAt.toISOString().replace(".000Z", "Z"),
    ...(displayName.length === 0 ? {} : { name: displayName }),
    payment: recordPayment(input),
  };
  const json = `${JSON.stringify(candidate, null, 2)}\n`;
  const record = validateOpapRecordBytes(new TextEncoder().encode(json), opid);
  const publicationUrl = `${deriveRecordUrl(opid)}.json`;
  return {
    opid,
    publicationUrl,
    proofUrl: `${publicationUrl}.proof`,
    filename: `${derivePathKey(opid)}.json`,
    record,
    json,
  };
}
