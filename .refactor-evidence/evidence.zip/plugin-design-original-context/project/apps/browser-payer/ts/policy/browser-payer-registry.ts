import { OpapError, type AssetRegistry } from "@opap/core";
import type { SplitAdapterPolicy } from "@opap/runtime";

import releaseRegistry from "../../../../registry/browser-payer-v1.json";

export interface ChainPolicy {
  readonly caip2: string;
  readonly chainId: number;
  readonly name: string;
  readonly nativeCurrency: {
    readonly name: string;
    readonly symbol: string;
    readonly decimals: number;
  };
  readonly rpcUrls: readonly string[];
  readonly explorerUrl: string | null;
  readonly environment: "local" | "test" | "production";
  readonly status: "active" | "blocked";
}

export interface BrowserSplitAdapterPolicy extends SplitAdapterPolicy {
  readonly environment: "local" | "test" | "production";
  readonly provenance: string;
}

export interface ConversionAdapterPolicy {
  readonly adapter: "org.openpayments/fixed-rate-local-v1";
  readonly chain: string;
  readonly sourceAsset: string;
  readonly targetAsset: string;
  readonly contract: string;
  readonly codeFingerprint: `sha256:${string}`;
  readonly status: "active" | "blocked";
  readonly environment: "local" | "test" | "production";
  readonly provenance: string;
}

export interface BrowserPayerRegistry extends AssetRegistry {
  readonly chains: readonly ChainPolicy[];
  readonly splitAdapters: readonly BrowserSplitAdapterPolicy[];
  readonly conversionAdapters: readonly ConversionAdapterPolicy[];
}

export const browserPayerRegistry = releaseRegistry as BrowserPayerRegistry;

export function chainPolicy(chain: string): ChainPolicy {
  const policy = browserPayerRegistry.chains.find(
    (candidate) => candidate.caip2 === chain,
  );
  if (policy === undefined || policy.status !== "active") {
    throw new OpapError("unrecognized_asset", `chain:${chain}`);
  }
  return policy;
}
