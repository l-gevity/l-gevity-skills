import {
  NO_CONTINUITY_EVIDENCE,
  OpapError,
  type AvailableContinuityEvidence,
  type ExecutionPlan,
  type PriorContinuityEvidence,
} from "@opap/core";
import {
  createGoogleDnsResolver,
  reResolveAndCompare,
  resolveExecutionPlan,
  resolveOpid,
  type FetchAdapter,
  type LiveResolution,
  type ResolvedExecutionPlan,
  type ResolutionOptions,
} from "@opap/runtime";

import directFixture from "../../fixtures/direct-local.json";
import splitFixture from "../../fixtures/split-local.json";
import { getBrowserHistoryAdapters } from "../storage/browser-history";

const fixtureRecords = new Map<string, unknown>([
  [
    "https://direct.local.example/.well-known/open-payment/record/Lw",
    directFixture,
  ],
  [
    "https://split.local.example/.well-known/open-payment/record/Lw",
    splitFixture,
  ],
]);

const fixtureFetch: FetchAdapter = async (url) => {
  const record = fixtureRecords.get(url);
  if (record === undefined) return new Response(null, { status: 404 });
  return new Response(JSON.stringify(record), {
    status: 200,
    headers: {
      "access-control-allow-origin": "*",
      "access-control-expose-headers": "OPAP-Proof",
      "cache-control": "no-store",
      "content-type": "application/opap+json",
    },
  });
};

function isLocalFixture(opid: string): boolean {
  return (
    typeof location !== "undefined" &&
    ["localhost", "127.0.0.1"].includes(location.hostname) &&
    (opid === "https://direct.local.example/" ||
      opid === "https://split.local.example/")
  );
}

function createBrowserFetchAdapter(origin: string): FetchAdapter {
  return async (input, init) => {
    const target = new URL(input);
    if (target.origin === origin) {
      return await globalThis.fetch(input, init);
    }

    const response = await globalThis.fetch(`${origin}/api/opap-record`, {
      body: JSON.stringify({ url: input }),
      cache: "no-store",
      credentials: "omit",
      headers: {
        accept: "application/opap+json, application/json;q=0.9",
        "content-type": "application/json",
      },
      method: "POST",
      redirect: "error",
      ...(init.signal == null ? {} : { signal: init.signal }),
    });
    if (
      response.status === 403 &&
      response.headers.get("opap-relay-error") === "target_address_forbidden"
    ) {
      throw new OpapError(
        "target_address_forbidden",
        `cloudflare_relay_rejected_target:${target.hostname}`,
      );
    }
    return response;
  };
}

export function resolutionOptions(
  opid: string,
  priorEvidence: PriorContinuityEvidence = NO_CONTINUITY_EVIDENCE,
): ResolutionOptions {
  if (isLocalFixture(opid)) {
    return {
      fetch: fixtureFetch,
      dns: { resolveTxt: async () => ({ status: "insecure", records: [] }) },
      priorEvidence,
    };
  }

  if (typeof location === "undefined") {
    throw new OpapError(
      "target_address_forbidden",
      "browser_cannot_pin_validated_peer_address",
    );
  }

  return {
    // Same-origin records stay direct. Cross-origin records use the narrow
    // Cloudflare relay so provider-enforced public egress replaces the peer
    // address pinning that browser fetch cannot expose.
    fetch: createBrowserFetchAdapter(location.origin),
    dns: createGoogleDnsResolver(),
    priorEvidence,
  };
}

export async function resolveBrowserInput(
  input: { readonly opid: string },
  signal?: AbortSignal,
): Promise<LiveResolution> {
  return await getBrowserHistoryAdapters().continuity.run(
    async (priorEvidence) =>
      await resolveOpid(input.opid, {
        ...resolutionOptions(input.opid, priorEvidence),
        ...(signal === undefined ? {} : { signal }),
      }),
    false,
  );
}

export async function resolveBrowserExecutionPlan(
  opid: string,
  optionIndex: number,
  signal?: AbortSignal,
): Promise<ResolvedExecutionPlan> {
  return await getBrowserHistoryAdapters().continuity.run(
    async (priorEvidence) =>
      await resolveExecutionPlan(opid, optionIndex, {
        ...resolutionOptions(opid, priorEvidence),
        ...(signal === undefined ? {} : { signal }),
      }),
  );
}

export async function reResolveBrowserAndCompare(
  plan: ExecutionPlan,
  priorEvidence: PriorContinuityEvidence,
  signal?: AbortSignal,
): Promise<ResolvedExecutionPlan> {
  return await reResolveAndCompare(plan, {
    ...resolutionOptions(plan.root_opid, priorEvidence),
    ...(signal === undefined ? {} : { signal }),
  });
}

export async function acceptBrowserContinuityChange(
  oldEvidence: AvailableContinuityEvidence,
  proposedEvidence: AvailableContinuityEvidence,
): Promise<void> {
  await getBrowserHistoryAdapters().continuity.acceptChange(
    oldEvidence,
    proposedEvidence,
  );
}
