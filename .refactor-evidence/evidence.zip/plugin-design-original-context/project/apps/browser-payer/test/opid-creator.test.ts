import { describe, expect, it } from "vitest";
import {
  createOpidRecord,
  sharePercentToPpm,
  type CreatorOptionsInput,
} from "../ts/userinterface/opid-creator";

const base: CreatorOptionsInput = {
  opid: "https://BÜCHER.example/donate",
  displayName: "Example Foundation",
  mode: "options",
  options: [
    {
      type: "sepa",
      name: "Example Foundation",
      iban: "NL96 TEST 0000 0000 00",
    },
  ],
};

describe("URL OPID creator", () => {
  it("creates a root/path record at the deterministic publication URL", () => {
    const created = createOpidRecord(base, new Date("2026-07-22T12:00:00Z"));
    expect(created.opid).toBe("https://xn--bcher-kva.example/donate");
    expect(created.publicationUrl).toBe(
      "https://xn--bcher-kva.example/.well-known/open-payment/record/L2RvbmF0ZQ.json",
    );
    expect(created.proofUrl).toBe(
      "https://xn--bcher-kva.example/.well-known/open-payment/record/L2RvbmF0ZQ.json.proof",
    );
    expect(created.filename).toBe("L2RvbmF0ZQ.json");
    expect(created.record).toMatchObject({
      revision: 1,
      issued_at: "2026-07-22T12:00:00Z",
      expires_at: "2026-08-21T12:00:00Z",
    });
  });
  it("accepts a bare domain and stores its canonical root URL", () => {
    expect(
      createOpidRecord({ ...base, opid: "https://payments.example" }).opid,
    ).toBe("https://payments.example/");
  });

  it("creates a canonical URL delegation", () => {
    expect(
      createOpidRecord({
        opid: base.opid,
        displayName: base.displayName,
        mode: "delegate",
        delegateTarget: "https://merchant.example/",
      }).record.payment,
    ).toEqual({ type: "delegate", target: "https://merchant.example/" });
  });
  it("rejects an invalid IBAN checksum", () => {
    expect(() =>
      createOpidRecord({
        ...base,
        options: [
          {
            type: "sepa",
            name: "Example Foundation",
            iban: "NL00TEST0000000000",
          },
        ],
      }),
    ).toThrowError(expect.objectContaining({ code: "invalid_record" }));
  });

  it("preserves the receiver's ordered payment options", () => {
    const payment = createOpidRecord({
      ...base,
      options: [
        {
          type: "erc20",
          chainId: "100",
          currency: "eur",
          asset: `0x${"A".repeat(40)}`,
          recipient: `0x${"B".repeat(40)}`,
          symbol: "EURe",
        },
        base.options[0]!,
      ],
    }).record.payment;

    expect(payment).toMatchObject({
      type: "options",
      options: [{ type: "erc20" }, { type: "sepa" }],
    });
  });

  it("creates an atomic split option and derives its configuration ID", () => {
    const payment = createOpidRecord({
      ...base,
      options: [
        {
          type: "split",
          chainId: "100",
          currency: "EUR",
          asset: `0x${"1".repeat(40)}`,
          contract: `0x${"2".repeat(40)}`,
          configId: "",
          allocations: [
            {
              type: "recipient",
              recipient: `0x${"3".repeat(40)}`,
              sharePpm: 600_000,
            },
            {
              type: "recipient",
              recipient: `0x${"4".repeat(40)}`,
              sharePpm: 400_000,
            },
          ],
        },
      ],
    }).record.payment;

    expect(payment).toMatchObject({
      type: "options",
      options: [
        {
          type: "split",
          execution: {
            type: "erc20-contract",
            adapter: "org.openpayments/split-v1",
            chain: "eip155:100",
            config_id: expect.stringMatching(/^0x[a-f0-9]{64}$/),
          },
          allocations: [{ share_ppm: 600_000 }, { share_ppm: 400_000 }],
        },
      ],
    });
  });

  it("creates an OPID-targeted split with the deployed root config", () => {
    const configId = `0x${"A".repeat(64)}`;
    const payment = createOpidRecord({
      ...base,
      options: [
        {
          type: "split",
          chainId: "100",
          currency: "EUR",
          asset: `0x${"1".repeat(40)}`,
          contract: `0x${"2".repeat(40)}`,
          configId,
          allocations: [
            {
              type: "target",
              target: "https://BÜCHER.example/alice",
              sharePpm: 600_000,
            },
            {
              type: "recipient",
              recipient: `0x${"4".repeat(40)}`,
              sharePpm: 400_000,
            },
          ],
        },
      ],
    }).record.payment;

    expect(payment).toMatchObject({
      type: "options",
      options: [
        {
          type: "split",
          execution: {
            config_id: configId.toLowerCase(),
          },
          allocations: [
            {
              target: "https://xn--bcher-kva.example/alice",
              share_ppm: 600_000,
            },
            { recipient: `0x${"4".repeat(40)}`, share_ppm: 400_000 },
          ],
        },
      ],
    });
  });

  it("requires a deployed configuration ID for an OPID-targeted split", () => {
    expect(() =>
      createOpidRecord({
        ...base,
        options: [
          {
            type: "split",
            chainId: "100",
            currency: "EUR",
            asset: `0x${"1".repeat(40)}`,
            contract: `0x${"2".repeat(40)}`,
            configId: "",
            allocations: [
              {
                type: "target",
                target: "https://alice.example/",
                sharePpm: 600_000,
              },
              {
                type: "recipient",
                recipient: `0x${"3".repeat(40)}`,
                sharePpm: 400_000,
              },
            ],
          },
        ],
      }),
    ).toThrowError(expect.objectContaining({ code: "invalid_record" }));
  });

  it("converts decimal percentages to exact parts per million", () => {
    expect(sharePercentToPpm("33.3333")).toBe(333_333);
    expect(sharePercentToPpm("50")).toBe(500_000);
    expect(() => sharePercentToPpm("0")).toThrow("invalid_share_percent");
    expect(() => sharePercentToPpm("100")).toThrow("invalid_share_percent");
    expect(() => sharePercentToPpm("12.34567")).toThrow(
      "invalid_share_percent",
    );
  });
});
