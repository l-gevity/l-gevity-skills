import { describe, expect, it } from "vitest";

import {
  NO_CONTINUITY_EVIDENCE,
  createExecutionPlan,
  fingerprintCanonicalJson,
  type AssetRegistry,
  type ExecutionPlan,
  type JsonObject,
  type SplitContractState,
} from "@opap/core";

import { buildReviewedPayment } from "../ts/paymentrouting/reviewed-payment";

const chain = "eip155:31337";
const asset = "0x1111111111111111111111111111111111111111";
const contract = "0x2222222222222222222222222222222222222222";
const configId = `0x${"a".repeat(64)}`;
const registry: AssetRegistry = {
  version: "2026-07-24.1",
  assets: [
    {
      chain,
      asset,
      name: "Test USD",
      symbol: "USDo",
      decimals: 2,
      currency: "USD",
      transferProfile: "erc20-standard",
      status: "active",
      environment: "local",
      provenance: "test",
      codeFingerprint: `sha256:${"b".repeat(64)}`,
      fingerprint: `sha256:${"c".repeat(64)}`,
    },
  ],
};

function executionPlan(
  execution: ExecutionPlan["execution"],
  optionProjection: JsonObject,
): ExecutionPlan {
  const targetProjection = { options: [optionProjection] };
  return createExecutionPlan({
    version: 1,
    protocol: "OPAP/1",
    root_opid: "https://example.com/",
    prior_evidence: "none",
    graph: {
      nodes: [
        {
          opid: "https://example.com/",
          hostname: "example.com",
          record_url: "https://example.com/.well-known/open-payment/record/Lw",
          revision: 1,
          expires_at: "2026-08-21T12:00:00Z",
          record_fingerprint: `sha256:${"d".repeat(64)}`,
          binding: "https",
          continuity: "none",
          history: "none",
          transport: {
            profile: "strict",
            proof_source: "none",
            cache: "no-store",
            media_type: "application/json",
          },
          target_projection: targetProjection,
          target_fingerprint: fingerprintCanonicalJson(targetProjection),
          selection: {
            option_index: 0,
            option_projection: optionProjection,
          },
        },
      ],
      edges: [],
    },
    execution,
  });
}

describe("reviewed payment planning", () => {
  it("builds an immutable direct payment independently from the UI", () => {
    const option = {
      type: "erc20",
      currency: "USD",
      chain,
      asset,
      recipient: "0x3333333333333333333333333333333333333333",
    } as const;
    const plan = executionPlan(
      {
        ...option,
        source_opid: "https://example.com/",
        source_option_index: 0,
      },
      option,
    );

    const payment = buildReviewedPayment(
      {
        plan,
        amount: " 12.34 ",
        currency: "USD",
        reference: " invoice-7 ",
        priorEvidence: NO_CONTINUITY_EVIDENCE,
      },
      registry,
    );

    expect(payment).toMatchObject({
      type: "erc20",
      amount: "12.34",
      amountAtomic: 1234n,
      reference: "invoice-7",
      assetProfile: { symbol: "USDo", decimals: 2 },
    });
    expect(Object.isFrozen(payment)).toBe(true);
  });

  it("builds deterministic split allocations only with verified adapter state", () => {
    const allocations = [
      {
        recipient: "0x3333333333333333333333333333333333333333",
        share_ppm: 600_000,
      },
      {
        recipient: "0x4444444444444444444444444444444444444444",
        share_ppm: 400_000,
      },
    ] as const;
    const option = {
      type: "split",
      currency: "USD",
      adapter: "org.openpayments/split-v1",
      chain,
      asset,
      contract,
      config_id: configId,
      allocations,
    } as const;
    const plan = executionPlan(
      {
        type: "split",
        source_opid: "https://example.com/",
        source_option_index: 0,
        currency: option.currency,
        adapter: option.adapter,
        chain: option.chain,
        asset: option.asset,
        contract: option.contract,
        config_id: option.config_id,
        allocations,
      },
      option,
    );
    const input = {
      plan,
      amount: "1.01",
      currency: "USD",
      priorEvidence: NO_CONTINUITY_EVIDENCE,
    } as const;

    expect(() => buildReviewedPayment(input, registry)).toThrowError(
      expect.objectContaining({
        code: "split_config_mismatch",
        diagnostic: "not_validated",
      }),
    );

    const adapterState: SplitContractState = {
      chain,
      contract,
      token: asset,
      configId,
      recipients: allocations.map(({ recipient }) => recipient),
      sharesPpm: allocations.map(({ share_ppm }) => share_ppm),
      immutable: true,
      codeFingerprint: `sha256:${"e".repeat(64)}`,
    };
    const payment = buildReviewedPayment({ ...input, adapterState }, registry);

    expect(payment).toMatchObject({
      type: "split",
      amountAtomic: 101n,
      allocations: [
        { sharePpm: 600_000, atomicAmount: "60" },
        { sharePpm: 400_000, atomicAmount: "41" },
      ],
    });
  });
});
