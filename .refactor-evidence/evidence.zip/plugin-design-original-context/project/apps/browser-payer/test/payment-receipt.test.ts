import { describe, expect, it } from "vitest";

import { bankingAppHref } from "../ts/userinterface/payment-receipt";

const paytoUri =
  "payto://iban/NL96TEST0000000000?amount=EUR%3A12.30&message=Invoice+42";

describe("banking-app handoff", () => {
  it("uses an Android intent so Chrome can dispatch to a banking app", () => {
    expect(
      bankingAppHref(
        paytoUri,
        "Mozilla/5.0 (Linux; Android 16; Pixel 9) AppleWebKit/537.36 Chrome/138.0.0.0 Mobile Safari/537.36",
      ),
    ).toBe(
      "intent://iban/NL96TEST0000000000?amount=EUR%3A12.30&message=Invoice+42#Intent;scheme=payto;end",
    );
  });

  it("keeps the standard payto URI on other platforms", () => {
    expect(
      bankingAppHref(
        paytoUri,
        "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X)",
      ),
    ).toBe(paytoUri);
  });
});
