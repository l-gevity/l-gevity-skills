import { describe, expect, it } from "vitest";

import type { OptionsResolution } from "@opap/core";

import { executablePaymentOptions } from "../ts/paymentrouting/reviewed-payment";
import { browserPayerRegistry } from "../ts/policy/browser-payer-registry";

const recipient = "0x2222222222222222222222222222222222222222";
const baseResolution = {
  status: "resolved",
  paymentType: "options",
  source: "https://example.com/multi",
  resolvedTo: "https://example.com/multi",
  records: [],
} as const;

describe("Browser Payer exact release policy", () => {
  it("preserves record preference order while omitting blocked, lookalike and mismatched handlers", () => {
    const resolution: OptionsResolution = {
      ...baseResolution,
      options: [
        {
          type: "erc20",
          currency: "EUR",
          chain: "eip155:100",
          asset: "0x420ca0f9b9b604ce0fd9c18ef134c705e5fa3430",
          recipient,
          symbol: "EURe",
        },
        {
          type: "erc20",
          currency: "GBP",
          chain: "eip155:10200",
          asset: "0x436af2954bb436b6821ab401112092e14cdbd546",
          recipient,
          symbol: "GBPe",
        },
        {
          type: "erc20",
          currency: "EUR",
          chain: "eip155:10200",
          asset: "0x1111111111111111111111111111111111111111",
          recipient,
          symbol: "EURe",
        },
        {
          type: "erc20",
          currency: "EUR",
          chain: "eip155:10200",
          asset: "0x7a47605930002cc2cd2c3c408d1f33fc2a18ab71",
          recipient,
          symbol: "NOT-EURE",
        },
        {
          type: "erc20",
          currency: "USD",
          chain: "eip155:10200",
          asset: "0x8bf987c9d041176758fe9c1180885bd4da011a5a",
          recipient,
        },
        {
          type: "erc20",
          currency: "ISK",
          chain: "eip155:10200",
          asset: "0x7e8e03b84eacb1798493145cc4ab9b562563456c",
          recipient,
          symbol: "ISKe",
        },
        {
          type: "erc20",
          currency: "EUR",
          chain: "eip155:10200",
          asset: "0x8bf987c9d041176758fe9c1180885bd4da011a5a",
          recipient,
          symbol: "USDe",
        },
      ],
    };

    const executable = executablePaymentOptions(resolution);

    expect(executable.map(({ index }) => index)).toEqual([1, 3, 4, 5]);
    expect(
      executable.map(({ option, assetProfile }) => ({
        currency: option.currency,
        symbol: assetProfile?.symbol,
      })),
    ).toEqual([
      { currency: "GBP", symbol: "GBPe" },
      { currency: "EUR", symbol: "EURe" },
      { currency: "USD", symbol: "USDe" },
      { currency: "ISK", symbol: "ISKe" },
    ]);
  });

  it("keeps all production assets and their chain blocked", () => {
    expect(
      browserPayerRegistry.chains.filter(
        ({ environment }) => environment === "production",
      ),
    ).toEqual([
      expect.objectContaining({ caip2: "eip155:100", status: "blocked" }),
    ]);
    expect(
      browserPayerRegistry.assets
        .filter(({ environment }) => environment === "production")
        .map(({ currency, status }) => [currency, status]),
    ).toEqual([
      ["EUR", "blocked"],
      ["GBP", "blocked"],
      ["USD", "blocked"],
      ["ISK", "blocked"],
    ]);
  });
});
