import { describe, expect, it } from "vitest";

import {
  createPaymentReturnTarget,
  interpretPaymentRequest,
} from "../ts/userinterface/payment-request";

describe("hosted payment request", () => {
  it("accepts and normalizes all supported payment arguments", () => {
    expect(
      interpretPaymentRequest(
        "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&amount=12.30&currency=eur&reference=Invoice+42&return_url=https%3A%2F%2Fshop.example%2Forders%2F42%3Fsource%3Dopap&state=order_42",
        "https://shop.example/cart",
      ),
    ).toEqual({
      input: {
        sourceKind: "opid",
        opid: "https://merchant.example/donate",
        amount: "12.30",
        currency: "EUR",
        reference: "Invoice 42",
      },
      returnUrl: "https://shop.example/orders/42?source=opap",
      state: "order_42",
    });
  });

  it("allows a return URL on the OPID origin without a referrer", () => {
    expect(
      interpretPaymentRequest(
        "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fmerchant.example%2Fcomplete",
      ).returnUrl,
    ).toBe("https://merchant.example/complete");
  });

  it("builds cancelled and handoff return targets without payment evidence", () => {
    const request = interpretPaymentRequest(
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fmerchant.example%2Fcomplete%3Forder%3D42%26status%3Dforged%26chain%3Dforged%26transaction_hash%3Dforged&state=opaque-42",
    );

    expect(createPaymentReturnTarget(request, { status: "cancelled" })).toEqual(
      {
        href: "https://merchant.example/complete?order=42&status=cancelled&state=opaque-42",
        host: "merchant.example",
        status: "cancelled",
      },
    );
    expect(createPaymentReturnTarget(request, { status: "handoff" })).toEqual({
      href: "https://merchant.example/complete?order=42&status=handoff&state=opaque-42",
      host: "merchant.example",
      status: "handoff",
    });
  });

  it("adds independently verifiable evidence only for confirmed payments", () => {
    const request = interpretPaymentRequest(
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fmerchant.example%2Fcomplete&state=opaque-42",
    );

    expect(
      createPaymentReturnTarget(request, {
        status: "confirmed",
        chain: "eip155:10200",
        transactionHash: "0xabc",
      }),
    ).toEqual({
      href: "https://merchant.example/complete?status=confirmed&state=opaque-42&chain=eip155%3A10200&transaction_hash=0xabc",
      host: "merchant.example",
      status: "confirmed",
    });
  });

  it("has no return target when the request has no return URL", () => {
    const request = interpretPaymentRequest(
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate",
    );
    expect(
      createPaymentReturnTarget(request, { status: "cancelled" }),
    ).toBeUndefined();
  });

  it.each([
    [
      "cross-origin without matching referrer",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fevil.example%2Fcomplete",
      undefined,
    ],
    [
      "insecure return URL",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=http%3A%2F%2Fmerchant.example%2Fcomplete",
      undefined,
    ],
    [
      "credential-bearing return URL",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fuser%3Asecret%40merchant.example%2Fcomplete",
      undefined,
    ],
    [
      "fragment-bearing return URL",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fmerchant.example%2Fcomplete%23paid",
      undefined,
    ],
    [
      "state without a return URL",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&state=opaque-42",
      undefined,
    ],
    [
      "unsafe state",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&return_url=https%3A%2F%2Fmerchant.example%2Fcomplete&state=not+opaque",
      undefined,
    ],
    [
      "duplicate argument",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&amount=1&amount=2",
      undefined,
    ],
    [
      "zero amount",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&amount=0.00",
      undefined,
    ],
    [
      "malformed currency",
      "?opid=https%3A%2F%2Fmerchant.example%2Fdonate&currency=EURO",
      undefined,
    ],
  ])("rejects %s", (_name, search, referrer) => {
    expect(() => interpretPaymentRequest(search, referrer)).toThrow();
  });
});
