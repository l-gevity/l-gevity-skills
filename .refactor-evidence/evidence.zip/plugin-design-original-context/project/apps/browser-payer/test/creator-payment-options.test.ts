// @vitest-environment jsdom

import { beforeEach, describe, expect, it, vi } from "vitest";

import { CreatorPaymentOptions } from "../ts/userinterface/creator-payment-options";

function input(name: string, value = ""): string {
  return `<input data-option-field="${name}" value="${value}">`;
}

beforeEach(() => {
  HTMLElement.prototype.scrollIntoView = vi.fn();
  document.body.innerHTML = `
    <form>
      <input type="radio" name="paymentMode" value="options" checked>
      <input type="radio" name="paymentMode" value="delegate">
      <div data-payment-mode-panel="options"></div>
      <div data-payment-mode-panel="delegate"></div>
      <button type="button" data-add-payment-option>Add</button>
      <div data-payment-option-list></div>
    </form>
    <template data-payment-option-template>
      <fieldset data-payment-option>
        <span data-option-title></span>
        <button type="button" data-move-option-up>Up</button>
        <button type="button" data-move-option-down>Down</button>
        <button type="button" data-remove-option>Remove</button>
        <select data-option-kind>
          <option value="sepa">SEPA</option>
          <option value="erc20">ERC-20</option>
        </select>
        <div data-option-panel="sepa">
          ${input("name")}
          ${input("iban")}
        </div>
        <div data-option-panel="erc20">
          ${input("chainId")}
          ${input("currency")}
          ${input("asset")}
          <div data-direct-only>${input("symbol")}</div>
          <input type="checkbox" data-split-toggle>
          <div data-direct-panel>${input("recipient")}</div>
          <div data-split-panel>
            ${input("contract")}
            ${input("configId")}
            <div data-allocation-list></div>
            <button type="button" data-add-allocation>Add allocation</button>
            <span data-split-total></span>
            <div data-target-config-panel></div>
          </div>
        </div>
      </fieldset>
    </template>
    <template data-allocation-template>
      <div data-allocation>
        <select data-allocation-kind>
          <option value="recipient">Recipient</option>
          <option value="target">Target</option>
        </select>
        <div data-allocation-panel="recipient">
          <input data-allocation-field="recipient">
        </div>
        <div data-allocation-panel="target">
          <input data-allocation-field="target">
        </div>
        <input data-allocation-field="share">
        <button type="button" data-remove-allocation>Remove allocation</button>
      </div>
    </template>
  `;
});

describe("creator payment option controls", () => {
  it("manages ordered cards and produces SEPA and direct ERC-20 inputs", () => {
    const changed = vi.fn();
    const controller = new CreatorPaymentOptions();
    const form = document.querySelector("form");
    controller.initialize(changed);

    const first = document.querySelector<HTMLElement>("[data-payment-option]")!;
    first.querySelector<HTMLInputElement>('[data-option-field="name"]')!.value =
      "Merchant";
    first.querySelector<HTMLInputElement>('[data-option-field="iban"]')!.value =
      "NL91ABNA0417164300";
    expect(controller.inputs()).toEqual([
      {
        type: "sepa",
        name: "Merchant",
        iban: "NL91ABNA0417164300",
      },
    ]);

    document
      .querySelector<HTMLButtonElement>("[data-add-payment-option]")!
      .click();
    const cards = document.querySelectorAll<HTMLElement>(
      "[data-payment-option]",
    );
    expect(cards).toHaveLength(2);
    expect(changed).toHaveBeenCalledOnce();

    const second = cards[1]!;
    const kind = second.querySelector<HTMLSelectElement>("[data-option-kind]")!;
    kind.value = "erc20";
    controller.refreshChangedControl(kind);
    for (const [name, value] of Object.entries({
      chainId: "100",
      currency: "EUR",
      asset: "0x0000000000000000000000000000000000000001",
      recipient: "0x0000000000000000000000000000000000000002",
      symbol: "EURe",
    })) {
      second.querySelector<HTMLInputElement>(
        `[data-option-field="${name}"]`,
      )!.value = value;
    }
    expect(controller.inputs()[1]).toMatchObject({
      type: "erc20",
      chainId: "100",
      currency: "EUR",
      symbol: "EURe",
    });

    second.querySelector<HTMLButtonElement>("[data-move-option-up]")!.click();
    expect(document.querySelector<HTMLElement>("[data-payment-option]")).toBe(
      second,
    );
    first.querySelector<HTMLButtonElement>("[data-remove-option]")!.click();
    expect(document.querySelectorAll("[data-payment-option]")).toHaveLength(1);

    const delegate = form!.querySelector<HTMLInputElement>(
      'input[value="delegate"]',
    )!;
    delegate.checked = true;
    expect(controller.selectedMode(form)).toBe("delegate");
    controller.showMode("delegate");
    expect(
      document.querySelector<HTMLElement>(
        '[data-payment-mode-panel="options"]',
      )!.hidden,
    ).toBe(true);
  });

  it("builds and validates split recipient and OPID-target allocations", () => {
    const controller = new CreatorPaymentOptions();
    controller.initialize(vi.fn());
    const card = document.querySelector<HTMLElement>("[data-payment-option]")!;
    const kind = card.querySelector<HTMLSelectElement>("[data-option-kind]")!;
    kind.value = "erc20";
    controller.refreshChangedControl(kind);
    for (const [name, value] of Object.entries({
      chainId: "100",
      currency: "EUR",
      asset: "0x0000000000000000000000000000000000000001",
      contract: "0x0000000000000000000000000000000000000002",
      configId: `0x${"a".repeat(64)}`,
    })) {
      card.querySelector<HTMLInputElement>(
        `[data-option-field="${name}"]`,
      )!.value = value;
    }
    const toggle = card.querySelector<HTMLInputElement>("[data-split-toggle]")!;
    toggle.checked = true;
    controller.refreshChangedControl(toggle);

    const allocations = card.querySelectorAll<HTMLElement>("[data-allocation]");
    expect(allocations).toHaveLength(2);
    allocations[0]!.querySelector<HTMLInputElement>(
      '[data-allocation-field="recipient"]',
    )!.value = "0x0000000000000000000000000000000000000003";
    allocations[0]!.querySelector<HTMLInputElement>(
      '[data-allocation-field="share"]',
    )!.value = "60";
    const targetKind = allocations[1]!.querySelector<HTMLSelectElement>(
      "[data-allocation-kind]",
    )!;
    targetKind.value = "target";
    controller.refreshChangedControl(targetKind);
    allocations[1]!.querySelector<HTMLInputElement>(
      '[data-allocation-field="target"]',
    )!.value = "https://recipient.example/";
    const targetShare = allocations[1]!.querySelector<HTMLInputElement>(
      '[data-allocation-field="share"]',
    )!;
    targetShare.value = "40";
    controller.refreshShareTotal(targetShare);

    expect(controller.inputs()[0]).toMatchObject({
      type: "split",
      allocations: [
        { type: "recipient", sharePpm: 600_000 },
        { type: "target", sharePpm: 400_000 },
      ],
    });
    expect(card.querySelector("[data-split-total]")!.textContent).toBe(
      "Total: 100%",
    );
  });
});
