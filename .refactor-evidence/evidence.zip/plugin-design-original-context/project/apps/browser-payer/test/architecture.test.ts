import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { ESLint } from "eslint";
import { describe, expect, it } from "vitest";

const repositoryRoot = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../../..",
);
const eslint = new ESLint({ cwd: repositoryRoot });

async function architectureMessages(
  code: string,
  relativeFilePath: string,
): Promise<readonly string[]> {
  const [result] = await eslint.lintText(code, {
    filePath: resolve(repositoryRoot, relativeFilePath),
  });
  return (result?.messages ?? [])
    .filter((message) => message.ruleId?.startsWith("boundaries/") === true)
    .map((message) => message.message);
}

describe("architecture enforcement", { timeout: 30_000 }, () => {
  it("blocks UI imports of the composition root", async () => {
    const messages = await architectureMessages(
      'import "./main";',
      "apps/browser-payer/ts/userinterface/payment-input.ts",
    );
    expect(messages).toContain(
      "The Browser Payer composition root wires focused UI modules and must never become their dependency.",
    );
  });

  it("blocks contract deep imports of opap-core internals", async () => {
    const messages = await architectureMessages(
      'import "../../../packages/opap-core/src/record";',
      "contracts/opap-split/test/opap-split.test.ts",
    );
    expect(messages).toContain(
      "External callers must import core through its public facade.",
    );
  });

  it("blocks opap-runtime from re-exporting opap-core", async () => {
    const messages = await architectureMessages(
      'export { OpapError } from "@opap/core";',
      "packages/opap-runtime/src/index.ts",
    );
    expect(messages).toContain(
      "The runtime facade exports only runtime-owned capabilities; consumers import protocol primitives from @opap/core.",
    );
  });

  it("blocks UI access to the raw release registry", async () => {
    const messages = await architectureMessages(
      'import "../../../../registry/browser-payer-v1.json";',
      "apps/browser-payer/ts/userinterface/payment-input.ts",
    );
    expect(messages).toContain(
      "Browser Payer code must consume the release registry through the payer policy boundary.",
    );
  });

  it("allows contract tests to consume the opap-core facade", async () => {
    const messages = await architectureMessages(
      'import { deriveSplitConfigId } from "@opap/core"; void deriveSplitConfigId;',
      "contracts/opap-split/test/opap-split.test.ts",
    );
    expect(messages).toEqual([]);
  });

  it("allows Browser Payer code to consume the opap-core facade", async () => {
    const messages = await architectureMessages(
      'import { normalizeOpid } from "@opap/core"; void normalizeOpid;',
      "apps/browser-payer/ts/userinterface/payment-input.ts",
    );
    expect(messages).toEqual([]);
  });

  it("blocks browser persistence outside payer-storage", async () => {
    const [result] = await eslint.lintText(
      'localStorage.setItem("key", "value");',
      {
        filePath: resolve(
          repositoryRoot,
          "apps/browser-payer/ts/userinterface/payment-receipt.ts",
        ),
      },
    );
    expect(result?.messages.map((message) => message.message)).toContain(
      "Unexpected use of 'localStorage'. Browser persistence belongs to payer-storage; consume the BrowserHistoryAdapters contract.",
    );
  });

  it("blocks computed dynamic imports", async () => {
    const [result] = await eslint.lintText("void import(window.name);", {
      filePath: resolve(
        repositoryRoot,
        "apps/browser-payer/ts/userinterface/payment-input.ts",
      ),
    });
    expect(result?.messages.map((message) => message.message)).toContain(
      "Dynamic imports must use a literal path so architecture checks can resolve the dependency.",
    );
  });

  it("blocks production packages from importing their tests", async () => {
    const messages = await architectureMessages(
      'import "../test/assets.test";',
      "packages/opap-core/src/assets.ts",
    );
    expect(messages).toContain(
      "Production core code must not depend on verification code.",
    );
  });

  it("allows runtime tests to exercise internal implementation details", async () => {
    const messages = await architectureMessages(
      'import { MAX_DOH_RESPONSE_BYTES } from "../src/dns"; void MAX_DOH_RESPONSE_BYTES;',
      "packages/opap-runtime/test/dns.test.ts",
    );
    expect(messages).toEqual([]);
  });
});
