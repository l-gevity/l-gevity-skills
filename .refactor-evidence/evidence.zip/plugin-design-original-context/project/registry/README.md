# Browser Payer registry

`browser-payer-v1.json` is the release-pinned execution policy consumed by the OPAP Browser Payer. It is not an OPAP discovery source and never replaces a chain, asset, recipient, or contract published by an OPAP Record.

The release enables the deterministic local EVM and the four Monerium sandbox tokens on Chiado: EURe/EUR, GBPe/GBP, USDe/USD and ISKe/ISK. The corresponding Gnosis production entries are pinned but deliberately `blocked`. No Chiado or Gnosis split-contract entry exists until a separately authorized, reviewed deployment supplies an exact address and code fingerprint.

Asset identity, currency and decimals come from Monerium's public sandbox and production token endpoints. Chiado and Gnosis network identity, RPC, and explorer data come from the Gnosis Chain network documentation. The captured source fields and review date are recorded in [Monerium multi-currency provenance](../docs/implementation/monerium-multicurrency-provenance.md). Each `codeFingerprint` is SHA-256 over the deployed runtime bytecode. Entry fingerprints are SHA-256 over the compact JSON serialization of each entry excluding its `fingerprint` property and using the property order committed in the registry.

Registry changes require:

1. authoritative issuer/network provenance;
2. exact chain and contract identity;
3. a monotonically newer registry version;
4. regenerated entry and deployed-code fingerprints;
5. core, browser, and local-EVM tests; and
6. an explicit production enablement review for any `production` entry.
