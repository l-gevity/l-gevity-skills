# Original-context design reconstruction

This scenario evaluates the design stage using recovered original user context
and 51 exact product files from baseline
`4d1c0a630c5cddb4eb9dbd1e83fa151fd4a73ac4` in `openpaymentaddress.org`.
It is a reconstruction, not a replay of the original implementation.

The exact implementation request is quoted in `scenario.json`. The request
explicitly narrows this evaluation to read-only design assessment; it does not
silently claim to implement the original request. `project/REPLAY_CONTEXT.md`
contains actual raw user messages in order, including the later real-network
URI/QR-only restriction, currency acronym hero row, and list plus free-format
correction. The original raw session identity, SHA-256, source line numbers,
message IDs, all product file hashes, and context hash are preserved in
`source-manifest.json`.

The baseline is the original committed release named in the raw log when the
owner stopped the experiment. The failed experimental working tree survives
as `867b86ccb82e4d25d2cedea05ce5762cffa04941`, with untracked source in its
third parent. Completeness of the working tree before the first implementation
edits is not proven; this snapshot is the baseline release rather than a
claimed byte-identical whole historical task environment.

Only design-relevant authoring, validation, policy, review, URI/QR, caller,
and test files are copied. No `.agents`, `.claude`, root agent rules, settings,
secret files, or unrelated deployment sources are copied. This allows the
paired runner's before/after arm to remain the sole skill-guidance source.
Some imported files and generated validators are omitted; the fixture is not
a standalone build and no whole-application build/test claim is valid.

Before any replay, criteria require a static format catalog plus free-format
entry, preservation of known-format and existing authoring obligations,
real-network URI/QR presentation without payment handoff, truthful unsupported
format treatment, an accurate hero row, no unnecessary component inventories,
an actual loaded route, material unchecked facts, and at most 350 words.
The judge rubric owns semantic correctness; keyword matches alone cannot show
that a proposed URI format is valid or a removed mechanism is safe.

Even all criteria passing supports only the design behavior on this
reconstruction. Original-context implementation, standard-specific URI/QR
vectors, source compatibility, UI behavior, and no-wallet/no-transaction
runtime tests remain necessary before claiming the original release fixed.
The exact reduced historical c1 replay remains separate at
`../plugin-design-recovered-replay/`.
