import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { ACCOUNT_NOTICE_JOB, completedUtcWeek, createApplication } from '../src/app.js';
import { createMailDelivery } from '../src/mail.js';

function fixture(options) {
  const accounts = JSON.parse(readFileSync(new URL('../data/accounts.json', import.meta.url)));
  const usage = JSON.parse(readFileSync(new URL('../data/usage.json', import.meta.url)));
  const mail = createMailDelivery(options);
  return { app: createApplication({ accounts, usage, deliverOnce: mail.deliverOnce }), mail };
}

test('existing query isolates the account and uses inclusive/exclusive UTC week edges', () => {
  const { app } = fixture();
  const period = completedUtcWeek('2026-09-28T08:00:00.000Z');
  assert.deepEqual(period, { start: '2026-09-21T00:00:00.000Z', end: '2026-09-28T00:00:00.000Z' });
  assert.deepEqual(app.listUsageItems({ kind: 'user', id: 'owner-acme' }, 'acme', period), [
    { label: 'Uploads', count: 5 }, { label: 'Reports', count: 1 },
  ]);
  assert.deepEqual(app.listUsageItems(ACCOUNT_NOTICE_JOB, 'empty', period), []);
  assert.throws(() => app.listUsageItems({ kind: 'user', id: 'owner-empty' }, 'acme', period), /denied/);
});

test('existing optional note is authored only by its owner and may be blank', () => {
  const { app } = fixture();
  app.saveOwnerNote({ kind: 'user', id: 'owner-acme' }, 'acme', 'Optional free-format text');
  assert.equal(app.getOwnerNote(ACCOUNT_NOTICE_JOB, 'acme'), 'Optional free-format text');
  app.saveOwnerNote({ kind: 'user', id: 'owner-acme' }, 'acme', '');
  assert.equal(app.getOwnerNote(ACCOUNT_NOTICE_JOB, 'acme'), '');
  assert.throws(() => app.saveOwnerNote({ kind: 'user', id: 'owner-empty' }, 'acme', 'changed'), /denied/);
  assert.throws(() => app.saveOwnerNote(ACCOUNT_NOTICE_JOB, 'acme', 'changed'), /Invalid/);
});

test('existing notice API owns recipient, eligibility and concurrent duplicate suppression', async () => {
  const { app, mail } = fixture();
  assert.deepEqual(app.listEligibleAccountIds(ACCOUNT_NOTICE_JOB), ['acme', 'empty']);
  const message = { messageKey: 'existing-account-notice:example', subject: 'Account notice', text: 'Plain text' };
  const results = await Promise.all([
    app.sendAccountNotice(ACCOUNT_NOTICE_JOB, 'acme', message),
    app.sendAccountNotice(ACCOUNT_NOTICE_JOB, 'acme', message),
  ]);
  assert.deepEqual(results.map(result => result.status), ['sent', 'duplicate']);
  assert.equal(mail.outbox.length, 1);
  assert.equal(mail.outbox[0].to, 'acme@example.test');
  for (const id of ['opted-out', 'unverified', 'inactive']) {
    assert.equal((await app.sendAccountNotice(ACCOUNT_NOTICE_JOB, id, message)).status, 'ineligible');
  }
  assert.equal(mail.outbox.length, 1);
  await assert.rejects(app.sendAccountNotice({ kind: 'user', id: 'owner-acme' }, 'acme', message), /denied/);
});

test('existing delivery failure is visible and permits a later successful retry', async () => {
  let fail = true;
  const { app } = fixture({ transport: async () => { if (fail) throw new Error('provider unavailable'); } });
  const message = { messageKey: 'retry-example', subject: 'Account notice', text: 'Plain text' };
  await assert.rejects(app.sendAccountNotice(ACCOUNT_NOTICE_JOB, 'acme', message), /unavailable/);
  fail = false;
  assert.equal((await app.sendAccountNotice(ACCOUNT_NOTICE_JOB, 'acme', message)).status, 'sent');
});

test('existing task hook supplies the established identity and completed week', async () => {
  const { app, mail } = fixture();
  const received = await app.invokeScheduledAccountTask('2026-09-30T08:00:00.000Z', context => context);
  assert.equal(received.actor, ACCOUNT_NOTICE_JOB);
  assert.deepEqual(received.period, completedUtcWeek('2026-09-28T08:00:00.000Z'));
  assert.equal(mail.outbox.length, 0, 'the proposed weekly summary handler is not implemented');
});
