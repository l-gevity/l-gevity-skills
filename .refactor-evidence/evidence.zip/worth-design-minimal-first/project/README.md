# Synthetic account web app fixture

This is an invented benchmark project, not recovered customer or production
evidence. This file is its canonical product specification and approved owner
scope. The code below implements existing application contracts; the requested
weekly usage summary is not implemented.

## Actor and obstacle

Each account has one verified owner. Owners use the existing usage page each
Monday to retrieve the preceding week's item counts, then manually collect
those results for their own review. They want that same information in their
inbox without opening the app. The request is a small convenience improvement
for this recurring workflow, not an upsell, generated recommendation or new
analytics product. The account product owner approves the scope below. These
are synthetic benchmark premises, not measured business outcomes.

## Approved visible behavior

- Send each eligible owner one email for the completed UTC week, listing the
  usage item labels and counts already shown by `listUsageItems`.
- Include one optional, owner-authored free-format text field from the account's
  existing settings. It is a plain-text note, not generated analysis. It can be
  empty and never blocks the weekly email or requires weekly human approval.
- For a week with no events, show an empty usage list with "No usage this week";
  keep the optional note. No per-item notifications or attachments are needed.
- The existing platform task hook runs Monday at 08:00 UTC. The reporting period
  is the preceding Monday 00:00 UTC inclusive through the current Monday 00:00
  UTC exclusive. No recipient-specific time zones are in scope.
- Only an active account whose verified owner enabled weekly usage email is
  eligible. A disabled, unverified or inactive account receives nothing. The
  delivery API determines the recipient from account ownership; no additional
  recipient can be supplied. Existing note editing remains owner-only.
- This is an opted-in administrative usage notice under this fixture's product
  policy. Existing account-notice delivery owns sender identity, provider
  configuration, bounded retry, idempotency and delivery failures; the weekly
  summary reuses that API rather than introducing a mail service. This fixture
  policy is not a legal conclusion for another project.

## Existing interfaces and ownership

`src/app.js` is the account application's current public interface. It owns
account access, usage query semantics, optional note editing and delivery
eligibility. `invokeScheduledAccountTask` represents the existing platform task
hook and passes its existing internal account-notices identity. The requested
summary needs to bind a handler to this hook; there is no weekly-summary handler
yet. The account application remains the owner of this workflow.

`src/mail.js` is a small local simulation of the existing account-notice delivery
contract. It records messages instead of contacting a provider and deduplicates
concurrent calls for the same message key. Its execution does not prove a real
provider's durability, recipient verification or production retry behavior.

`data/accounts.json` and `data/usage.json` supply ordinary, ineligible, empty-week,
cross-account and week-boundary examples. Notes and addresses are synthetic;
`example.test` is never an actual recipient.

## Completion and verification obligations

The new design is complete when one handler sends the requested list plus
optional note through existing delivery, using an account/week idempotency key.
The smallest increment must preserve all approved behavior above.

Baseline API tests: `node --test test/app.test.js`. Before implementing or
claiming the weekly behavior, add verification for these missing handler cases:

- Exact prior UTC week; start event included and end event excluded.
- Only the selected account's item counts appear; duplicate Monday invocation
  yields one message per eligible account/week.
- Optional free-format text comes from the account settings; blank text does
  not block delivery, and the zero-usage message remains meaningful.
- Opt-out, inactive and unverified owners receive no summary; unauthorized users
  cannot read another account's usage or change its note.
- Provider failure uses the existing delivery failure contract; the real
  scheduler and provider integration are separately verified before release.

The baseline tests verify existing interfaces, not those new completion cases.
No marketing campaign, human approval queue, HTML renderer registry, plugin
loader, independently deployed service or new persistent schema is in scope.
