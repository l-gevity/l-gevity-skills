// Local simulation of the existing delivery API; never sends an external email.
export function createMailDelivery({ transport } = {}) {
  const outbox = [];
  const accepted = new Map();
  const send = transport ?? (async message => { outbox.push({ ...message }); });
  return {
    outbox,
    async deliverOnce(message) {
      if (accepted.has(message.key)) {
        await accepted.get(message.key);
        return { status: 'duplicate' };
      }
      const pending = Promise.resolve().then(() => send(message));
      accepted.set(message.key, pending);
      try {
        await pending;
        return { status: 'sent' };
      } catch (error) {
        accepted.delete(message.key);
        throw error;
      }
    },
  };
}
