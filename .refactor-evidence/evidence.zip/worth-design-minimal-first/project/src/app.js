export const ACCOUNT_NOTICE_JOB = Object.freeze({ kind: 'job', name: 'account-notices' });

export function completedUtcWeek(nowUtc) {
  const end = new Date(nowUtc);
  end.setUTCHours(0, 0, 0, 0);
  end.setUTCDate(end.getUTCDate() - ((end.getUTCDay() + 6) % 7));
  const start = new Date(end);
  start.setUTCDate(start.getUTCDate() - 7);
  return { start: start.toISOString(), end: end.toISOString() };
}

export function createApplication({ accounts, usage, deliverOnce }) {
  const isNoticeJob = actor => actor?.kind === 'job' && actor.name === 'account-notices';
  const eligible = account => account.active && account.owner.verified && account.weeklyUsageEmail;
  function accountFor(actor, accountId) {
    const account = accounts.find(value => value.id === accountId);
    if (!account || (!isNoticeJob(actor) && actor?.id !== account.owner.id)) {
      throw new Error('Account access denied');
    }
    return account;
  }

  return {
    listUsageItems(actor, accountId, { start, end }) {
      accountFor(actor, accountId);
      const items = new Map();
      for (const event of usage) {
        if (event.accountId === accountId && event.at >= start && event.at < end) {
          items.set(event.label, (items.get(event.label) ?? 0) + event.count);
        }
      }
      return [...items].map(([label, count]) => ({ label, count }));
    },
    getOwnerNote(actor, accountId) {
      return accountFor(actor, accountId).ownerNote;
    },
    saveOwnerNote(actor, accountId, text) {
      const account = accountFor(actor, accountId);
      if (actor?.kind !== 'user' || typeof text !== 'string' || text.length > 1000) {
        throw new Error('Invalid owner note');
      }
      account.ownerNote = text;
    },
    listEligibleAccountIds(actor) {
      if (!isNoticeJob(actor)) throw new Error('Account job access denied');
      return accounts.filter(eligible).map(account => account.id);
    },
    async sendAccountNotice(actor, accountId, { messageKey, subject, text }) {
      const account = accountFor(actor, accountId);
      if (!isNoticeJob(actor)) throw new Error('Account job access denied');
      if (!eligible(account)) return { status: 'ineligible' };
      return deliverOnce({ key: `${account.id}:${messageKey}`, to: account.owner.email, subject, text });
    },
    async invokeScheduledAccountTask(nowUtc, task) {
      return task({ actor: ACCOUNT_NOTICE_JOB, period: completedUtcWeek(nowUtc) });
    },
  };
}
