# Rejected refactor evidence

These are preserved inputs and results of the rejected v6 skills experiment,
not active skill guidance or acceptance scenarios for the selected infrastructure
commit. The predeclared criteria remain in ../.documentation/refactor-replay-criteria.md.

Each final-v6 JSON is an unchanged copy of the original replay metadata. Its
relative `.inputs` and `.logs` paths still identify the original artifact layout;
those supporting files live in the verified full snapshot:

`C:/Users/Patrick/Projects/l-gevity/l-gevity-skills-experimental-preserved-20261001-092102/working-tree.zip`

The sibling manifest.json records SHA-256 for all 4,311 preserved files. Status,
HEAD, working-tree diff and index diff are saved alongside it. Original ZIP paths
begin `.scenarios/<scenario>/replays/`. All failed and interrupted attempts remain
in that archive. Extract evidence into a separate review directory.

The two plugin folders include the original recovered requests, immutable product
fixtures and provenance. The original-context fixture reconstructs design after
owner clarification; it does not replay the whole implementation. The weekly-email
fixture is explicitly synthetic and cannot prove the original plugin failure fixed.

Current task skills and root instructions were restored to the accepted baseline.
Only independently validated infrastructure and the replay evaluation protocol
are selected for commit. No failed report/minimality criterion was weakened;
the experiment was withdrawn rather than relabeled successful.

These project-specific research fixtures are outside the published generic skill
library and outside active scenario discovery. They remain tracked evidence.
